#!/usr/bin/env python3
"""Put your own XMB art into EBOOT.PBP (no compiler needed).

  xmb_patch.py EBOOT.PBP [--icon ICON0.png] [--background PIC1.png] [--out NEW.PBP]

The PSP menu (XMB) only reads its icon and background from inside the EBOOT, so this rewrites those
two sections of the PBP container.  icon: 144x80 PNG, background: 480x272 PNG (other sizes are
resized).  Omitted images stay as they are."""
import argparse
import struct
import sys
from pathlib import Path

NAMES = ["PARAM.SFO", "ICON0.PNG", "ICON1.PMF", "PIC0.PNG", "PIC1.PNG", "SND0.AT3", "DATA.PSP", "DATA.PSAR"]


def read_pbp(data):
    if data[:4] != b"\0PBP":
        raise ValueError("not an EBOOT.PBP")
    offs = list(struct.unpack("<8I", data[8:40])) + [len(data)]
    return [data[offs[i]:offs[i + 1]] for i in range(8)]


def write_pbp(parts, version=0x10000):
    head = 40
    offs, pos = [], head
    for p in parts:
        offs.append(pos)
        pos += len(p)
    return b"\0PBP" + struct.pack("<I", version) + struct.pack("<8I", *offs) + b"".join(parts)


def png_bytes(path, size):
    from PIL import Image
    import io
    im = Image.open(path).convert("RGBA")
    if im.size != size:
        im = im.resize(size, Image.LANCZOS)
    buf = io.BytesIO()
    im.save(buf, "PNG")
    return buf.getvalue()


def patch(eboot, out, icon=None, background=None):
    data = Path(eboot).read_bytes()
    version = struct.unpack("<I", data[4:8])[0]
    parts = read_pbp(data)
    if icon:
        parts[1] = png_bytes(icon, (144, 80))
    if background:
        parts[4] = png_bytes(background, (480, 272))
    Path(out).write_bytes(write_pbp(parts, version))
    return {n: len(p) for n, p in zip(NAMES, parts)}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("eboot")
    ap.add_argument("--icon")
    ap.add_argument("--background")
    ap.add_argument("--out")
    a = ap.parse_args()
    sizes = patch(a.eboot, a.out or a.eboot, a.icon, a.background)
    print("wrote %s" % (a.out or a.eboot), sizes)


if __name__ == "__main__":
    sys.exit(main())
