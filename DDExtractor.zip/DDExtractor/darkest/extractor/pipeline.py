"""Extractor pipeline: the user's own Darkest Dungeon copy -> assets.pak (game data tables, art, UI, audio).

Runs the converter scripts in this repository / release folder in-process (so it also works from a
frozen build) and packs the result.  No game file is shipped with the tool.
"""
import contextlib
import io
import json
import os
import runpy
import shutil
import sys
import tempfile
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
# repo layout: <root>/darkest/{tools,extractor}, <root>/tools ;  release zip: same layout
DTOOLS = ROOT / "darkest" / "tools"
TOOLS = ROOT / "tools"


class Cancelled(Exception):
    pass


class Stage:
    def __init__(self, label, weight, run):
        self.label, self.weight, self.run = label, weight, run


def check_game_dir(p):
    p = Path(p)
    need = ["heroes", "monsters", "audio/master_banks", "shared", "dungeons", "fonts"]
    missing = [n for n in need if not (p / n).exists()]
    return (not missing, "ok" if not missing else "not a Darkest Dungeon folder (missing: %s)" % ", ".join(missing))


def check_spine(p):
    ok = (Path(p) / "spBinaryReader.py").exists()
    return ok, "ok" if ok else "folder must contain spBinaryReader.py (SpineConverter2.1.27)"


def check_vgmstream(path):
    import subprocess
    try:
        r = subprocess.run([str(path), "-h"], capture_output=True, text=True, timeout=20)
        txt = (r.stdout or "") + (r.stderr or "")
        if "vgmstream" in txt.lower():
            return True, "ok"
        return False, "does not look like vgmstream-cli"
    except Exception as e:  # noqa: BLE001
        return False, "cannot run it: %s" % e


def check_ffmpeg(path):
    import subprocess
    try:
        r = subprocess.run([str(path), "-hide_banner", "-encoders"], capture_output=True, text=True, timeout=20)
        if "libvorbis" in (r.stdout or ""):
            return True, "ok"
        if "ffmpeg" in ((r.stdout or "") + (r.stderr or "")).lower() or r.returncode == 0:
            return False, "this ffmpeg build has no libvorbis encoder (use a full / gpl build)"
        return False, "does not look like ffmpeg"
    except Exception as e:  # noqa: BLE001
        return False, "cannot run it: %s" % e


class Tee(io.TextIOBase):
    def __init__(self, log, cancel):
        self.log, self.cancel, self.buf = log, cancel, ""

    def write(self, s):
        if self.cancel.is_set():
            raise Cancelled()
        self.buf += s
        while "\n" in self.buf:
            line, self.buf = self.buf.split("\n", 1)
            if line.strip():
                self.log(line)
        return len(s)

    def flush(self):
        pass


def run_script(path, args, log, cancel):
    """Run a converter script (as __main__) with sys.argv set; its prints go to the log."""
    old_argv, old_path = sys.argv, list(sys.path)
    sys.argv = [str(path)] + [str(a) for a in args]
    sys.path.insert(0, str(Path(path).parent))
    out = Tee(log, cancel)
    try:
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(out):
            try:
                runpy.run_path(str(path), run_name="__main__")
            except SystemExit as e:
                if e.code not in (None, 0):
                    raise RuntimeError("%s failed: %s" % (Path(path).name, e.code))
    finally:
        sys.argv, sys.path[:] = old_argv, old_path


def extract(game, vgmstream, ffmpeg, spine, out_pak, log=print, progress=lambda f, label: None, cancel=None, keep_work=False):
    cancel = cancel or threading.Event()
    game, out_pak = Path(game), Path(out_pak)
    work = Path(tempfile.mkdtemp(prefix="ddextract_", dir=str(out_pak.parent)))
    assets, gen = work / "assets", work / "gen"
    assets.mkdir(parents=True)
    gen.mkdir()
    os.environ["DD_VGMSTREAM"] = str(vgmstream)
    os.environ["DD_FFMPEG"] = str(ffmpeg)
    os.environ["DD_SPINE_CONVERTER"] = str(spine)
    os.environ["VGMSTREAM"] = str(vgmstream)

    def game_data():
        run_script(DTOOLS / "export_game_data.py", [game, gen], log, cancel)
        import importlib.util
        spec_file = DTOOLS / "dd_spec.json"
        sp = importlib.util.spec_from_file_location("ddbin", DTOOLS / "ddbin.py")
        ddbin = importlib.util.module_from_spec(sp)
        sp.loader.exec_module(ddbin)
        spec = json.load(open(spec_file))
        blob = ddbin.make_bin(spec, (gen / "dd_data.c").read_text(encoding="utf-8"))
        (assets / "gen").mkdir(exist_ok=True)
        (assets / "gen" / "dd_data.bin").write_bytes(blob)
        log("game data: %d bytes" % len(blob))

    stages = [
        Stage("Game data tables", 3, game_data),
        Stage("Hero and monster sprites", 40, lambda: run_script(DTOOLS / "export_art.py", [game, gen / "manifest.json", assets / "sprites"], log, cancel)),
        Stage("Interface art", 8, lambda: run_script(DTOOLS / "export_ui.py", [game, assets], log, cancel)),
        Stage("Town art", 8, lambda: run_script(DTOOLS / "export_town.py", [game, assets], log, cancel)),
        Stage("HUD and fonts", 8, lambda: run_script(DTOOLS / "export_hud.py", [game, assets], log, cancel)),
        Stage("Camping icons", 1, lambda: run_script(DTOOLS / "export_camp.py", [game, assets], log, cancel)),
        Stage("Button glyphs", 1, lambda: run_script(DTOOLS / "make_buttons.py", [assets], log, cancel)),
        Stage("Sound and music", 30, lambda: run_script(DTOOLS / "export_audio.py", [game, assets], log, cancel)),
        Stage("Packing assets.pak", 3, lambda: run_script(DTOOLS / "pack_assets.py", [assets, work / "assets.pak"], log, cancel)),
    ]
    total = sum(s.weight for s in stages)
    done = 0
    try:
        for st in stages:
            if cancel.is_set():
                raise Cancelled()
            log("== %s" % st.label)
            progress(done / total, st.label)
            st.run()
            done += st.weight
        progress(1.0, "Done")
        shutil.move(str(work / "assets.pak"), str(out_pak))
        log("wrote %s (%.1f MB)" % (out_pak, out_pak.stat().st_size / 1e6))
    finally:
        if not keep_work:
            shutil.rmtree(work, ignore_errors=True)
    return out_pak
