#!/usr/bin/env python3
"""Darkest Dungeon PSP demake - asset extractor.

Reads YOUR copy of Darkest Dungeon (Steam) and builds assets.pak for the demake's EBOOT.PBP.
Nothing from the game is shipped with this tool.

  python3 extractor.py                     the window
  python3 extractor.py --cli GAME_DIR --vgmstream PATH --ffmpeg PATH --spine DIR --out assets.pak
"""
import argparse
import json
import os
import sys
import threading
import webbrowser
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pipeline  # noqa: E402
import xmb_patch  # noqa: E402

VGMSTREAM_URL = "https://github.com/vgmstream/vgmstream/releases/latest"
FFMPEG_URL = "https://www.ffmpeg.org/download.html"
CONFIG = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / "dd-psp-extractor.json"


def load_cfg():
    try:
        return json.load(open(CONFIG))
    except Exception:  # noqa: BLE001
        return {}


def save_cfg(cfg):
    try:
        CONFIG.parent.mkdir(parents=True, exist_ok=True)
        json.dump(cfg, open(CONFIG, "w"), indent=1)
    except Exception:  # noqa: BLE001
        pass


def guess_steam_dir():
    for p in (Path.home() / ".steam/steam/steamapps/common/DarkestDungeon", Path.home() / ".local/share/Steam/steamapps/common/DarkestDungeon",
              Path("C:/Program Files (x86)/Steam/steamapps/common/DarkestDungeon"), Path("C:/Program Files/Steam/steamapps/common/DarkestDungeon")):
        if p.exists():
            return str(p)
    return ""


def cli(a):
    for name, ok in (("game", pipeline.check_game_dir(a.game)), ("vgmstream", pipeline.check_vgmstream(a.vgmstream)),
                     ("ffmpeg", pipeline.check_ffmpeg(a.ffmpeg)), ("spine", pipeline.check_spine(a.spine))):
        if not ok[0]:
            sys.exit("%s: %s" % (name, ok[1]))
    last = [None]

    def prog(f, label):
        if label != last[0]:
            last[0] = label
    pipeline.extract(a.game, a.vgmstream, a.ffmpeg, a.spine, a.out, log=lambda s: (sys.__stdout__.write(s + "\n"), sys.__stdout__.flush()), progress=prog, keep_work=a.keep)


def gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    try:
        import PIL  # noqa: F401
    except ImportError:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Pillow missing", "This tool needs the Python package Pillow.\nInstall it with:\n\n    pip install pillow")
        return

    cfg = load_cfg()
    root = tk.Tk()
    root.title("Darkest Dungeon PSP - asset extractor")
    root.geometry("760x700")
    nb = ttk.Notebook(root)
    nb.pack(fill="both", expand=True, padx=6, pady=6)
    frm = ttk.Frame(nb, padding=8)      # tab 1: extract
    tab2 = ttk.Frame(nb, padding=8)     # tab 2: menu art
    nb.add(frm, text="Extract assets")
    nb.add(tab2, text="Menu art (optional)")

    vars_ = {k: tk.StringVar(value=cfg.get(k, "")) for k in ("game", "vgm", "ffmpeg", "spine", "out")}
    if not vars_["game"].get():
        vars_["game"].set(guess_steam_dir())
    if not vars_["out"].get():
        vars_["out"].set(str(Path.home() / "assets.pak"))
    status = {k: tk.StringVar(value="") for k in vars_}

    checks = {
        "game": pipeline.check_game_dir, "vgm": pipeline.check_vgmstream, "ffmpeg": pipeline.check_ffmpeg,
        "spine": pipeline.check_spine, "out": lambda p: (bool(p) and Path(p).parent.exists(), "ok" if p and Path(p).parent.exists() else "folder does not exist"),
    }
    labels = {
        "game": ("1. Darkest Dungeon folder", "The Steam install folder (contains heroes, audio, fonts ...)"),
        "vgm": ("2. vgmstream-cli", "Decodes the game's FMOD sound banks.  Download vgmstream-cli for your system, unzip it, pick the program."),
        "ffmpeg": ("3. ffmpeg", "Encodes the sounds.  Download a full build (it must include libvorbis), pick the ffmpeg program."),
        "spine": ("4. SpineConverter2.1.27 folder", "Converts the game's animations.  Pick the folder that contains spBinaryReader.py."),
        "out": ("5. Save assets.pak as", "Put the finished file next to EBOOT.PBP on the PSP."),
    }
    buttons = {}

    def refresh(*_):
        allok = True
        for k, fn in checks.items():
            v = vars_[k].get().strip()
            if not v:
                status[k].set("")
                allok = False
                continue
            ok, msg = fn(v)
            status[k].set(("\u2713 " if ok else "\u2717 ") + msg)
            allok &= ok
        buttons["go"].state(["!disabled"] if allok and not running[0] else ["disabled"])

    def browse(k):
        if k in ("game", "spine"):
            p = filedialog.askdirectory(title=labels[k][0], initialdir=vars_[k].get() or str(Path.home()))
        elif k == "out":
            p = filedialog.asksaveasfilename(title=labels[k][0], defaultextension=".pak", initialfile="assets.pak")
        else:
            p = filedialog.askopenfilename(title=labels[k][0])
        if p:
            vars_[k].set(p)

    running = [False]
    for i, k in enumerate(("game", "vgm", "ffmpeg", "spine", "out")):
        box = ttk.LabelFrame(frm, text=labels[k][0], padding=6)
        box.pack(fill="x", pady=2)
        ttk.Label(box, text=labels[k][1], wraplength=700, foreground="#555").pack(anchor="w")
        row = ttk.Frame(box)
        row.pack(fill="x", pady=2)
        e = ttk.Entry(row, textvariable=vars_[k])
        e.pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Browse...", command=lambda k=k: browse(k)).pack(side="left", padx=4)
        if k == "vgm":
            ttk.Button(row, text="Download page", command=lambda: webbrowser.open(VGMSTREAM_URL)).pack(side="left")
        if k == "ffmpeg":
            ttk.Button(row, text="Download page", command=lambda: webbrowser.open(FFMPEG_URL)).pack(side="left")
        ttk.Label(box, textvariable=status[k]).pack(anchor="w")
        vars_[k].trace_add("write", refresh)

    row = ttk.Frame(frm)
    row.pack(side="bottom", fill="x", pady=(4, 0))
    bar = ttk.Progressbar(frm, maximum=1000)
    bar.pack(fill="x", pady=(8, 2))
    stage = tk.StringVar(value="")
    ttk.Label(frm, textvariable=stage).pack(anchor="w")
    logbox = tk.Text(frm, height=6, state="disabled", wrap="word")
    logbox.pack(fill="both", expand=True, pady=4)
    cancel = threading.Event()

    def log(line):
        def ui():
            logbox.configure(state="normal")
            logbox.insert("end", line + "\n")
            logbox.see("end")
            logbox.configure(state="disabled")
        root.after(0, ui)

    def progress(f, label):
        root.after(0, lambda: (bar.configure(value=int(f * 1000)), stage.set(label)))

    def worker():
        try:
            out = pipeline.extract(vars_["game"].get(), vars_["vgm"].get(), vars_["ffmpeg"].get(), vars_["spine"].get(),
                                   vars_["out"].get(), log=log, progress=progress, cancel=cancel)
            root.after(0, lambda: messagebox.showinfo("Done", "Wrote %s\n\nCopy it next to EBOOT.PBP on your PSP." % out))
        except pipeline.Cancelled:
            log("cancelled")
        except Exception as e:  # noqa: BLE001
            log("ERROR: %s" % e)
            root.after(0, lambda: messagebox.showerror("Extraction failed", str(e)))
        finally:
            running[0] = False
            root.after(0, lambda: (buttons["cancel"].state(["disabled"]), refresh()))

    def go():
        save_cfg({k: v.get() for k, v in vars_.items()})
        cancel.clear()
        running[0] = True
        buttons["go"].state(["disabled"])
        buttons["cancel"].state(["!disabled"])
        threading.Thread(target=worker, daemon=True).start()

    # optional: own XMB art into the EBOOT
    xv = {k: tk.StringVar(value=cfg.get("x_" + k, "")) for k in ("eboot", "icon", "bg")}
    ttk.Label(tab2, wraplength=700, text="The PSP menu (XMB) shows an icon and a background for the game. They are stored inside EBOOT.PBP. "
              "Pick your EBOOT.PBP and your own PNG images, then press the button; the EBOOT is updated in place (keep a copy).").pack(anchor="w", pady=(0, 8))
    xb = ttk.LabelFrame(tab2, text="Your menu art", padding=6)
    xb.pack(fill="x", pady=3)
    for k, label in (("eboot", "EBOOT.PBP"), ("icon", "Icon (144x80 PNG)"), ("bg", "Background (480x272 PNG)")):
        r = ttk.Frame(xb)
        r.pack(fill="x", pady=1)
        ttk.Label(r, text=label, width=24).pack(side="left")
        ttk.Entry(r, textvariable=xv[k]).pack(side="left", fill="x", expand=True)
        ttk.Button(r, text="Browse...", command=lambda k=k: xv[k].set(filedialog.askopenfilename() or xv[k].get())).pack(side="left", padx=4)

    def patch_xmb():
        try:
            if not xv["eboot"].get():
                raise ValueError("pick the EBOOT.PBP first")
            xmb_patch.patch(xv["eboot"].get(), xv["eboot"].get(), xv["icon"].get() or None, xv["bg"].get() or None)
            save_cfg({**{k: v.get() for k, v in vars_.items()}, **{"x_" + k: v.get() for k, v in xv.items()}})
            messagebox.showinfo("Done", "Menu art written into the EBOOT.")
        except Exception as e:  # noqa: BLE001
            messagebox.showerror("Could not patch", str(e))
    ttk.Button(xb, text="Put art into EBOOT", command=patch_xmb).pack(anchor="w", pady=2)

    buttons["go"] = ttk.Button(row, text="Extract", command=go)
    buttons["go"].pack(side="left")
    buttons["cancel"] = ttk.Button(row, text="Cancel", command=cancel.set)
    buttons["cancel"].pack(side="left", padx=6)
    buttons["cancel"].state(["disabled"])
    refresh()
    root.mainloop()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--cli", dest="game")
    ap.add_argument("--vgmstream")
    ap.add_argument("--ffmpeg")
    ap.add_argument("--spine")
    ap.add_argument("--out", default="assets.pak")
    ap.add_argument("--keep", action="store_true", help="keep the temporary work folder")
    a = ap.parse_args()
    if a.game:
        cli(a)
    else:
        gui()


if __name__ == "__main__":
    main()
