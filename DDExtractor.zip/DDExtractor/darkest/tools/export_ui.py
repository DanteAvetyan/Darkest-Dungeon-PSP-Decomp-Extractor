#!/usr/bin/env python3
"""Export fonts, dungeon backgrounds, portraits and skill icons for the PSP demake.

Usage: export_ui.py <game_dir> <out_dir>

Formats (little endian, read by src/core/assets.c):
  .ddi  image:  "DDI1" u16 w, h, tile, ntx, nty; pad u16; clut[256*4] RGBA;
                tiles row-major, each tile*tile u8 indices (edge tiles padded)
  .ddf  font:   "DDF1" u16 line_h, base, page_w, page_h, nglyphs; pad u16;
                glyphs x (u16 code, x, y, w, h; i16 xoff, yoff, xadv); u8 alpha[page_w*page_h]
"""
import struct
import sys
from pathlib import Path

from PIL import Image

TOOLS = Path(__file__).resolve().parents[2] / "tools"
sys.path.insert(0, str(TOOLS))
from pack_psp_atlas import quantize_rgba, resize_rgba  # noqa: E402

SCREEN_H = 272
BG_H = 256  # backgrounds are stored one tile tall and stretched to 272 when drawn
TILE = 256
HEROES = ["crusader", "highwayman", "vestal", "occultist", "grave_robber", "bounty_hunter",
          "hellion", "leper", "man_at_arms", "jester", "houndmaster", "arbalest", "antiquarian",
          "abomination", "plague_doctor"]
DUNGEONS = ["crypts", "weald", "warrens", "cove"]
ABILITY_NAMES = ["one", "two", "three", "four", "five", "six", "seven"]


# Write an image as .ddi (format at the top of this file): quantize to 256 colours and cut it
# into tile x tile pieces (edge tiles padded with transparent) because PSP textures must be
# power-of-two and at most 512 wide.
def write_ddi(img, path, tile=TILE):
    img = img.convert("RGBA")
    w, h = img.size
    ntx, nty = (w + tile - 1) // tile, (h + tile - 1) // tile
    canvas = Image.new("RGBA", (ntx * tile, nty * tile), (0, 0, 0, 0))
    canvas.paste(img, (0, 0))
    q, pal = quantize_rgba(canvas)
    data = struct.pack("<4s5HH", b"DDI1", w, h, tile, ntx, nty, 0) + bytes(pal)
    for ty in range(nty):
        for tx in range(ntx):
            data += q.crop((tx * tile, ty * tile, (tx + 1) * tile, (ty + 1) * tile)).tobytes()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


# Resize keeping aspect ratio to an exact height.
def fit_height(img, h):
    w = max(1, round(img.width * h / img.height))
    return resize_rgba(img.convert("RGBA"), (w, h))


# Resize keeping aspect ratio to fit inside w x h.
def fit_box(img, w, h):
    s = min(w / img.width, h / img.height)
    return resize_rgba(img.convert("RGBA"), (max(1, round(img.width * s)), max(1, round(img.height * s))))


# --------------------------------------------------------------------- fonts

# Read a BMFont-style .fnt text file (glyph rectangles and metrics).
def parse_fnt(path):
    info, chars = {}, []
    for line in path.read_text(errors="replace").splitlines():
        parts = line.split()
        if not parts:
            continue
        kv = {}
        for p in parts[1:]:
            if "=" in p:
                k, v = p.split("=", 1)
                kv[k] = v.strip('"')
        if parts[0] == "common":
            info.update(kv)
        elif parts[0] == "page":
            info.setdefault("pages", []).append(kv["file"]) if isinstance(info.get("pages"), list) \
                else info.__setitem__("pages", [kv["file"]])
        elif parts[0] == "char":
            chars.append({k: int(v) for k, v in kv.items() if k != "letter"})
    return info, chars


# Build a .ddf font: repack the glyph bitmap as 8-bit alpha and write glyph records.
def export_font(fnt_path, out_path, line_h, tight=1.0):
    info, chars = parse_fnt(fnt_path)
    src_line = int(info["lineHeight"])
    s = line_h / src_line
    page = Image.open(fnt_path.parent / info["pages"][0]).convert("RGBA")
    glyphs = []
    for c in chars:
        if not (32 <= c["id"] < 127):
            continue
        g = page.crop((c["x"], c["y"], c["x"] + c["width"], c["y"] + c["height"]))
        # BMFont white-on-alpha: keep alpha (or luminance when alpha is flat)
        a = g.getchannel("A")
        if a.getextrema() == (255, 255):
            a = g.convert("L")
        gw, gh = max(1, round(c["width"] * s)), max(1, round(c["height"] * s))
        a = a.resize((gw, gh), Image.Resampling.LANCZOS) if c["width"] > 1 else Image.new("L", (gw, gh), 0)
        glyphs.append((c["id"], a, round(c["xoffset"] * s), round(c["yoffset"] * s),
                       max(1, round(c["xadvance"] * s * tight))))
    # shelf pack into 256 x N
    pw, x, y, shelf, pos = 256, 1, 1, 0, []
    for code, a, *_ in sorted(glyphs, key=lambda g: -g[1].height):
        if x + a.width + 1 > pw:
            x, y, shelf = 1, y + shelf + 1, 0
        pos.append((code, x, y))
        x += a.width + 1
        shelf = max(shelf, a.height)
    ph = 64
    while ph < y + shelf + 1:
        ph *= 2
    atlas = Image.new("L", (pw, ph), 0)
    at = {code: (px, py) for code, px, py in pos}
    blob = b""
    for code, a, xo, yo, adv in glyphs:
        px, py = at[code]
        atlas.paste(a, (px, py))
        blob += struct.pack("<5H3h", code, px, py, a.width, a.height, xo, yo, adv)
    base = round(int(info["base"]) * s)
    data = struct.pack("<4s5HH", b"DDF1", line_h, base, pw, ph, len(glyphs), 0) + blob + atlas.tobytes()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(data)
    return len(glyphs), pw, ph


# --------------------------------------------------------------------- main

# Driver: fonts, dungeon backgrounds, portraits, skill icons, title and menu art.
def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    game, out = Path(sys.argv[1]).expanduser(), Path(sys.argv[2])
    n = 0

    print("fonts:", export_font(game / "fonts/ubuntu.fnt", out / "fonts/body.ddf", 12),
          export_font(game / "fonts/dwarvenaxe-m.fnt", out / "fonts/title.ddf", 18, tight=1.1))

    for d in DUNGEONS:
        src = game / "dungeons" / d
        dst = out / "dungeons" / d
        for p in sorted(src.glob(f"{d}.*.png")):
            name = p.name[len(d) + 1:-4]
            if any(k in name for k in ("colour_grade", "plot_", "tutorial", "final_room")):
                continue
            img = Image.open(p)
            # corridor layers are 720 tall like rooms; all are drawn at full screen height
            write_ddi(fit_height(img, BG_H), dst / f"{name}.ddi")
            n += 1

    # the Darkest Dungeon: one art set per plot quest (quest_1..4) -> dungeons/dd1..dd4, renamed to
    # corridor_wall.00.., room_wall.r0.., entrance_room_wall, final_room_wall
    import re as _re
    for q in range(1, 5):
        src = game / "dungeons/darkestdungeon" / f"quest_{q}"
        dst = out / "dungeons" / f"dd{q}"
        walls = rooms = 0
        for p in sorted(src.glob("darkestdungeon.*.png")):
            name = p.name[len("darkestdungeon."):-4]
            if name.startswith(("corridor_bg.0", "corridor_mid.0")) and (src / f"darkestdungeon.{name[:-3]}.png").exists():
                continue  # keep the plain corridor_bg / corridor_mid layer
            if name.startswith("corridor_wall."):
                name, walls = f"corridor_wall.{walls:02d}", walls + 1
            elif name.startswith("room_wall."):
                name, rooms = f"room_wall.r{rooms}", rooms + 1
            elif _re.match(r"(entrance|final)_room_wall\.plot_", name):
                name = name.split(".")[0]
            elif name.startswith("corridor_bg.0"):
                name = "corridor_bg"
            write_ddi(fit_height(Image.open(p), BG_H), dst / f"{name}.ddi")
            n += 1
        print(f"dd{q}: {walls} corridor walls, {rooms} room walls")

    # colour grades (16x256 RGB LUTs, one per light band 0 = dark .. 4 = bright) as raw RGB
    def lut(src, dst):
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(Image.open(src).convert("RGB").tobytes())
    for d in DUNGEONS + ["town"]:
        for b in range(5):
            if (game / "dungeons" / d / f"colour_grade_{b}.png").exists():
                lut(game / "dungeons" / d / f"colour_grade_{b}.png", out / "dungeons" / d / f"grade_{b}.lut")
            crow = game / "dungeons" / d / f"colour_grade_plot_crow_trinket_{b}.png"
            if crow.exists():
                lut(crow, out / "dungeons" / d / "crow" / f"grade_{b}.lut")
            for n in range(3):  # the Shrieker's Perch, by level
                p = game / "dungeons" / d / f"colour_grade_plot_trinket_retention_{n}_{b}.png"
                if p.exists():
                    lut(p, out / "dungeons" / d / f"perch{n}" / f"grade_{b}.lut")
    # the Shrieker quests' one room (final_room_wall.plot_*)
    for key, name in [("plot_crow_trinket", "plot_crow")] + [(f"plot_trinket_retention_{n}", f"plot_perch{n}") for n in range(3)]:
        write_ddi(fit_height(Image.open(game / f"dungeons/weald/weald.final_room_wall.{key}.png"), BG_H),
                  out / "dungeons/weald" / f"{name}.ddi")

    # the Darkest Dungeon grades per quest: darkestdungeon/quest_N/colour_grade_0..4 -> dd<N>
    for q in range(1, 5):
        for b in range(5):
            src = game / "dungeons/darkestdungeon" / f"quest_{q}" / f"colour_grade_{b}.png"
            if src.exists():
                lut(src, out / "dungeons" / f"dd{q}" / f"grade_{b}.lut")

    # loading cards shown when an expedition starts (loading_screen.<key>.png), the mode select
    # dialog (backdrop + one skull per mode) and the Old Road's own two rooms
    for p in sorted((game / "loading_screen").glob("loading_screen.*.png")):
        key = p.name[len("loading_screen."):-4]
        if key in ("tipoverlay", "titleoverlay") or key.startswith("plot_kill_"):
            continue
        write_ddi(fit_height(Image.open(p), BG_H), out / "ui/loading" / f"{key}.ddi")
        n += 1
    write_ddi(fit_box(Image.open(game / "fe_flow/modeselect_menu_backdrop.png"), 300, 250), out / "ui/mode_backdrop.ddi")
    for m in ("radiant", "base", "new_game_plus"):
        write_ddi(fit_box(Image.open(game / "modes" / m / "fe_flow/mode_select_dialog_icon.png"), 64, 64),
                  out / "ui" / f"mode_{m}.ddi", tile=64)
    # raid results (two pages over the quest background) and the quest-complete seal
    write_ddi(fit_height(Image.open(game / "raid_results/raid_results.quest_completed_background.png"), BG_H),
              out / "ui/results_bg.ddi")
    write_ddi(fit_box(Image.open(game / "raid_results/raid_results.heroes_frames.png"), 200, 200), out / "ui/results_heroes.ddi")
    write_ddi(fit_box(Image.open(game / "overlays/quest_complete.png"), 60, 76), out / "ui/quest_seal.ddi", tile=128)
    for i, name in enumerate(("entrance", "final")):
        write_ddi(fit_height(Image.open(game / f"dungeons/weald/weald.tutorial.room_wall.effigy_{i}.png"), BG_H),
                  out / "dungeons/weald" / f"oldroad_{name}.ddi")
    n += 6

    # the Hamlet as a dungeon (Wolves at the Door): same naming as dd1..dd4
    src, dst = game / "dungeons/town", out / "dungeons/town"
    walls = rooms = 0
    for p in sorted(src.glob("town.*.png")):
        name = p.name[len("town."):-4]
        if name.startswith("corridor_wall."):
            name, walls = f"corridor_wall.{walls:02d}", walls + 1
        elif name == "room_wall.start":
            name = "entrance_room_wall"
        elif name.startswith("room_wall."):
            name, rooms = f"room_wall.r{rooms}", rooms + 1
        elif name.startswith("corridor_mid."):
            if name != "corridor_mid.01":
                continue
            name = "corridor_mid"
        elif not name.startswith(("corridor_bg", "corridor_door")):
            continue
        write_ddi(fit_height(Image.open(p), BG_H), dst / f"{name}.ddi")
        n += 1
    print(f"town: {walls} corridor walls, {rooms} room walls")

    for h in HEROES:
        src = game / "heroes" / h
        portrait = src / f"{h}_A" / f"{h}_portrait_roster.png"
        if portrait.exists():
            write_ddi(fit_box(Image.open(portrait), 48, 48), out / "heroes" / h / "portrait.ddi", tile=64)
            n += 1
        for i, word in enumerate(ABILITY_NAMES):
            icon = src / f"{h}.ability.{word}.png"
            if icon.exists():
                write_ddi(fit_box(Image.open(icon), 32, 32), out / "heroes" / h / f"skill{i}.ddi", tile=32)
                n += 1

    # title screen: red sky (lower half of the tall gradient), manor silhouette, start frame
    sky = Image.open(game / "fe_flow/title_bg.png")
    sky = sky.crop((0, sky.height * 2 // 5, sky.width, sky.height))  # enough glow to sit the logo on
    write_ddi(fit_height(sky, BG_H), out / "ui/title_sky.ddi")
    house = Image.open(game / "fe_flow/title_house.png").convert("RGBA")
    write_ddi(resize_rgba(house, (480, round(house.height * 480 / house.width))), out / "ui/title_house.ddi")
    write_ddi(fit_box(Image.open(game / "fe_flow/start_button.png"), 160, 40), out / "ui/frame_button.ddi", tile=256)
    write_ddi(fit_height(Image.open(game / "campaign/town/town_bg.png"), BG_H), out / "ui/town_sky.ddi")
    write_ddi(fit_height(Image.open(game / "game_over/game_over.background.png"), BG_H), out / "ui/game_over.ddi")
    n += 6

    # buildings: interior background, keeper, icon, activity icons
    town = game / "campaign/town/buildings"
    for b in ["stage_coach", "guild", "blacksmith", "tavern", "abbey", "sanitarium", "camping_trainer",
              "graveyard", "nomad_wagon"]:
        d = town / b
        bg = d / f"{b}.character_background.png"
        if bg.exists():
            write_ddi(fit_height(Image.open(bg), BG_H), out / f"ui/{b}_bg.ddi")
        ch = d / f"{b}.character.png"
        if ch.exists():
            write_ddi(fit_box(Image.open(ch), 190, 190), out / f"ui/{b}_char.ddi")
        ic = d / f"{b}.icon.png"
        if ic.exists():
            write_ddi(fit_box(Image.open(ic), 40, 40), out / f"ui/{b}_icon.ddi", tile=64)
        for extra in d.glob(f"{b}.*.icon.png"):
            name = extra.name[len(b) + 1:-len(".icon.png")]
            write_ddi(fit_box(Image.open(extra), 36, 36), out / f"ui/{b}_{name}.ddi", tile=64)
            n += 1
        n += 3

    for p in (game / "loading_screen").glob("loading_screen.*_0.png"):
        write_ddi(fit_box(Image.open(p), 480, 272), out / "loading" / f"{p.name.split('.')[1]}.ddi")
        n += 1
    print(f"{n} images")


if __name__ == "__main__":
    main()
