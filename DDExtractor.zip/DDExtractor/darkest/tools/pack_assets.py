#!/usr/bin/env python3
"""Pack the converted assets into one file for the memory stick.

Usage: pack_assets.py <assets_dir> <out.pak>
Format (little endian): "DDPK", u32 version (1), u32 count, u32 index_bytes, then the index
sorted by path: u32 offset, u32 packed_size, u32 size, u16 path_len, path (relative to assets/,
'/' separators); then the data. Entries are zlib streams, or stored when packed_size == size.
"""
import struct
import sys
import zlib
from pathlib import Path

SKIP = (".page.png",)  # converter intermediates the game never opens


# Steps: (1) list every asset file; (2) sort names bytewise - the C reader binary-searches with
# strcmp, so this order matters; (3) zlib-compress each (level 9), keeping the raw bytes when
# compression doesn't help; (4) build the index (offset/sizes/name) - offsets are absolute so
# the index size must be known first (index_bytes); (5) write header + index + data.
def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    root, out = Path(sys.argv[1]), Path(sys.argv[2])
    files = sorted(p for p in root.rglob("*") if p.is_file() and not p.name.endswith(SKIP))
    names = [p.relative_to(root).as_posix().encode() for p in files]
    order = sorted(range(len(files)), key=lambda i: names[i])  # byte order: matches strcmp
    blobs = []
    for i in order:
        raw = files[i].read_bytes()
        z = zlib.compress(raw, 9)
        blobs.append((names[i], z if len(z) < len(raw) else raw, len(raw)))
    index_bytes = sum(14 + len(n) for n, _, _ in blobs)
    off = 16 + index_bytes
    index, data = bytearray(), bytearray()
    for n, b, size in blobs:
        index += struct.pack("<IIIH", off + len(data), len(b), size, len(n)) + n
        data += b
    out.write_bytes(b"DDPK" + struct.pack("<III", 1, len(blobs), index_bytes) + index + data)
    raw = sum(s for _, _, s in blobs)
    print(f"{len(blobs)} files, {raw / 1e6:.1f} MB -> {out.stat().st_size / 1e6:.1f} MB")


if __name__ == "__main__":
    main()
