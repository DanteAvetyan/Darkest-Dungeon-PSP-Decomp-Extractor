#!/usr/bin/env python3
"""Decode Darkest Dungeon's binary "persist" format (magic 01 B1 00 00) used by maps/*.dm into
a nested dict. Value types are not stored, so they are guessed from size and shape:
1 byte -> bool/int, 4 bytes -> int (or float when the name says so), length-prefixed bytes ending
in NUL -> string, count-prefixed 4-byte runs -> list of ints.

Layout (as read from the files): a 64-byte header, then a table of objects (16 bytes each:
parent, field index, direct children, all children), then a table of fields (12 bytes each:
name hash, data offset, info), then the data block. Field info bit 0 = object, bits 2..10 =
name length including NUL, bits 11..30 = object index (bit 31 is a flag).

Usage: dm_decode.py file.dm [out.json]"""
import json
import struct
import sys

FLOAT_NAMES = {"x", "y", "z", "w", "light", "scale"}


# decode() walks the file structure described in the docstring: read the 64-byte header,
# then the object table and field table, slice each field's name and value out of the data
# block, guess its type from its size, and rebuild the nested dictionary (objects may nest).
def decode(blob):
    magic, _ver, hlen, _z, m1size, m1n, m1off = struct.unpack_from("<7I", blob, 0)
    assert magic == 0xB101, "not a persist file"
    m2n, m2off = struct.unpack_from("<2I", blob, 0x2C)
    dlen, doff = struct.unpack_from("<2I", blob, 0x38)
    objs = [struct.unpack_from("<4i", blob, m1off + 16 * i) for i in range(m1n)]
    fields = []
    for i in range(m2n):
        _h, off, info = struct.unpack_from("<iII", blob, m2off + 12 * i)
        fields.append(dict(off=off, is_obj=info & 1, nlen=(info >> 2) & 0x1FF, obj=(info >> 11) & 0xFFFFF))  # bit 31: flag
    data = blob[doff:doff + dlen]
    ends = sorted(f["off"] for f in fields) + [dlen]
    nxt = {ends[i]: ends[i + 1] for i in range(len(ends) - 1)}
    for f in fields:
        f["name"] = data[f["off"]:f["off"] + f["nlen"] - 1].decode("latin-1")
        f["vstart"] = f["off"] + f["nlen"]
        f["vend"] = nxt[f["off"]]

    def value(f):
        s, e = f["vstart"], f["vend"]
        n = e - s
        if n <= 1 or (n < 4 and n > 0 and data[s] in (0, 1) and all(b == 0 for b in data[s + 1:e])):
            return data[s] if n else None
        a = (s + 3) & ~3
        body = data[a:e]
        if len(body) >= 8 and body[4:8] == b"\x01\xb1\x00\x00":
            try:
                return decode(body[4:4 + struct.unpack_from("<i", body, 0)[0]])  # nested persist file
            except (IndexError, AssertionError, struct.error, KeyError):
                pass  # not a whole persist file after all: fall through to raw bytes
        if len(body) >= 4:
            first = struct.unpack_from("<i", body, 0)[0]
            # string: int length (incl NUL) + text
            if 0 < first <= len(body) - 4 and body[4 + first - 1] == 0 and len(body) - 4 - first < 4:
                txt = body[4:4 + first - 1]
                if all(32 <= c < 127 for c in txt):
                    return txt.decode("latin-1")
            if len(body) == 4 or len(body) < 8:
                if f["name"] in FLOAT_NAMES:
                    return round(struct.unpack_from("<f", body, 0)[0], 4)
                return first
            # list: count + count*4 bytes
            if first >= 0 and 4 + first * 4 <= len(body) and len(body) - (4 + first * 4) < 4:
                return list(struct.unpack_from("<%di" % first, body, 4))
            if len(body) == 8 and f["name"] in FLOAT_NAMES:
                return list(struct.unpack_from("<2f", body, 0))
        return body.hex()

    def build(oi):
        parent, fi, ndirect, _nall = objs[oi]
        out = {}
        # children of object oi are the fields that follow its field, skipping nested subtrees
        k = fi + 1 if fi >= 0 else 0
        got = 0
        while got < ndirect and k < len(fields):
            f = fields[k]
            if f["is_obj"]:
                out[f["name"]] = build(f["obj"])
                k += 1 + objs[f["obj"]][3]
            else:
                out[f["name"]] = value(f)
                k += 1
            got += 1
        return out

    return build(0)


if __name__ == "__main__":
    d = decode(open(sys.argv[1], "rb").read())
    s = json.dumps(d, indent=1)
    if len(sys.argv) > 2:
        open(sys.argv[2], "w").write(s)
    else:
        print(s)
