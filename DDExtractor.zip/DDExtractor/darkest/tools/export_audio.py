#!/usr/bin/env python3
"""FMOD banks -> PSP audio. Needs vgmstream-cli (VGMSTREAM env) and ffmpeg.
usage: export_audio.py <game_dir> <out_assets_dir>
 sfx   -> audio/sfx/<name>.ogg (mono 22050 vorbis, <=4s)
 music -> audio/music/<name>.ogg (mono 22050 vorbis)"""
import sys, os, glob, struct, subprocess, tempfile, shutil
game, out = sys.argv[1], sys.argv[2]
VGM = os.environ.get('DD_VGMSTREAM') or os.environ.get('VGMSTREAM') or 'vgmstream-cli'
FFMPEG = os.environ.get('DD_FFMPEG') or 'ffmpeg'
import wave
RATE = 22050
SKIP = {'voiceover_shared_courtyard', 'master_bank', 'music'}
import re
AMB = re.compile(r'^amb_(dun_[a-z0-9_]+_(base|dark)\d?|town\d?_[a-z_]+|local_campfire)$')
MUSIC_KEEP = ('Town_Stereo_Mix_LOOP_1', 'Camping_Stereo_Mix_LOOP_1', 'mus_theme_loop', 'mus_theme_intro_v2',
              'Mournweald_LEVEL1_LOOP1', 'Explore_Vaults_Level_1_Loop2', 'mus_combat_cove_lvl1_loop1',
              'mus_combat_dd_lvl1_loop1', 'Combat_Level1_Loop1', 'WARRENS_Combat_LOOP1_LEVEL1',
              'mus_combat_weald_hallway', 'mus_combat_dd_lvl2_loop1', 'Combat_Level2_Loop1')

def split(bank, tmp):
    """All SND chunks of a bank (each is an FSB5, maybe preceded by padding)."""
    d = open(bank, 'rb').read()
    out, pos, n = [], 12, 0
    while pos + 8 <= len(d):
        t, sz = struct.unpack('<4sI', d[pos:pos + 8])
        if t == b'SND ':
            c = d[pos + 8:pos + 8 + sz]
            i = c.find(b'FSB5')
            if i >= 0:
                p = os.path.join(tmp, 'x%d.fsb' % n); open(p, 'wb').write(c[i:]); out.append(p); n += 1
        pos += 8 + sz
    return out

def dump(fsb, tmp):
    wd = os.path.join(tmp, 'w'); shutil.rmtree(wd, True); os.makedirs(wd)
    subprocess.run([VGM, '-S', '0', '-o', wd + '/?n.wav', fsb], stdout=subprocess.DEVNULL,
                   stderr=subprocess.DEVNULL)
    return sorted(glob.glob(wd + '/*.wav'))

def wav_seconds(path):
    try:
        with wave.open(path) as wf:
            return wf.getnframes() / float(wf.getframerate())
    except Exception:
        return 0.0

def to_pcm(wav):
    r = subprocess.run([FFMPEG, '-v', 'error', '-i', wav, '-ac', '1', '-ar', str(RATE), '-f', 's16le', '-'],
                       capture_output=True)
    return r.stdout

sfxd = os.path.join(out, 'audio/sfx'); musd = os.path.join(out, 'audio/music')
vod = os.path.join(out, 'audio/voice'); os.makedirs(vod, exist_ok=True)
os.makedirs(sfxd, exist_ok=True); os.makedirs(musd, exist_ok=True)
tmp = tempfile.mkdtemp()
tot = 0
for bank in sorted(glob.glob(game + '/audio/*/*.bank')):
    name = os.path.basename(bank)[:-5]
    if name.endswith('.strings'): continue
    ismusic = name == 'music'
    if name in SKIP and not ismusic: continue
    for fsb in split(bank, tmp):
        for w in dump(fsb, tmp):
            base = os.path.basename(w)[:-4]
            if name == 'ambience':   # only the looping beds; one-shots are skipped
                if '_os' in base or not AMB.match(base): continue
                subprocess.run([FFMPEG, '-y', '-v', 'error', '-i', w, '-t', '90', '-ac', '1', '-ar', str(RATE), '-c:a',
                                'libvorbis', '-q:a', '-1', os.path.join(musd, base + '.ogg')])
            elif name == 'voiceover':   # narrator lines only
                if not base.startswith('vo_narr_') or 'volumeslider' in base: continue
                subprocess.run([FFMPEG, '-y', '-v', 'error', '-i', w, '-ac', '1', '-ar', str(RATE), '-c:a',
                                'libvorbis', '-q:a', '2', os.path.join(vod, base + '.ogg')])
                o = os.path.join(vod, base + '.ogg')   # long speeches (backstory, loading cards) are not wanted
                if wav_seconds(w) > 7.0: os.remove(o)
            elif ismusic:
                if not base.startswith(MUSIC_KEEP): continue
                subprocess.run([FFMPEG, '-y', '-v', 'error', '-i', w, '-ac', '1', '-ar', str(RATE), '-c:a',
                                'libvorbis', '-q:a', '1', os.path.join(musd, base + '.ogg')])
            else:
                if base.startswith('amb_') or os.path.getsize(w) > 4 * 48000 * 8 + 64: continue
                o = os.path.join(sfxd, base + '.ogg')
                subprocess.run([FFMPEG, '-y', '-v', 'error', '-i', w, '-t', '4', '-ac', '1', '-ar', str(RATE),
                                '-c:a', 'libvorbis', '-q:a', '0', o])
                tot += os.path.getsize(o)
    print(name, flush=True)
with open(os.path.join(out, 'audio/index.txt'), 'w') as f:
    for n in sorted(os.listdir(sfxd)): f.write('s ' + n[:-4] + '\n')
    for n in sorted(os.listdir(musd)): f.write('m ' + n[:-4] + '\n')
    for n in sorted(os.listdir(vod)): f.write('v ' + n[:-4] + '\n')
print('sfx bytes', tot)
if not os.listdir(sfxd) or not os.listdir(musd):
    sys.exit('no audio was produced: check the vgmstream-cli and ffmpeg (needs the libvorbis encoder) paths')
shutil.rmtree(tmp, True)
