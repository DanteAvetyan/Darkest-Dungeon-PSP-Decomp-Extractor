#!/usr/bin/env python3
"""Camping skill icons: raid/camping/skill_icons/camp_skill_<id>.png -> assets/camp/<id>.ddi (32x32).
Usage: export_camp.py <game_dir> <assets_dir>"""
import sys
from pathlib import Path

from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools"))
from export_ui import write_ddi  # noqa: E402
from pack_psp_atlas import resize_rgba  # noqa: E402


def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    game, out = Path(sys.argv[1]).expanduser(), Path(sys.argv[2])
    n = 0
    for p in sorted((game / "raid/camping/skill_icons").glob("camp_skill_*.png")):
        write_ddi(resize_rgba(Image.open(p).convert("RGBA"), (32, 32)), out / "camp" / (p.stem[len("camp_skill_"):] + ".ddi"))
        n += 1
    print("camp skill icons:", n)


if __name__ == "__main__":
    main()
