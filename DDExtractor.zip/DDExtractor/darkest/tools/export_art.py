#!/usr/bin/env python3
"""Convert every exported hero/monster Spine animation into one .dda file for the PSP runtime.

Usage: export_art.py <game_dir> <manifest.json> <out_dir> [--only name,...] [--preview]

For each sprite in the manifest (written by export_game_data.py) and each <name>.sprite.<anim>.skel:
  skel -> Spine JSON (SpineConverter 2.1.27) -> regions cropped, scaled, packed into one
  power-of-two page (max 512x512), quantized to 256 colours -> <out_dir>/<sprite>/<anim>.dda

Geometry is always scaled by WORLD_SCALE so every actor shares one world size; if the texture
does not fit in 512x512 at that scale, only the texture resolution is reduced (UVs are
normalised per region, so geometry is unaffected).

.dda layout (little endian; see src/core/spine.c for the reader):
  char magic[4] "DDA1"; u16 page_w, page_h; u16 bones, slots, attachments, timelines; f32 duration
  bones[]:   i16 parent; u8 flags(1=inheritScale,2=inheritRotation); u8 pad; f32 x,y,rot,sx,sy,length
  slots[]:   u16 bone; i16 setup_attachment; u8 r,g,b,a; u8 additive; u8 pad[3]
  attachments[]: u8 type(0 region,1 mesh,2 skinned); u8 pad; u16 slot; u16 verts; u16 tri_indices;
                 then region: f32 x,y,rot,sx,sy,w,h + 4x(f32 u,v) page pixels
                      mesh:   verts x (f32 x,y,u,v); tri_indices x u16
                      skinned: verts x (f32 u,v; u8 n; pad; n x (u16 bone; f32 x,y,w)); tri_indices x u16
  timelines[]: u8 kind(0 rotate,1 translate,2 scale,3 attachment,4 color,5 draw_order); u8 pad;
               u16 target; u16 keys; then keys x (f32 time; f32 v[4]; u8 curve(0 lin,1 step,2 bez);
               pad[3]; f32 bezier[4])
               attachment keys store v[0] = attachment index (-1 none); color keys v = r,g,b,a;
               draw_order keys store an offset into a trailing u16 slot-order table in v[0]
  u16 order_count; u16 order[order_count]
  u16 ik_count; ik[]: u16 parent_bone, child_bone (0xffff = one-bone), target_bone; i8 bend; u8 pad; f32 mix
  u16 ffd_count; ffd[]: u16 attachment, nkeys, nvals (2 per vertex for meshes, 2 per weight for
      skinned meshes); keys x (f32 time; u8 curve; pad[3]; f32 bezier[4]; u16 offset, count;
      f32 deltas[count])
  zero padding to a 16-byte boundary, then u8 clut[256*4] (RGBA)  u8 pixels[page_w*page_h]
"""
import json
import struct
import sys
from pathlib import Path

from PIL import Image

TOOLS = Path(__file__).resolve().parents[2] / "tools"
sys.path.insert(0, str(TOOLS))
import os
sys.path.insert(0, os.environ.get("DD_SPINE_CONVERTER") or str(TOOLS / "third_party" / "SpineConverter2.1.27"))
from convert_spine import parse_atlas  # noqa: E402
from pack_psp_atlas import crop_regions, quantize_rgba, resize_rgba, scale_skeleton  # noqa: E402
from spBinaryReader import spBinaryReader  # noqa: E402
from spJsonWriter import spJsonWriter  # noqa: E402

WORLD_SCALE = 0.3
MAX_PAGE = 512
PAD = 2
SKIP_ANIMS = {"heroic", "investigate", "town"}  # not used by the demake


# --------------------------------------------------------------------- helpers

# Use the bundled SpineConverter (Java-style binary reader/JSON writer ported to Python) to turn
# the game's binary .skel into Spine JSON, which is much easier to read from Python.
def to_json_dict(path, scratch):
    data = spBinaryReader().readSkeletonDataFile(str(path))
    spJsonWriter().writeSkeletonDataFile(data, str(scratch))
    return json.loads(scratch.read_text())


# PACKING = placing many small images (the character's body parts) into one big texture
# "atlas page" so the GPU needs only one texture per character. This is SHELF packing: sort
# by height, fill a row (shelf) left to right, start a new row when the width runs out.
def pack(sizes, page):
    """Shelf pack {key:(w,h)} into a page x page square; None if it doesn't fit."""
    order = sorted(sizes, key=lambda k: (-sizes[k][1], -sizes[k][0]))
    pos, x, y, shelf = {}, PAD, PAD, 0
    for k in order:
        w, h = sizes[k]
        if w + 2 * PAD > page:
            return None
        if x + w + PAD > page:
            x, y, shelf = PAD, y + shelf + PAD, 0
        if y + h + PAD > page:
            return None
        pos[k] = (x, y)
        x += w + PAD
        shelf = max(shelf, h)
    return pos, y + shelf + PAD


# Choose how big to make things: try the full scale, and for each scale try pages 64..512 px;
# if nothing fits shrink the texture scale by 10% and retry. (Geometry scale is fixed; only
# the texture resolution drops.) Also trims the page height to a smaller power of two.
def layout(regions, world_scale=WORLD_SCALE):
    """Pick the smallest page and the largest texture scale (<= world_scale) that fits."""
    tex_scale = world_scale
    while tex_scale > 0.05:
        sizes = {k: (max(1, round(im.width * tex_scale)), max(1, round(im.height * tex_scale)))
                 for k, im in regions.items()}
        for page in (64, 128, 256, 512):
            r = pack(sizes, page)
            if r:
                pos, used_h = r
                ph = page
                while ph // 2 >= used_h and ph > 16:  # trim height to a smaller power of two
                    ph //= 2
                return tex_scale, sizes, pos, page, ph
        tex_scale *= 0.9
    raise RuntimeError("regions do not fit")


# Spine keyframe interpolation: stepped (1), bezier with 4 control values (2), else linear (0).
# Matches SpKey.curve in spine.h.
def curve(key):
    c = key.get("curve")
    if c == "stepped":
        return 1, (0, 0, 1, 1)
    if isinstance(c, list) and len(c) == 4:
        return 2, tuple(float(v) for v in c)
    return 0, (0, 0, 1, 1)


# --------------------------------------------------------------------- writer

# Serialises the parsed skeleton + atlas rects into the binary .dda format that spine.c reads
# (field order here mirrors parse() in spine.c exactly).
class DdaWriter:
    def __init__(self, skel, rects, page_w, page_h):
        self.s = skel
        self.rects = rects
        self.pw, self.ph = page_w, page_h
        self.bone_idx = {b["name"]: i for i, b in enumerate(skel["bones"])}
        self.slot_idx = {s["name"]: i for i, s in enumerate(skel["slots"])}
        self.atts, self.att_idx = [], {}
        skin = skel["skins"].get("default", {})
        for slot in skel["slots"]:
            for name, a in skin.get(slot["name"], {}).items():
                self.att_idx[(slot["name"], name)] = len(self.atts)
                self.atts.append((slot["name"], name, a))

    def region_uv(self, path):
        x, y, w, h = self.rects[path]
        return x, y, w, h

    def bones(self):
        out = b""
        for b in self.s["bones"]:
            flags = (1 if b.get("inheritScale", True) else 0) | (2 if b.get("inheritRotation", True) else 0)
            out += struct.pack("<hBB6f", self.bone_idx.get(b.get("parent"), -1), flags, 0,
                               b.get("x", 0), b.get("y", 0), b.get("rotation", 0),
                               b.get("scaleX", 1), b.get("scaleY", 1), b.get("length", 0))
        return out

    def slots(self):
        out = b""
        for s in self.s["slots"]:
            col = s.get("color", "ffffffff")
            r, g, b_, a = (int(col[i:i + 2], 16) for i in (0, 2, 4, 6))
            att = self.att_idx.get((s["name"], s.get("attachment")), -1) if s.get("attachment") else -1
            out += struct.pack("<HhBBBBB3x", self.bone_idx[s["bone"]], att, r, g, b_, a,
                               1 if s.get("additive") else 0)
        return out

    def attachments(self):
        out = b""
        for slot, name, a in self.atts:
            t = a.get("type", "region")
            rx, ry, rw, rh = self.region_uv(a.get("path", name))
            si = self.slot_idx[slot]
            if t == "region":
                # corners in the order the runtime emits them: BL, BR, TR, TL (v grows downward)
                uvs = [(rx, ry + rh), (rx + rw, ry + rh), (rx + rw, ry), (rx, ry)]
                out += struct.pack("<BBHHH", 0, 0, si, 4, 0)
                out += struct.pack("<7f", a.get("x", 0), a.get("y", 0), a.get("rotation", 0),
                                   a.get("scaleX", 1), a.get("scaleY", 1), a["width"], a["height"])
                for u, v in uvs:
                    out += struct.pack("<2f", u, v)
                continue
            uv = a["uvs"]
            n = len(uv) // 2
            tris = a["triangles"]
            out += struct.pack("<BBHHH", 1 if t == "mesh" else 2, 0, si, n, len(tris))
            v = a["vertices"]
            if t == "mesh":
                for i in range(n):
                    out += struct.pack("<4f", v[2 * i], v[2 * i + 1],
                                       rx + uv[2 * i] * rw, ry + uv[2 * i + 1] * rh)
            else:
                j = 0
                for i in range(n):
                    cnt = int(v[j]); j += 1
                    out += struct.pack("<2fBx", rx + uv[2 * i] * rw, ry + uv[2 * i + 1] * rh, cnt)
                    for _ in range(cnt):
                        out += struct.pack("<H3f", int(v[j]), v[j + 1], v[j + 2], v[j + 3])
                        j += 4
            out += struct.pack(f"<{len(tris)}H", *tris)
        return out

    def timelines(self, anim):
        out, count, duration = b"", 0, 0.0
        order_table = []

        def keys_blob(keys, values):
            nonlocal duration
            blob = b""
            for k in keys:
                duration = max(duration, k.get("time", 0))
                ct, bz = curve(k)
                vals = (list(values(k)) + [0, 0, 0, 0])[:4]
                blob += struct.pack("<f4fB3x4f", k.get("time", 0), *vals, ct, *bz)
            return blob

        for bname, tl in anim.get("bones", {}).items():
            bi = self.bone_idx.get(bname)
            if bi is None:
                continue
            for kind, name, fn in ((0, "rotate", lambda k: (k.get("angle", 0),)),
                                   (1, "translate", lambda k: (k.get("x", 0), k.get("y", 0))),
                                   (2, "scale", lambda k: (k.get("x", 1), k.get("y", 1)))):
                keys = tl.get(name)
                if keys:
                    out += struct.pack("<BxHH", kind, bi, len(keys)) + keys_blob(keys, fn)
                    count += 1
        for sname, tl in anim.get("slots", {}).items():
            si = self.slot_idx.get(sname)
            if si is None:
                continue
            if tl.get("attachment"):
                keys = tl["attachment"]
                fn = lambda k, s=sname: (self.att_idx.get((s, k.get("name")), -1) if k.get("name") else -1,)
                out += struct.pack("<BxHH", 3, si, len(keys)) + keys_blob(keys, fn)
                count += 1
            if tl.get("color"):
                keys = tl["color"]
                fn = lambda k: tuple(int(k.get("color", "ffffffff")[i:i + 2], 16) / 255 for i in (0, 2, 4, 6))
                out += struct.pack("<BxHH", 4, si, len(keys)) + keys_blob(keys, fn)
                count += 1
        dorder = anim.get("drawOrder") or anim.get("draworder")
        if dorder:
            nslots = len(self.s["slots"])

            def order_of(k):
                order = list(range(nslots))
                offs = k.get("offsets")
                if offs:
                    order = [-1] * nslots
                    unchanged = []
                    orig = 0
                    for o in offs:
                        si = self.slot_idx[o["slot"]]
                        while orig != si:
                            unchanged.append(orig); orig += 1
                        order[orig + o["offset"]] = orig
                        orig += 1
                    while orig < nslots:
                        unchanged.append(orig); orig += 1
                    ui = len(unchanged) - 1
                    for i in range(nslots - 1, -1, -1):
                        if order[i] == -1:
                            order[i] = unchanged[ui]; ui -= 1
                start = len(order_table)
                order_table.extend(order)
                return (start,)
            out += struct.pack("<BxHH", 5, 0, len(dorder)) + keys_blob(dorder, order_of)
            count += 1
        return out, count, duration, order_table

    def ik(self):
        out, n = b"", 0
        for c in self.s.get("ik", []) or []:
            bones = [self.bone_idx[b] for b in c["bones"]]
            out += struct.pack("<HHHbxf", bones[0], bones[1] if len(bones) > 1 else 0xFFFF,
                               self.bone_idx[c["target"]], 1 if c.get("bendPositive", True) else -1,
                               float(c.get("mix", 1)))
            n += 1
        return struct.pack("<H", n) + out

    def ffd(self, anim):
        out, n = b"", 0
        for skin in (anim.get("ffd") or {}).values():
            for slot, atts in skin.items():
                for name, keys in atts.items():
                    ai = self.att_idx.get((slot, name))
                    if ai is None:
                        continue
                    a = self.atts[ai][2]
                    if a.get("type") == "skinnedmesh":
                        v, j, nvals = a["vertices"], 0, 0
                        while j < len(v):
                            cnt = int(v[j]); nvals += 2 * cnt; j += 1 + 4 * cnt
                    else:
                        nvals = len(a["uvs"])
                    blob = b""
                    for k in keys:
                        ct, bz = curve(k)
                        vals = k.get("vertices") or []
                        blob += struct.pack("<fB3x4fHH", k.get("time", 0), ct, *bz,
                                            int(k.get("offset", 0)), len(vals))
                        blob += struct.pack(f"<{len(vals)}f", *vals)
                    out += struct.pack("<HHH", ai, len(keys), nvals) + blob
                    n += 1
        return struct.pack("<H", n) + out

    def write(self, path, anim_name, clut, pixels):
        anims = self.s.get("animations", {})
        # an empty animation (a static pose, e.g. most "defend" files) is still the one asked for;
        # falling back to the first one would play that file's "death" fade instead
        anim = anims[anim_name] if anim_name in anims else next(iter(anims.values()), {})
        tl, tl_count, duration, order_table = self.timelines(anim)
        for skin in (anim.get("ffd") or {}).values():
            for atts in skin.values():
                for keys in atts.values():
                    duration = max([duration] + [k.get("time", 0) for k in keys])
        head = struct.pack("<4sHHHHHHf", b"DDA1", self.pw, self.ph, len(self.s["bones"]),
                           len(self.s["slots"]), len(self.atts), tl_count, duration)
        body = self.bones() + self.slots() + self.attachments() + tl
        body += struct.pack(f"<H{len(order_table)}H", len(order_table), *order_table)
        body += self.ik() + self.ffd(anim)
        # pad so the CLUT and pixels start 16-byte aligned: the PSP GE can then texture
        # straight from the loaded file without a copy
        pad = (-(len(head) + len(body))) % 16
        path.write_bytes(head + body + b"\0" * pad + bytes(clut) + pixels)


# --------------------------------------------------------------------- main

# Convert ONE animation file: skel -> JSON, crop/pack its regions into a page, quantize to 256
# colours (palette + index image), scale the skeleton, and write the .dda. Returns stats and
# any Spine features used (so we notice ones the runtime doesn't support).
def export_anim(skel_path, atlas_path, png_dir, out_path, scratch, preview_dir=None, world_scale=WORLD_SCALE, anim=None):
    skel = to_json_dict(skel_path, scratch)
    if anim and anim not in skel.get("animations", {}):
        skel.setdefault("animations", {})[anim] = {}  # asked for but missing: the still setup pose
    pages = parse_atlas(atlas_path)
    regions = crop_regions(pages, png_dir)
    tex_scale, sizes, pos, pw, ph = layout(regions, world_scale)
    page = Image.new("RGBA", (pw, ph), (0, 0, 0, 0))
    for k, (x, y) in pos.items():
        page.paste(resize_rgba(regions[k], sizes[k]), (x, y))
    q, pal = quantize_rgba(page)
    rects = {k: (pos[k][0], pos[k][1], sizes[k][0], sizes[k][1]) for k in pos}
    scaled = scale_skeleton(skel, world_scale)
    anim_name = anim or skel_path.name.split(".")[-2]
    DdaWriter(scaled, rects, pw, ph).write(out_path, anim_name, pal, q.tobytes())
    if preview_dir:
        q.convert("RGBA").save(preview_dir / f"{out_path.stem}.page.png")
    feats = set()
    for a in skel.get("animations", {}).values():
        for key in ("ffd", "events", "drawOrder", "draworder"):
            if a.get(key):
                feats.add(key)
    if skel.get("ik"):
        feats.add("ik")
    return tex_scale, pw, ph, feats


# Command line driver: loops over the manifest's sprites and animations.
def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if len(args) != 3:
        sys.exit(__doc__)
    game, manifest, out = Path(args[0]).expanduser(), json.loads(Path(args[1]).read_text()), Path(args[2])
    only = None
    for a in sys.argv:
        if a.startswith("--only="):
            only = set(a.split("=", 1)[1].split(","))
    preview = "--preview" in sys.argv
    scratch = out / ".scratch.json"
    out.mkdir(parents=True, exist_ok=True)
    total, feats_seen, low_res = 0, {}, []
    for kind in ("heroes", "monsters"):
        for spr in manifest[kind]:
            if only and spr["id"] not in only:
                continue
            anim_dir, png_dir = game / spr["anim_dir"], game / spr["png_dir"]
            dst = out / spr["id"]
            dst.mkdir(parents=True, exist_ok=True)
            for skel_path in sorted(anim_dir.glob("*.skel")):
                anim = skel_path.name.split(".")[-2]
                if anim in SKIP_ANIMS:
                    continue
                atlas = skel_path.with_suffix(".atlas")
                try:
                    ts, pw, ph, feats = export_anim(skel_path, atlas, png_dir, dst / f"{anim}.dda",
                                                    scratch, dst if preview else None)
                except Exception as e:  # report and keep going; one broken anim shouldn't stop the batch
                    print(f"  FAILED {spr['id']}/{anim}: {e}")
                    continue
                total += 1
                for f in feats:
                    feats_seen.setdefault(f, []).append(f"{spr['id']}/{anim}")
                if ts < WORLD_SCALE - 1e-6:
                    low_res.append(f"{spr['id']}/{anim}@{ts:.2f}")
            print(f"{spr['id']}: {len(list(dst.glob('*.dda')))} anims")
    scratch.unlink(missing_ok=True)
    print(f"total {total} animations")
    for f, where in feats_seen.items():
        print(f"feature '{f}' used by {len(where)}: {where[:6]}")
    if low_res:
        print(f"reduced texture scale for {len(low_res)}: {low_res[:10]}")


if __name__ == "__main__":
    main()
