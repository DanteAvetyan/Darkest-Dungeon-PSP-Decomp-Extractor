#!/usr/bin/env python3
"""Export Darkest Dungeon game data into C tables for the PSP demake.

Usage: export_game_data.py <game_dir> <out_dir>
Writes <out_dir>/dd_data.c (types in src/core/dd_types.h) and <out_dir>/manifest.json
(the hero/monster sprite list used by export_art.py).

HOW THIS SCRIPT WORKS (read this first)
---------------------------------------
The original game stores its rules as text: ".darkest" files (a "key: .field value" format),
JSON and CSV. The PSP game cannot parse those at runtime, so this script converts them ahead
of time into C source code: big constant arrays (see src/core/dd_types.h for the struct each
array holds).

The design is a single Exporter object that collects rows into Python lists:
  * shared pools that rows point into by index - buffs, effects, effect ops, skills ...
  * one list per table - heroes, monsters, brains, encounters, curios, quirks ...
Methods like hero()/monster()/curios() read game files and append rows. Many things are
"interned": effect("stun") returns the index of that effect, adding it the first time it is
requested, so the same effect is never duplicated. Variable-length lists are stored FLAT:
a row records (first_index, count) into a shared array instead of owning a Python list.
Finally Exporter.write() turns every list into C text in extracted/gen/dd_data.c, and the
manifest.json lists which sprites export_art.py must convert.

Adding a data field = (1) read it in the right Exporter method, (2) emit it in write(),
(3) add the field to the struct in dd_types.h (same order!).

The output is derived from the user's own game files: keep it in the gitignored extracted/ tree.

Left out on purpose (the user's own exercise): the Plague Doctor class. Its skills and art are
not exported; see docs/your_turn.md.
"""
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools"))
from extract_units import parse_darkest, parse_value  # noqa: E402

HEROES = ["crusader", "highwayman", "vestal", "occultist", "grave_robber", "bounty_hunter",
          "hellion", "leper", "man_at_arms", "jester", "houndmaster", "arbalest", "antiquarian",
          "abomination", "plague_doctor"]
EXCLUDED_HEROES = set()

DUNGEONS = [("ruins", "crypts", "The Ruins"), ("weald", "weald", "The Weald"),
            ("warrens", "warrens", "The Warrens"), ("cove", "cove", "The Cove"),
            ("darkest", "darkestdungeon", "The Darkest Dungeon")]  # DG_DARKEST: plot quests only
LEVELS = [1, 3, 5, 6]  # 6 = the Darkest Dungeon's own mash

RES_KEYS = ["stun", "poison", "bleed", "disease", "move", "debuff", "death_blow", "trap"]
MT = {"man": 0, "beast": 1, "unholy": 2, "eldritch": 3, "corpse": 4, "cauldron": 5, "cosmic": 6,
      "carpentry": 7, "thatchery": 7, "stonework": 7, "ironwork": 7}
SKILL_TYPE = {"melee": 0, "ranged": 1, "move": 2, "teleport": 5}  # 5 = SK_TELEPORT (White Cell Stalk)
TARGET = {"target": 0, "performer": 1, "global": 2, "performer_group_other": 3, "target_group": 4}

STAT_SUB = {"attack_rating": 1, "defense_rating": 2, "protection_rating": 3, "speed_rating": 4,
            "crit_chance": 5, "damage_low": 6, "damage_high": 7, "max_hp": 8}
RES_SUB = {"stun": 0, "poison": 1, "bleed": 2, "disease": 3, "move": 4, "debuff": 5,
           "death_blow": 6, "trap": 7}
STAT_RES, STAT_HEAL_RECEIVED, STAT_CRIT_RECEIVED, STAT_STRESS_RECEIVED = 9, 10, 11, 12
STAT_STRESS_HEAL_RECEIVED, STAT_FOOD = 13, 14
STAT_RESOLVE, STAT_HEAL_DEALT, STAT_EFFECT_CHANCE, STAT_SURPRISE, STAT_DMG_RECEIVED = 15, 16, 17, 18, 19
STAT_SCOUTING = 20
# <x>_chance trinket buffs raise the wearer's skill effect chance (sub = DDResist it fights)
EFFECT_CHANCE = {"stun_chance": 0, "poison_chance": 1, "bleed_chance": 2, "move_chance": 4, "debuff_chance": 5}
TRINKET_RARITIES = ["very_common", "common", "uncommon", "rare", "very_rare", "ancestral", "trophy", "crow",
                    "ancestral_shambler", "madman", "collector", "courtier", "darkest_dungeon"]
# buff rule_type -> DDBuffRule (dd_types.h)
RULES = {"always": 0, "in_dungeon": 1, "monsterType": 2, "monster_type_count_min": 3, "lightabove": 4,
         "lightbelow": 5, "hpbelow": 6, "firstroundonly": 7, "rangedonly": 8, "meleeonly": 9, "in_camp": 10,
         "in_activity": 11, "stress_above": 12, "in_corridor": 13, "walking_backwards": 14,
         "hpabove": 16, "at_deaths_door": 17, "in_rank": 18, "skill": 19}
DUR = {"combat_end": 1, "quest_end": 2, "activity_end": 3}

# effect field -> (op name, how to read the value)
SIMPLE_OPS = {
    "dotStress": "OP_HORROR",
    "kill_enemy_types": "OP_CLEAR_CORPSES",  # only "corpse" in the data (Purge, Disorienting Blast, Abyssal Artillery)
    "stun": "OP_STUN", "unstun": "OP_UNSTUN", "dotBleed": "OP_BLEED", "dotPoison": "OP_BLIGHT",
    "cure": "OP_CURE", "cure_bleed": "OP_CURE_BLEED", "cure_poison": "OP_CURE_BLIGHT",
    "heal": "OP_HEAL", "stress": "OP_STRESS", "healstress": "OP_HEAL_STRESS", "kill": "OP_KILL",
    "push": "OP_PUSH", "pull": "OP_PULL", "shuffletarget": "OP_SHUFFLE_TARGET",
    "shuffleparty": "OP_SHUFFLE_PARTY", "immobilize": "OP_IMMOBILIZE",
    "unimmobilize": "OP_UNIMMOBILIZE", "tag": "OP_MARK", "untag": "OP_UNMARK",
    "guard": "OP_GUARD", "clearguarding": "OP_CLEAR_GUARDING", "clearguarded": "OP_CLEAR_GUARDED",
    "riposte": "OP_RIPOSTE", "stealth": "OP_STEALTH", "unstealth": "OP_UNSTEALTH",
    "clear_debuff": "OP_CLEAR_DEBUFF", "torch_increase": "OP_TORCH_INC",
    "torch_decrease": "OP_TORCH_DEC", "capture": "OP_CAPTURE", "control": "OP_CONTROL",
}
# temporary stat changes carried by an effect (combat_stat_buff style)
STAT_OPS = {
    "attack_rating_add": ("OP_STAT_ADD", 1), "defense_rating_add": ("OP_STAT_ADD", 2),
    "protection_rating_add": ("OP_STAT_ADD", 3), "speed_rating_add": ("OP_STAT_ADD", 4),
    "speed_rating": ("OP_STAT_ADD", 4), "crit_chance_add": ("OP_STAT_ADD", 5),
    "critical_rating": ("OP_STAT_ADD", 5),
    "damage_low_add": ("OP_STAT_ADD", 6), "damage_high_add": ("OP_STAT_ADD", 7),
    "damage_low_multiply": ("OP_STAT_MUL", 6), "damage_high_multiply": ("OP_STAT_MUL", 7),
}


# ---- tiny C-literal helpers used by write() ---------------------------------------------
def c_str(s):
    return "NULL" if s is None else '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'


# C float literal with a fixed format, e.g. 0.5 -> 0.5000f. None/empty -> 0.
def c_float(v):
    return f"{float(v or 0):.4f}f"


# The game's parser returns a single value or a list; normalise to a list.
def as_list(v):
    return [] if v is None else v if isinstance(v, list) else [v]


# Convert a rank string like "1,2" or "~3,4" or "@1,2" into a C DDRanks initializer.
# digits 1-4 set bits 0-3 of `mask`; '~' (hit all ranks at once) = flag 1; '@' (own side) =
# flag 2; an empty target string means "performer only" (flag 4).
def ranks(value, empty_is_self=False):
    s = "" if value is None else str(value)
    mask = 0
    for ch in s:
        if ch.isdigit() and 1 <= int(ch) <= 4:
            mask |= 1 << (int(ch) - 1)
    flags = (1 if "~" in s else 0) | (2 if "@" in s else 0)
    if empty_is_self and value is None:
        flags |= 4
    return f"{{0x{mask:x}, {flags}}}"


# Localisation: reads the English string tables so names/descriptions can be embedded.
class Strings:
    def __init__(self, game):
        self.t, self.all = {}, {}
        for f in (game / "localization").glob("*.string_table.xml"):
            try:
                root = ET.parse(f).getroot()
            except ET.ParseError:
                continue
            for lang in root.iter("language"):
                if lang.get("id") != "english":
                    continue
                for e in lang.iter("entry"):
                    self.t.setdefault(e.get("id"), (e.text or "").strip())
                    self.all.setdefault(e.get("id"), []).append((e.text or "").strip())

    def get(self, key, fallback):
        v = self.t.get(key)
        return v if v else fallback.replace("_", " ").title()


# Collects every table; see the module docstring.
class Exporter:
    def __init__(self, game):
        self.game = game
        self.str = Strings(game)
        self.buffs, self.buff_index = [], {}
        self.buff_list = []
        self.eff_ops, self.effects, self.effect_index = [], [], {}
        self.skill_effects, self.skills = [], []
        self.heroes, self.monsters, self.monster_index = [], [], {}
        self.brains, self.brain_index = [], {}
        self.skill_desires, self.target_desires, self.bonus_desires = [], [], []
        self.shared_ids = {}
        self.encounters = []
        self.tutorial_enc = []  # dd_enc_tutorial: weald "named" tutorial_1 (hall), tutorial_2 (room)
        self.named_enc = {}  # Darkest Dungeon mash name -> encounter index
        self.missing_effects = set()
        self.unsupported_fields = {}
        self.manifest = {"heroes": [], "monsters": []}
        self._load_buffs()
        self._load_effects()
        self._brain_json = {b["id"]: b for b in json.loads(
            (game / "raid/ai/base.monster_brains.json").read_text())["monster_brains"]}

    # ------------------------------------------------------------ buffs / effects
    # Read the shared buff library (stat modifiers) and classify each by stat/sub-stat/mode.
    def _load_buffs(self):
        for f in [self.game / "shared/buffs/base.buffs.json", self.game / "shared/buffs/non_exported.buffs.json"]:
            for b in json.loads(f.read_text())["buffs"]:
                st, sub = b.get("stat_type", ""), b.get("stat_sub_type", "")
                stat, sub_i, mode = 0, 0, 0
                if st in ("combat_stat_add", "combat_stat_multiply"):
                    stat, mode = STAT_SUB.get(sub, 0), int(st.endswith("multiply"))
                elif st == "resistance":
                    stat, sub_i = STAT_RES, RES_SUB.get(sub, 0)
                elif st == "hp_heal_received_percent":
                    stat = STAT_HEAL_RECEIVED
                elif st == "crit_received_chance":
                    stat = STAT_CRIT_RECEIVED
                elif st == "stress_dmg_received_percent":
                    stat = STAT_STRESS_RECEIVED
                elif st == "stress_heal_received_percent":
                    stat = STAT_STRESS_HEAL_RECEIVED
                elif st == "food_consumption_percent":
                    stat = STAT_FOOD
                elif st == "resolve_check_percent":
                    stat = STAT_RESOLVE
                elif st == "hp_heal_percent":
                    stat = STAT_HEAL_DEALT
                elif st in EFFECT_CHANCE:
                    stat, sub_i = STAT_EFFECT_CHANCE, EFFECT_CHANCE[st]
                elif st == "damage_received_percent":
                    stat = STAT_DMG_RECEIVED
                elif st == "scouting_chance":
                    stat = STAT_SCOUTING
                elif st in ("party_surprise_chance", "monsters_surprise_chance"):
                    stat, sub_i = STAT_SURPRISE, int(st.startswith("monsters"))
                if b["id"] in self.buff_index:
                    continue
                rd = b.get("rule_data") or {}
                rule = RULES.get(b.get("rule_type", "always"), 15)
                ri = MT.get(str(rd.get("string", "")), -1) if rule in (2, 3) else -1
                self.buff_index[b["id"]] = len(self.buffs)
                self.buffs.append((b["id"], stat, sub_i, mode, DUR.get(b.get("duration_type"), 0),
                                   int(b.get("duration", 0) or 0), float(b.get("amount", 0)), rule,
                                   float(rd.get("float", 0) or 0), ri, int(bool(b.get("is_false_rule"))),
                                   str(rd.get("string")) if rule == 19 else None))

    # Read raw effect definitions by name; they are converted lazily by effect().
    def _load_effects(self):
        self._effect_src = {}
        for f in [self.game / "effects/base.effects.darkest"]:
            for k, e in parse_darkest(f):
                if k == "effect" and isinstance(e.get("name"), str):
                    self._effect_src.setdefault(e["name"], e)

    def effect(self, name):
        """Index of an effect, exporting it on first use."""
        if name in self.effect_index:
            return self.effect_index[name]
        e = self._effect_src.get(name)
        if e is None:
            self.missing_effects.add(name)
            return None
        ops = []
        for key, val in e.items():
            if key in SIMPLE_OPS:
                v = val if not isinstance(val, list) else val[0]
                v = 1.0 if v is True else float(v) if isinstance(v, (int, float)) else 1.0
                ops.append((SIMPLE_OPS[key], 0, v))
            elif key in STAT_OPS:
                op, stat = STAT_OPS[key]
                ops.append((op, stat, float(val[0] if isinstance(val, list) else val)))
            elif key == "buff_ids":
                for bid in as_list(val):
                    if bid in self.buff_index:
                        ops.append(("OP_BUFF", self.buff_index[bid], 0.0))
            elif key == "disease":  # "any" = a random disease, else a quirk id
                if not hasattr(self, "_quirk_ids"):
                    ql = json.loads((self.game / "shared/quirk/quirk_library.json").read_text())["quirks"]
                    self._quirk_ids = {x["id"]: i for i, x in enumerate(ql)}
                ops.append(("OP_DISEASE", self._quirk_ids.get(str(val), -1), 1.0))
            elif key == "summon_monsters":
                chances = as_list(e.get("summon_chances")) or [1] * len(as_list(val))
                for mid, ch in zip(as_list(val), chances):
                    idx = self.monster(str(mid))
                    if idx is not None:
                        ops.append(("OP_SUMMON", idx, float(ch)))
            elif key not in ("name", "target", "chance", "on_hit", "on_miss", "queue", "duration",
                             "can_apply_on_death", "apply_once", "swap_source_and_target",
                             "curio_result_type", "monsterType", "combat_stat_buff", "keyStatus",
                             "has_description", "buff_duration_type", "buff_type", "buff_amount",
                             "buff_source_type", "summon_chances", "summon_count", "summon_ranks",
                             "summon_limits", "summon_does_roll_initiatives", "riposte_effect",
                             "riposte_on_hit_chance_add", "riposte_on_miss_chance_add",
                             "summon_can_spawn_loot", "curio", "crit_doesnt_apply_to_roll", "source_heal_type", "virtue_blockable_chance"):  # curio: marks curio-only effects
                self.unsupported_fields[key] = self.unsupported_fields.get(key, 0) + 1
        flags = 0
        flags |= 1 if e.get("on_hit", True) else 0
        flags |= 2 if e.get("on_miss", False) else 0
        flags |= 4 if e.get("queue", False) else 0
        flags |= 8 if e.get("can_apply_on_death", False) else 0
        flags |= 16 if e.get("apply_once", False) else 0
        flags |= 32 if e.get("swap_source_and_target", False) else 0
        flags |= 64 if e.get("curio_result_type") == "negative" else 0
        flags |= 128 if e.get("buff_duration_type") == "combat_end" else 0
        mtypes = 0
        for t in as_list(e.get("monsterType")):
            mtypes |= 1 << MT.get(str(t), 0)
        idx = len(self.effects)
        self.effect_index[name] = idx
        ks = {"tagged": 1, "poisoned": 2, "stunned": 3, "bleeding": 4}.get(e.get("keyStatus"), 0)
        has_dur = "duration" in e
        instant = (e.get("target") == "performer" and e.get("combat_stat_buff")
                   and e.get("buff_duration_type") != "combat_end"
                   and (not has_dur or ks or mtypes))
        flags2 = (1 if instant else 0) | (2 if has_dur else 0)
        flags2 |= 4 if e.get("summon_can_spawn_loot") is False else 0  # EF2_SUMMON_NO_LOOT
        flags2 |= 8 if e.get("crit_doesnt_apply_to_roll") in (True, "True", "true") else 0  # EF2_NO_CRIT_ROLL
        flags2 |= 16 if e.get("source_heal_type") == "hero_skill" else 0  # EF2_HEAL_CAN_CRIT
        flags2 |= 32 if e.get("virtue_blockable_chance") else 0  # EF2_VIRTUE_BLOCKS (always 100% in the data)
        self.effects.append((name, TARGET.get(e.get("target"), 0), flags, mtypes, ks, flags2,
                             int(e.get("duration", 3) if e.get("duration") is not None else 3),
                             float(e.get("chance", 1.0) if not isinstance(e.get("chance"), list) else 1.0),
                             len(self.eff_ops), len(ops), int(e.get("summon_count", 1) or 1)))
        self.eff_ops += ops
        return idx

    def effect_span(self, names):
        # resolve first: exporting an effect can recurse (summons export monsters and their
        # skills), and each span must stay contiguous
        idx = [self.effect(str(n)) for n in names]
        first = len(self.skill_effects)
        self.skill_effects += [i for i in idx if i is not None]
        return first, len(self.skill_effects) - first

    # ------------------------------------------------------------ skills
    # Convert one skill definition (hero or monster) to a skill row and link its effects.
    def add_skill(self, f, name, anim, level, is_monster):
        stype = SKILL_TYPE.get(f.get("type"), 0)
        if f.get("heal") is not None:
            stype = 3
        elif f.get("type") is None and stype == 0:
            stype = 4
        if f.get("atk") in (0, 0.0) and f.get("dmg") in (0, 0.0) and stype == 0 and not is_monster:
            stype = 4  # buff skills such as Bulwark of Faith
        flags = 0
        flags |= 1 if f.get("is_crit_valid", is_monster) not in (False, "False") else 0
        flags |= 2 if f.get("ignore_protection") else 0
        flags |= 4 if f.get("ignore_stealth") else 0
        flags |= 8 if f.get("ignore_guard") else 0
        flags |= 16 if f.get("self_target_valid") else 0
        flags |= 32 if f.get("can_miss") in (False, "False") else 0
        flags |= 64 if f.get("is_continue_turn") else 0
        flags |= 128 if f.get("is_stall_invalidating") in (False, "False", "false") else 0  # SKF_NO_STALL_RESET
        dmg = f.get("dmg")
        dlo = dhi = 0
        dmg_mod = 0.0
        if is_monster and isinstance(dmg, list):
            dlo, dhi = int(dmg[0]), int(dmg[1])
        elif isinstance(dmg, (int, float)):
            dmg_mod = float(dmg)
        heal = as_list(f.get("heal"))
        mv = as_list(f.get("move"))
        eff_first, eff_count = self.effect_span(as_list(f.get("effect")))
        self.skills.append(dict(
            id=f["id"], name=name, anim=anim, type=stype, level=int(f.get("level", 0) or 0),
            flags=flags, limit=int(f.get("per_battle_limit", -1) or -1),
            atk=f.get("atk", 0) or 0, dmg_mod=dmg_mod, crit=f.get("crit", 0) or 0,
            dlo=dlo, dhi=dhi, hlo=int(heal[0]) if heal else 0, hhi=int(heal[-1]) if heal else 0,
            mb=int(mv[0]) if mv else 0, mf=int(mv[1]) if len(mv) > 1 else 0,
            launch=ranks(f.get("launch")),
            target=ranks(f.get("target"), empty_is_self=stype in (3, 4) or f.get("target") is None),
            xt=int(f.get("extra_targets_count", 0) or 0), xtc=f.get("extra_targets_chance", 0) or 0,
            eff_first=eff_first, eff_count=eff_count))
        return len(self.skills) - 1

    # ------------------------------------------------------------ heroes
    # Export one hero class: stats per equipment level, resistances, skills, death's door buffs.
    def hero(self, cls):
        assert cls not in EXCLUDED_HEROES
        d = self.game / "heroes" / cls
        info = parse_darkest(d / f"{cls}.info.darkest")
        art_recs = [(k, f) for k, f in parse_darkest(d / f"{cls}.art.darkest") if "id" in f]
        art = {f["id"]: f.get("anim") for k, f in art_recs
               if k in ("combat_skill", "riposte_skill", "combat_move_skill")}
        icon_words = ["one", "two", "three", "four", "five", "six", "seven"]
        icon_of = {f["id"]: icon_words.index(f.get("icon")) for k, f in art_recs
                   if k == "combat_skill" and f.get("icon") in icon_words}
        h = dict(id=cls, name=self.str.get(f"hero_class_name_{cls}", cls), res=[0] * 8,
                 weapons=[], armours=[], tags=0, move=-1, riposte=-1)
        by_id = {}
        crit_effects, dd_buffs, dd_rec, ha_rec = [], [], [], []
        for k, f in info:
            if k == "resistances":
                h["res"] = [float(f.get(r, 0) or 0) for r in RES_KEYS]
            elif k == "weapon":
                dmg = as_list(f.get("dmg")) or [0, 0]
                h["weapons"].append((f.get("atk", 0) or 0, f.get("crit", 0) or 0,
                                     int(dmg[0]), int(dmg[-1]), int(f.get("spd", 0) or 0)))
            elif k == "armour":
                h["armours"].append((f.get("def", 0) or 0, f.get("prot", 0) or 0,
                                     int(f.get("hp", 0) or 0), int(f.get("spd", 0) or 0)))
            elif k == "combat_skill":
                by_id.setdefault(f["id"], []).append(f)
            elif k == "combat_move_skill":
                h["move_src"] = f
            elif k == "riposte_skill":
                h["riposte_src"] = f
            elif k == "crit":
                crit_effects = as_list(f.get("effects"))
            elif k == "deaths_door":
                dd_buffs = as_list(f.get("buffs"))
                dd_rec = as_list(f.get("recovery_buffs"))
                ha_rec = as_list(f.get("recovery_heart_attack_buffs"))
            elif k == "tag":
                h["tags"] |= {"religious": 1, "heavy": 2, "outsider": 4}.get(f.get("id"), 0)
        # only the seven selectable skills, in icon order (battle_heal etc. have no icon)
        by_id = dict(sorted(((sid, lv) for sid, lv in by_id.items() if sid in icon_of),
                            key=lambda kv: icon_of[kv[0]]))
        h["skill_first"] = len(self.skills)
        for sid, levels in by_id.items():
            name = self.str.get(f"combat_skill_name_{cls}_{sid}", sid)
            for f in sorted(levels, key=lambda x: x.get("level", 0)):
                self.add_skill(f, name, art.get(sid) or "attack", f.get("level", 0), False)
        h["skill_count"] = len(by_id)
        h["upgrades"] = [self.upgrades(cls, list(by_id), m) for m in ("", "radiant", "new_game_plus")]  # GM_* order
        # combat_skill .generation_guaranteed: every recruit of the class starts with it
        h["guaranteed"] = next((i for i, (sid, fs) in enumerate(by_id.items())
                                if any(f.get("generation_guaranteed") in (True, "True", "true") for f in fs)), -1)
        if "move_src" in h:
            h["move"] = self.add_skill(h.pop("move_src"), "Move", "walk", 0, False)
        if "riposte_src" in h:
            f = h.pop("riposte_src")
            h["riposte"] = self.add_skill(f, "Riposte", art.get(f["id"]) or "riposte", 0, False)
        h["crit_eff"] = self.effect_span(crit_effects)
        h["dd"] = self.buff_span(dd_buffs)
        h["dd_rec"] = self.buff_span(dd_rec)
        h["ha_rec"] = self.buff_span(ha_rec)
        self.heroes.append(h)
        self.manifest["heroes"].append({"id": cls, "anim_dir": f"heroes/{cls}/anim",
                                        "png_dir": f"heroes/{cls}/{cls}_A/anim"})

    # Town upgrade costs/levels for weapons, armour and skills of a hero class.
    def upgrades(self, cls, skill_ids, mode=""):
        f = self.game / "modes" / mode / "upgrades/heroes" / f"{cls}.upgrades.json"
        d = json.loads((f if mode and f.exists() else self.game / "upgrades/heroes" / f"{cls}.upgrades.json").read_text())
        trees = {t["id"]: t for t in d["trees"]}

        def costs(tid, n):
            reqs = trees.get(tid, {}).get("requirements", [])
            c = [sum(x["amount"] for x in r.get("currency_cost", []) if x["type"] == "gold") for r in reqs][:n]
            lv = [int(r.get("prerequisite_resolve_level", 0)) for r in reqs][:n]
            return c + [0] * (n - len(c)), lv + [0] * (n - len(lv))

        wc, wl = costs(f"{cls}.weapon", 4)
        ac, al = costs(f"{cls}.armour", 4)
        sk = [costs(f"{cls}.{sid}", 5) for sid in skill_ids][:8]
        sk += [([0] * 5, [0] * 5)] * (8 - len(sk))
        return wc, wl, ac, al, sk

    # Afflictions and virtues (trait_library.json) with their buffs and act-out behaviours.
    def traits(self):
        acts = {"nothing": 0, "bark_stress": 1, "change_pos": 2, "ignore_command": 3, "random_command": 4,
                "retreat_from_combat": 5, "attack_friendly": 6, "attack_self": 7, "mark_self": 8,
                "stress_heal_self": 9, "stress_heal_party": 10, "buff_random_party_member": 11,
                "buff_party": 12, "heal_self": 13}
        hero_index = {h["id"]: i for i, h in enumerate(self.heroes)}
        self.trait_rows, self.actouts = [], []
        data = json.loads((self.game / "shared/trait/trait_library.json").read_text())["traits"]
        for t in data:
            if not t.get("is_generated"):
                continue
            kind = 0 if t.get("overstress_type") == "affliction" else 1
            word = "affliction" if kind == 0 else "virtue"
            name = self.str.get(f"str_{word}_name_{t['id']}", t["id"])
            desc = self.str.t.get(f"str_{word}_description_{t['id']}", "")
            bf = self.buff_span(t.get("buff_ids", []))
            first = len(self.actouts)
            for a in t.get("combat_start_turn_act_outs", []):
                if not a.get("chance") or a.get("id") not in acts:
                    continue
                classes = a.get("valid_hero_class_ids") or [None]
                for c in classes:
                    if c is not None and c not in hero_index:
                        continue  # e.g. classes not in this build
                    d = a.get("data", {})
                    eff = self.effect(d.get("string_value")) if d.get("string_value") else None
                    self.actouts.append((acts[a["id"]], hero_index.get(c, -1),
                                         eff if eff is not None else -1,
                                         float(a["chance"]), float(d.get("number_value", 0))))
            react = {r["id"]: float(r.get("chance", 0)) for r in t.get("reaction_act_outs", [])}
            self.trait_rows.append((t["id"], name, desc, kind, bf, first, len(self.actouts) - first,
                                    react.get("block_heal", 0), react.get("block_move", 0),
                                    react.get("block_buff", 0)))

    # Curio types and their weighted result tables (curio_type_library.csv).
    def curios(self):
        import csv
        root = self.game / "curios"
        sprites = {}
        for r in csv.DictReader(open(root / "curio_props.csv", encoding="utf-8", errors="replace")):
            sprites.setdefault(r["Curio Type"], r["Sprite Reference"])
        rows = list(csv.reader(open(root / "curio_type_library.csv", encoding="utf-8", errors="replace")))
        types = {"Nothing": 0, "Loot": 1, "Quirk": 2, "Effect": 3, "Purge": 4, "Scouting": 5, "Teleport": 6, "Disease": 7, "Summon": 8}
        items = {"food": 0, "torch": 1, "shovel": 2, "bandage": 3, "antivenom": 4, "medicinal_herbs": 5,
                 "holy_water": 6, "skeleton_key": 7, "laudanum": 8, "firewood": 9}
        regions = {"ALL": 15, "Ruins": 1, "Weald": 2, "Warrens": 4, "Cove": 8}
        self.curio_rows, self.curio_results = [], []

        def cell(r, i):
            return r[i].strip() if i < len(r) else ""

        def sub_results(r, rtype, item):
            out = []
            for c in (7, 10, 13):
                name, w = cell(r, c), cell(r, c + 1)
                if not name or name == "N/A":
                    continue
                try:
                    wt = float(w) if w and w != "N/A" else 1.0
                except ValueError:
                    wt = 1.0
                eff, draws = -1, 0
                if rtype == 3:
                    e = self.effect(name)
                    if e is None:
                        continue
                    eff = e
                elif rtype == 1:
                    draws = int(wt) if name != "JOURNALONLY" else 0
                    wt = 1.0
                    eff = self.loot_id(name)  # CR_LOOT: loot table id
                elif rtype == 2:
                    draws = 1 if name == "positive" else -1
                out.append((rtype, item, wt, eff, draws))
            if not out and rtype in (0, 4, 5, 6, 7, 8):
                out.append((rtype, item, 1.0, -1, 0))
            return out

        i = 0
        while i < len(rows):
            r = rows[i]
            if cell(r, 1).isdigit() and cell(r, 2) and i + 2 < len(rows) and cell(rows[i + 1], 2) == "ID STRING":
                name, good = cell(r, 2).replace(" (tutorial)", ""), {"Good": 1, "Bad": 0}.get(cell(r, 4), 2)
                cid = cell(rows[i + 2], 2)
                res, itm, region, j = [], [], 15, i + 2
                mode = "res"
                while j < len(rows):
                    rr = rows[j]
                    if j > i + 2 and cell(rr, 1).isdigit():
                        break
                    if cell(rr, 2) == "REGION FOUND" and j + 1 < len(rows):
                        region = regions.get(cell(rows[j + 1], 2), 15)
                    if cell(rr, 2) == "Item Interactions":
                        mode = "item"
                    elif mode == "res" and cell(rr, 4) in types and cell(rr, 5):
                        rtype = types[cell(rr, 4)]
                        w = float(cell(rr, 5))
                        subs = sub_results(rr, rtype, 255)
                        total = sum(x[2] for x in subs) or 1
                        for x in subs:  # flatten: weight = result weight x sub share
                            res.append((x[0], 255, w * x[2] / total, x[3], x[4]))
                    elif mode == "item" and cell(rr, 4) in items:
                        rtype = types.get(cell(rr, 5), 0)
                        subs = sub_results(rr, rtype, items[cell(rr, 4)])
                        total = sum(x[2] for x in subs) or 1
                        for x in subs:
                            itm.append((x[0], x[1], x[2] / total, x[3], x[4]))
                    j += 1
                if res and cid:
                    rf = len(self.curio_results)
                    self.curio_results += res
                    itf = len(self.curio_results)
                    self.curio_results += itm
                    self.curio_rows.append((cid, name, sprites.get(cid, cid), region, good, rf, len(res), itf, len(itm)))
                i = j
                continue
            i += 1
        self.manifest["curios"] = sorted({c[2] for c in self.curio_rows})

    # Camping skills and their effects (camping/default.camping_skills.json).
    def camping(self):
        d = json.loads((self.game / "raid/camping/default.camping_skills.json").read_text())
        types = {"stress_heal_amount": 0, "stress_damage_amount": 1, "health_heal_max_health_percent": 2,
                 "health_damage_max_health_percent": 3, "buff": 4, "remove_bleeding": 5, "remove_poison": 5,
                 "remove_disease": 5, "reduce_ambush_chance": 6, "remove_deaths_door_recovery_buffs": 7,
                 "loot": 8, "reduce_torch": 9}
        sel = {"self": 0, "individual": 1, "party": 2, "party_other": 3}
        hero_index = {h["id"]: i for i, h in enumerate(self.heroes)}
        self.camp_skills, self.camp_effects = [], []
        for sk in d["skills"]:
            classes = 0
            for c in sk.get("hero_classes", []):
                if c in hero_index:
                    classes |= 1 << hero_index[c]
            if not classes:
                continue
            first = len(self.camp_effects)
            target = 0
            for e in sk["effects"]:
                t = types.get(e["type"], 10)
                bi = self.buff_index.get(e.get("sub_type", ""), -1) if t == 4 else -1
                if t == 4 and bi < 0:
                    continue
                s_ = sel.get(e.get("selection"), 0)
                target |= s_ == 1
                self.camp_effects.append((t, s_, bi, float(e.get("amount", 0)),
                                          float(e.get("chance", {}).get("amount", 1.0))))
            name = self.str.get(f"camping_skill_name_{sk['id']}", sk["id"]).title()
            self.camp_skills.append((sk["id"], name, int(sk.get("cost", 1)), int(sk.get("use_limit", 1)),
                                     classes, first, len(self.camp_effects) - first, target))

    # Map generator parameters and quest-board generation tables.
    def maps_and_quests(self):
        qt = {"explore": 0, "cleanse": 1, "kill_boss": 2, "gather": 3, "activate": 4, "inventory_activate": 5}
        dg = {"crypts": 0, "weald": 1, "warrens": 2, "cove": 3}
        size = {"short": 1, "medium": 2, "long": 3}
        self.map_params = []
        text = (self.game / "scripts/map_generator.darkest").read_text(errors="replace")
        for block in text.split("map:")[1:]:
            f = {}
            for line in block.splitlines():
                parts = line.split()
                if parts and parts[0].startswith("."):
                    vals = [parse_value(v) for v in parts[1:]]
                    f[parts[0][1:]] = vals[0] if len(vals) == 1 else vals
            if f.get("dungeon_type") not in dg or f.get("size") not in size:
                continue
            pair = lambda key: (lambda v: [int(v[0]), int(v[-1])] if isinstance(v, list) else [int(v), int(v)])(f.get(key, 0))
            gw, gh = pair("gridsize")
            self.map_params.append(dict(
                length=size[f["size"]], quest=qt.get(f["quest_type"], 0), dungeon=dg[f["dungeon_type"]],
                rooms=int(f["base_room_number"]), corridors=int(f["base_corridor_number"]), gw=gw, gh=gh,
                spacing=int(f["spacing"]), goal=int(f["goal_room_number"]), mfd=int(f["min_final_distance"]),
                conn=float(f["connectivity"]), hb=pair("hallway_battle"), ht=pair("hallway_trap"),
                ho=pair("hallway_obstacle"), hc=pair("hallway_curio"), hh=pair("hallway_hunger"),
                rb=pair("total_room_battles"), gc=pair("room_guarded_curio"), gt=pair("room_guarded_treasure"),
                sr=pair("secret_rooms")))
        g = json.loads((self.game / "campaign/quest/quest.generation.json").read_text())["generation"]
        self.quest_options = []
        for entry in g["type"]["available_quests_table"]:
            if entry["dungeon"] not in dg:
                continue
            for row, opts in enumerate(entry["generated_quest_table"][:8]):
                for o in opts:
                    if o["type"] in qt:
                        self.quest_options.append((dg[entry["dungeon"]], row, qt[o["type"]], int(o["length"]), float(o["chance"])))
        n = json.loads((self.game / "campaign/quest/number.quest.generation.json").read_text())
        self.quests_per_visit = (n["generation"]["number"]["number_of_quests_per_town_visit_table"] + [13] * 8)[:8]
        self.dungeon_unlock = [0] * len(DUNGEONS)
        for d in g["dungeon"]["generated_dungeons"]:
            if d["id"] in dg:
                self.dungeon_unlock[dg[d["id"]]] = int(d["required_number_of_quests_finished"])

    # Intern a list of buff ids; return (first, count) into the flat buff list.
    def buff_span(self, ids):
        first = len(self.buff_list)
        self.buff_list += [self.buff_index[i] for i in ids if i in self.buff_index]
        return first, len(self.buff_list) - first

    # ------------------------------------------------------------ monsters
    # Export a monster class variant (e.g. brigand_cutthroat_A): stats, skills, AI brain link,
    # boss mechanics (captors, shared health, shifting forms, companions).
    def monster(self, variant):
        """Index of a monster class like 'brigand_cutthroat_A', exporting it on first use."""
        if variant in self.monster_index:
            return self.monster_index[variant]
        base = re.sub(r"_[A-Z]$", "", variant)
        d = self.game / "monsters" / base / variant
        info_f = d / f"{variant}.info.darkest"
        if not info_f.exists():
            return None
        idx = len(self.monsters)
        self.monster_index[variant] = idx
        m = dict(id=variant, name=self.str.get(f"str_monstername_{variant}", base), size=1,
                 types=0, flags=0, tpr=1, riposte=-1, brain=-1, corpse=-1, loot=("", 0),
                 sprite=base, life_link=None, captor_full=-1, captor_empty=-1, captor_for=None,
                 captor_damage=0.0, captor_dd=0, shared=0, shift=[], shift_every=0,
                 companion=None, comp_buffs=(0, 0), comp_heal=0.0, control_stress=0,
                 spawn=(0, 0), boss=0, flags2=0, death_effs=(0, 0), carry_hp=0.0, death_dmg_base=None,
                 death_dmg=0, react=(0, 0))
        self.monsters.append(m)  # reserve slot (recursion via corpse/summons)
        info = parse_darkest(info_f)
        art_f = d / f"{variant}.art.darkest"
        art = {f["id"]: f.get("anim") for k, f in parse_darkest(art_f) if k == "skill" and "id" in f} \
            if art_f.exists() else {}
        skills, corpse = [], None
        for k, f in info:
            if k == "display":
                m["size"] = int(f.get("size", 1) or 1)
            elif k == "enemy_type":
                m["types"] |= 1 << MT.get(str(f.get("id")), 0)
            elif k == "stats":
                m["hp"] = int(f.get("hp", 1) or 1)
                m["def"], m["prot"] = f.get("def", 0) or 0, f.get("prot", 0) or 0
                m["spd"] = int(f.get("spd", 0) or 0)
                m["res"] = [f.get("stun_resist", 0) or 0, f.get("poison_resist", 0) or 0,
                            f.get("bleed_resist", 0) or 0, 0, f.get("move_resist", 0) or 0,
                            f.get("debuff_resist", 0) or 0, 0, 0]
            elif k == "skill":
                skills.append(f)
            elif k == "riposte_skill":
                m["riposte_src"] = f
            elif k == "initiative":
                tpr = f.get("number_of_turns_per_round")
                m["tpr"] = int(tpr) if isinstance(tpr, (int, float)) else 1  # 0 = never acts on its own
            elif k == "monster_brain":
                m["brain"] = self.brain(str(f.get("id")))
            elif k == "death_class":
                corpse = f.get("monster_class_id")
                m["flags"] |= 32 if f.get("is_valid_on_crit") in (False, "False") else 0
                if f.get("can_die_from_damage") in (False, "False", "false"):
                    m["flags2"] |= 2  # MF2_TRANSFORM: becomes monster_class_id instead of dying
                if f.get("change_class_effects"):
                    m["death_src"] = as_list(f.get("change_class_effects"))
                m["carry_hp"] = float(f.get("carry_over_hp_min_percent") or 0)
            elif k == "loot":
                m["loot"] = (str(f.get("code") or ""), int(f.get("count") or 0))
            elif k == "personality":  # .prefskill: skill slot the preferred_skill desire favours, -1 none
                m["prefskill"] = int(f.get("prefskill")) if f.get("prefskill") is not None else -1
            elif k == "battle_modifier":
                m["flags"] |= 1 if f.get("can_surprise") else 0
                m["flags"] |= 2 if f.get("can_be_surprised") else 0
                m["flags"] |= 16 if f.get("can_be_hit") is False else 0
                m["flags"] |= 64 if f.get("always_surprise") else 0
                if f.get("can_be_damaged_directly") in (False, "False", "false"):
                    m["flags2"] |= 1  # MF2_NO_DIRECT_DAMAGE: only death_damage hurts it
                m["flags2"] |= 4 if f.get("disable_stall_penalty") in (True, "True") else 0     # MF2_NO_STALL
                m["flags2"] |= 8 if f.get("accelerate_stall_penalty") in (True, "True") else 0  # MF2_STALL_FAST
                m["flags2"] |= 16 if f.get("does_count_towards_stall_penalty") in (False, "False") else 0  # MF2_STALL_SKIP
                m["flags2"] |= 32 if f.get("can_be_missed") in (False, "False") else 0  # MF2_NEVER_MISSED
                m["flags2"] |= 64 if f.get("can_relieve_stress_from_crit") in (False, "False") else 0  # MF2_NO_CRIT_RELIEF
                m["flags2"] |= 128 if f.get("can_relieve_stress_from_killing_blow") in (False, "False") else 0  # MF2_NO_KILL_RELIEF
            elif k == "wave_spawning" and f.get("prefers_front"):
                m["flags"] |= 4
            elif k == "tag" and f.get("id") == "boss":
                m["boss"] = 1
            elif k == "life_link":
                m["life_link"] = str(f.get("base_class"))
            elif k == "captor_empty":
                m["captor_for"] = str(f.get("performing_monster_captor_base_class"))
                m["captor_full_name"] = str(f.get("captor_full_monster_class"))
            elif k == "captor_full":
                m["captor_empty_name"] = str(f.get("captor_empty_monster_class"))
                m["captor_damage"] = float(f.get("per_turn_damage_percent") or 0)
                m["captor_dd"] = 1 if f.get("release_on_prisoner_at_deaths_door") in (True, "true") else 0
            elif k == "shape_shifter":
                m["shift_src"] = f
            elif k == "shared_health":
                m["shared"] = self.shared_ids.setdefault(str(f.get("id")), len(self.shared_ids) + 1)
            elif k == "companion":
                m["companion"] = str(f.get("monster_class"))
                m["comp_buffs"] = self.buff_span(as_list(f.get("buffs")))
                m["comp_heal"] = float(f.get("heal_per_turn_percent") or 0)
            elif k == "controller":
                m["control_stress"] = int(f.get("stress_per_controlled_turn") or 0)
            elif k == "spawn":
                m["spawn_src"] = as_list(f.get("effects"))
            elif k == "death_damage":
                m["death_dmg_base"] = str(f.get("target_base_class_id"))
                m["death_dmg"] = int(f.get("target_damage") or 0)
            elif k == "skill_reaction":
                m["react_src"] = as_list(f.get("was_hit_performer_effects"))
        for f in skills:  # resolve effects (and any summoned monsters) before laying out skills
            for e in as_list(f.get("effect")):
                self.effect(str(e))
        m["skill_first"] = len(self.skills)
        for f in skills:
            self.add_skill(f, self.str.get(f"str_monster_skill_{f['id']}", f["id"]),
                           art.get(f["id"]) or "attack", 0, True)
        m["skill_count"] = len(skills)
        if "riposte_src" in m:
            m["riposte"] = self.add_skill(m.pop("riposte_src"), "Riposte", "riposte", 0, True)
        if corpse:
            c = self.monster(str(corpse))
            m["corpse"] = c if c is not None else -1
        for key, dst in (("captor_full_name", "captor_full"), ("captor_empty_name", "captor_empty")):
            if m.get(key):
                c = self.monster(m.pop(key))
                m[dst] = c if c is not None else -1
        if m.get("shift_src"):
            f = m.pop("shift_src")
            ranks_ = [str(r) for r in as_list(f.get("monster_class_valid_ranks"))]
            for cid, ch, rk in zip(as_list(f.get("monster_class_ids")), as_list(f.get("monster_class_chances")), ranks_):
                c = self.monster(str(cid))
                if c is not None:
                    mask = 0
                    for chr_ in rk:
                        if chr_.isdigit() and 1 <= int(chr_) <= 4:
                            mask |= 1 << (int(chr_) - 1)
                    m["shift"].append((c, float(ch), mask))
            m["shift_every"] = int(f.get("round_frequency") or 1)
        if m.get("spawn_src"):
            m["spawn"] = self.effect_span(m.pop("spawn_src"))
        if m.get("death_src"):
            m["death_effs"] = self.effect_span(m.pop("death_src"))
        if m.get("react_src"):
            m["react"] = self.effect_span(m.pop("react_src"))
        if base not in {x["id"] for x in self.manifest["monsters"]}:
            self.manifest["monsters"].append({"id": base, "anim_dir": f"monsters/{base}/anim",
                                              "png_dir": f"monsters/{base}/anim"})
        # resolve skill index references inside the brain now that skills exist
        if m["brain"] >= 0:
            self._bind_brain(m["brain"], m)
        return idx

    # ------------------------------------------------------------ brains
    # Intern a monster AI brain by id.
    def brain(self, bid):
        if bid in self.brain_index:
            return self.brain_index[bid]
        self.brain_index[bid] = len(self.brains)
        self.brains.append({"id": bid, "bound": False})
        return self.brain_index[bid]

    # Convert a brain's skill/target/bonus desires into table rows.
    def _bind_brain(self, bi, m):
        b = self.brains[bi]
        if b["bound"]:
            return
        src = self._brain_json.get(b["id"], {})
        skill_ids = {self.skills[i]["id"]: i for i in range(m["skill_first"], m["skill_first"] + m["skill_count"])}
        b["skill_first"] = len(self.skill_desires)
        # monster_brains skill_selection_desires (AI::MonsterSkillSelectionDesire, decomp8): a desire
        # adds its base_chance to a skill when IsDesireValid holds - inclusive min/max ranges on
        # battle counts, the performer's cumulative performing turn and HP ratio - plus a type test
        types = {"specific_skill": 0, "performing_turn_skill": 1, "stun_skill": 2, "ally_alive_skill": 3,
                 "ally_dead_skill": 4, "heal_skill": 5, "effect_key_status_skill": 6, "random_skill": 7,
                 "preferred_skill": 9, "fill_ally_captor_empty_skill": 8}
        counts = ["monsters", "monsters_size", "heroes", "marked_heroes", "non_marked_heroes", "non_stunned_heroes",
                  "non_deaths_door_heroes", "virtued_heroes", "guarded_monsters", "control_count"]
        for dsr in src.get("skill_selection_desires", []):
            data = dsr.get("data", {})
            ty = types.get(dsr.get("type"))
            if ty is None:
                continue
            sid = data.get("combat_skill_id")
            idx = skill_ids.get(sid, -1) if sid else -1
            if sid and idx < 0:
                continue  # a skill this monster doesn't have
            lo = [int(data.get(f"{c}_min", 0)) for c in counts]
            hi = [min(255, int(data.get(f"{c}_max", 255))) for c in counts]
            turn = int(data.get("performing_turn", data.get("performing_turn_min", 0)))
            ks = {"tagged": 1, "poisoned": 2, "stunned": 3, "bleeding": 4}.get(str(data.get("effect_key_status", "")), 0)
            self.skill_desires.append((sid if sid else None, float(data.get("base_chance", 1.0)), ty, turn,
                                       int(bool(data.get("first_initiative_only"))), ks,
                                       str(data.get("ally_base_class_id", "") or ""),
                                       float(data.get("hp_ratio_threshold", 0) or 0), lo, hi))
        b["skill_count"] = len(self.skill_desires) - b["skill_first"]
        b["target_first"] = len(self.target_desires)
        types = {"random_target": 0, "marked_target": 1, "health_target": 2, "stunned_target": 3,
                 "rank_target": 4, "stress_target": 5, "resistance_target": 6,
                 "actor_dot_target": 7, "guard_target": 8}
        for dsr in src.get("target_selection_desires", []):
            data = dsr.get("data", {})
            if not data.get("is_enemy_target_desire", True):
                continue
            t = types.get(dsr.get("type"), 9)
            param = 0
            if t == 4:
                for r in as_list(data.get("ranks")):
                    param |= 1 << (int(r) - 1) if str(r).isdigit() and 1 <= int(r) <= 4 else 0
            elif t == 6:
                param = RES_SUB.get(data.get("resistance_type_id"), 0)
            sk = data.get("specific_combat_skill_id") or None  # by id: brains are shared by A/B/C variants
            self.target_desires.append((t, param, sk, float(data.get("base_chance", 1.0))))
        b["target_count"] = len(self.target_desires) - b["target_first"]
        b["bonus_first"] = len(self.bonus_desires)
        types = {"guaranteed": 0, "last_skill": 1, "ally_last_damaged": 2, "ally_actor_class_count": 3}
        for dsr in src.get("bonus_initiative_desires", []):
            t = types.get(dsr.get("type"))
            if t is None:
                continue
            d = dsr.get("data", {})
            when = (1 if d.get("is_round_start") else 0) | (2 if d.get("is_round_in_progress") or d.get("is_post_turn") else 0) \
                | (4 if d.get("is_round_finish") else 0)
            sk = d.get("combat_skill_id_override") or None
            self.bonus_desires.append((t, when, sk, d.get("last_combat_skill_id"), d.get("ally_base_class_id"),
                                       int(d.get("ally_count_min", 0)), int(d.get("ally_count_max", 4)),
                                       int(d.get("monsters_min", 0)), int(d.get("monsters_max", 8)),
                                       int(d.get("monsters_size_limit", 0)), 1 if d.get("ignore_if_stun") else 0))
        b["bonus_count"] = len(self.bonus_desires) - b["bonus_first"]
        b["bound"] = True

    # ------------------------------------------------------------ encounters
    # Read a dungeon's .mash files: which monster groups appear for each level and kind.
    def encounters_for(self, di, folder):
        for lvl in LEVELS:
            f = self.game / "dungeons" / folder / f"{folder}.{lvl}.mash.darkest"
            if not f.exists():
                continue
            for k, e in parse_darkest(f):
                kind = {"hall": 0, "room": 1, "boss": 2, "stall": 7}.get(k)  # 7: ENC_STALL reinforcements
                if k == "named" and str(e.get("name")) in ("tutorial_1", "tutorial_2") and folder == "weald":
                    kind = 3  # ENC_NAMED: the Old Road's fixed fights, never picked at random
                    self.tutorial_enc.append(len(self.encounters))
                if k == "named" and folder == "darkestdungeon":
                    kind = 3  # placed by name on the fixed Darkest Dungeon maps
                    self.named_enc[str(e.get("name"))] = len(self.encounters)
                if k == "named" and str(e.get("name")) == "summon_mash_shambler":
                    kind = 6  # ENC_ALTAR: a torch on the Shambler's altar (curio Summon result)
                if kind is None:
                    continue
                ids = [self.monster(str(t)) for t in as_list(e.get("types"))]
                ids = [i for i in ids if i is not None][:4]
                if ids:
                    self.encounters.append((di, lvl, kind, len(ids), float(e.get("chance", 1)), ids, 0.0))
            # <folder>.conditional.<lvl>.mash.darkest: hall packs that only show up under a condition
            # (Shambler at darkness 0, Collector with a full inventory); limit 1 per expedition
            f = self.game / "dungeons" / folder / f"{folder}.conditional.{lvl}.mash.darkest"
            for k, e in (parse_darkest(f) if f.exists() else []):
                ids = [i for i in (self.monster(str(t)) for t in as_list(e.get("types"))) if i is not None][:4]
                if k != "hall" or not ids:
                    continue
                if e.get("darkness_range") is not None:
                    kind, cond = 4, float(as_list(e.get("darkness_range"))[-1])  # ENC_COND_DARK: max light
                elif e.get("inventory_valid_item_percent_range") is not None:
                    kind, cond = 5, float(as_list(e.get("inventory_valid_item_percent_range"))[0])  # ENC_COND_INV
                else:
                    continue
                self.encounters.append((di, lvl, kind, len(ids), float(e.get("chance", 0)), ids, cond))

    # ------------------------------------------------------------ Darkest Dungeon plot maps
    # Decode the Darkest Dungeon's fixed map files (see dm_decode.py) into room/hall tables.
    def plot_maps(self):
        """maps/DD_map1..4.dm (binary persist files, see dm_decode.py) + quest.plot_quests.json:
        fixed rooms and halls for the four Darkest Dungeon expeditions.
        Tile content codes (Hypothesis, matched against the Old Road's persist.map.json and the
        maps themselves): 1 fight, 3 trap, 4 obstacle, 6/10 room fight + curio, 7 hall curio,
        8 hunger check, 9 room curio, 13 secret door. Curio/obstacle ids are string_hash(name)
        = h*53 + c (Verified: string_hash @ 0xc2abe0)."""
        import struct
        from dm_decode import decode

        def h53(n):
            h = 0
            for c in n.encode():
                h = (h * 53 + c) & 0xFFFFFFFF
            return h - (1 << 32) if h >= 1 << 31 else h

        curio_by_hash = {h53(r[0]): i for i, r in enumerate(self.curio_rows)}
        curio_by_hash[h53("custom_map_quest_curio")] = -2  # CURIO_QUEST: the quest's goal curio
        NONE = 1701736302  # area id "none"
        SPOT_EMPTY, SPOT_BATTLE, SPOT_CURIO, SPOT_TRAP, SPOT_ENTRANCE, SPOT_BOSS, SPOT_OBSTACLE, SPOT_HUNGER, \
            SPOT_GHOST = range(9)
        MAX_SEG = 10
        pq = {q["id"]: q for q in json.loads((self.game / "campaign/quest/quest.plot_quests.json").read_text())["plot_quests"]}
        qtype = {"kill_boss": 2, "inventory_activate": 4, "activate": 4, "explore": 0}
        boss_of = {1: "shuffler_D", 4: "ancestor_small_D"}
        self.plot_quests, self.plot_rooms, self.plot_corrs = [], [], []
        # 1-4: the Darkest Dungeon; 5-6: quests that town events put on the board
        ids = [f"plot_darkest_dungeon_{n}" for n in range(1, 5)] + ["plot_town_invasion_0", "plot_crow_trinket",
                                                                     "plot_tutorial_crypts"] + \
              [f"plot_trinket_retention_{n}" for n in range(3)]  # the Shrieker's Perch, levels 1/3/5
        folder_dg = {"town": 5, "weald": 1, "crypts": 0}  # DG_TOWN, DG_WEALD, DG_RUINS
        for qn, qid in enumerate(ids, 1):
            q = pq[qid]
            qq = q["quest"] if isinstance(q["quest"], dict) else json.loads(q["quest"])
            named, dg, lvl = self.named_enc, 4, 6
            if qn > 4:  # named/boss packs of the quest's own mash file
                folder, lvl = qq["dungeon"], int(qq["difficulty"])
                dg, named, goal_boss = folder_dg[folder], {}, None
                goal = qq["goal_ids"][0].replace("kill_", "")
                for k, e in parse_darkest(self.game / "dungeons" / folder / f"{folder}.{lvl}.mash.darkest"):
                    types = [str(t) for t in as_list(e.get("types"))]
                    if k not in ("named", "boss") or (k == "boss" and goal not in types):
                        continue
                    mids = [i for i in (self.monster(t) for t in types) if i is not None][:4]
                    if not mids:
                        continue
                    if k == "named":
                        named.setdefault(str(e.get("name")), len(self.encounters))
                    elif goal_boss is None:
                        goal_boss = len(self.encounters)
                    self.encounters.append((dg, lvl, 3, len(mids), 1.0, mids, 0.0))
            m = decode((self.game / f"maps/{qq['map_name']}.dm").read_bytes())["map"]
            st, dy = m["static_dynamic"]["static_save"]["areas"], m["static_dynamic"]["areas"]

            def pos(t):
                return struct.unpack("<2f", bytes.fromhex(t["mappos"]))

            def tile_info(key, tk):
                t, d = st[key]["tiles"][tk], dy.get(key, {}).get("tiles", {}).get(tk, {})
                enc = named.get(d.get("mash_name", ""), -1)
                cur = curio_by_hash.get(t.get("curio_prop", 0) or t.get("cur", 0), -1)
                return d.get("content", 0), enc, cur, t
            rooms = [k for k, a in st.items() if a["kind"] == 0]
            # a room reached only through a hall's secret door is folded into that square
            by_id = {a["id"]: n for n, a in st.items()}
            has_secret_door = {n for n in st if any(t.get("content") == 13 for t in dy.get(n, {}).get("tiles", {}).values())}
            secret = {k for k in rooms if {by_id.get(st[k][f"door{i}"]["area_to"]) for i in range(8)} - {None} <= has_secret_door
                      and st[k]["id"] not in (m["entrance_id"], m.get("final_room_id", 0))}
            rooms = [k for k in rooms if k not in secret]
            rix = {st[k]["id"]: i for i, k in enumerate(rooms)}
            room_first = len(self.plot_rooms)
            final = m.get("final_room_id", 0)
            boss = -1
            if qn in boss_of:
                boss = next(i for i, e in enumerate(self.encounters) if e[0] == 4 and e[2] == 2 and
                            self.monsters[e[5][0]]["id"] == boss_of[qn])
            elif qn > 4 and qq["type"] == "kill_boss":
                boss = goal_boss if goal_boss is not None else next(iter(named.values()), -1)
            for k in rooms:
                content, enc, cur, t = tile_info(k, "tile0")
                x, y = pos(t)
                spot = SPOT_EMPTY
                if len(rooms) == 1 and boss >= 0:  # the Shrieker's perch: one room, the fight itself
                    spot, enc = SPOT_BOSS, boss
                elif st[k]["id"] == m["entrance_id"]:
                    spot = SPOT_ENTRANCE
                elif st[k]["id"] == final and boss >= 0:
                    spot, enc = SPOT_BOSS, boss
                elif enc >= 0:
                    spot = SPOT_BATTLE
                elif cur != -1:
                    spot = SPOT_CURIO
                self.plot_rooms.append((round(x), round(y), spot, enc, cur))
            corr_first = len(self.plot_corrs)
            for k, a in st.items():
                if a["kind"] != 1:
                    continue
                ends = [rix[r["id"]] for r in (st[x] for x in rooms)
                        if any(r[f"door{i}"]["area_to"] == a["id"] for i in range(8))]
                if len(ends) != 2:
                    continue
                tiles = [tk for tk in a["tiles"] if st[k]["tiles"][tk]["type"] == 1]
                # the end nearer the hall's first square is room a
                x0, y0 = pos(a["tiles"][tiles[0]])
                ra, rb = (self.plot_rooms[room_first + e] for e in ends)
                if abs(ra[0] - x0) + abs(ra[1] - y0) > abs(rb[0] - x0) + abs(rb[1] - y0):
                    ends.reverse()
                segs = []
                for tk in tiles:
                    content, enc, cur, t = tile_info(k, tk)
                    if content == 1 and enc >= 0:
                        segs.append((SPOT_BATTLE, enc))
                    elif content == 3:
                        segs.append((SPOT_TRAP, -1))
                    elif content == 4:
                        segs.append((SPOT_GHOST if t.get("obstacle") == h53("ancestor") else SPOT_OBSTACLE, -1))
                    elif content == 7 and cur != -1:
                        segs.append((SPOT_CURIO, cur))
                    elif content == 8:
                        segs.append((SPOT_HUNGER, -1))
                    elif content == 13:  # secret door: the hidden room's curio sits on this square
                        sr = [x for x in secret]
                        sc = tile_info(sr[0], "tile0")[2] if sr else -1
                        segs.append((SPOT_CURIO, sc) if sc != -1 else (SPOT_EMPTY, -1))
                    else:
                        segs.append((SPOT_EMPTY, -1))
                while len(segs) > MAX_SEG:  # long halls (the final approach): drop empty squares
                    i = max((i for i, sg in enumerate(segs) if sg[0] == SPOT_EMPTY),
                            key=lambda i: min(abs(i - j) for j, sg in enumerate(segs) if sg[0] != SPOT_EMPTY) if any(
                                sg[0] != SPOT_EMPTY for sg in segs) else i)
                    segs.pop(i)
                self.plot_corrs.append((ends[0], ends[1], segs))
            goal_count = sum(1 for r in self.plot_rooms[room_first:] if r[4] == -2)
            rew = {it["type"]: it["amount"] for it in qq["completion_reward"]["items_definition"]["items"].values()}
            def quirk_list(key):
                return [(x["quirk_ids"][0], float(x["chance"])) for x in q.get(key, []) if x["quirk_ids"]][:7]
            self.plot_quests.append(dict(dungeon=dg, level=lvl,
                                         trinket=next((it["id"] for it in qq["completion_reward"]["items_definition"]["items"].values()
                                                       if it["type"] == "trinket"), ""),
                                         rarity=next((r["rarity"] for r in q.get("additional_trinket_completion_rewards", [])), ""),
                                         qwin=quirk_list("party_quirks_to_apply_on_completion"),
                                         qlose=quirk_list("party_quirks_to_apply_on_failure"),
                                         ignore_upgrades=sum(int(x["amount"]) for x in q.get("upgrade_tags_to_remove_on_ignore", [])
                                                             if x["upgrade_tag"] == "building"),
                                         quest=qtype[qq["type"]], length=int(qq["length"]),
                                         retreat=int(bool(q["can_retreat"])), boss=boss,
                                         rooms=(room_first, len(self.plot_rooms) - room_first),
                                         corrs=(corr_first, len(self.plot_corrs) - corr_first),
                                         gold=int(rew.get("gold", 0)), crests=int(rew.get("heirloom", 0)),
                                         goals=goal_count, xp=int(qq["completion_reward"].get("resolve_xp", 0)),
                                         name=self.str.get(f"town_quest_name_{qid}", f"Quest {qn}"),
                                         desc=self.str.get(f"town_quest_description_{qid}", ""),
                                         tip=self.str.get(f"str_{qid}_tip", "")))
        # the epilogue the narrator reads after the Heart of Darkness falls
        self.epilog = []
        while f"str_vo_epilog_{len(self.epilog)}" in self.str.t:
            self.epilog.append(" ".join(self.str.t[f"str_vo_epilog_{len(self.epilog)}"].split()))

    # ------------------------------------------------------------ loot
    # Intern a loot-table name.
    def loot_id(self, name):
        ids = self.__dict__.setdefault("loot_ids", {})
        return ids.setdefault(name, len(ids)) if name else -1

    # Loot tables, gem list and darkness bonus tables.
    def loot(self):
        """loot/*.loot.json: tables by id, difficulty and dungeon; overrides replace base tables."""
        tables = {}
        for f in ("loot.json", "common_overrides.loot.json", "blueprint_overrides.loot.json"):
            for t in json.loads((self.game / "loot" / f).read_text()).get("loot_tables", []):
                tables[(t["id"], t["difficulty"], t["dungeon"])] = t
        folders = [d[1] for d in DUNGEONS]
        supply = {"torch": 1, "shovel": 2, "bandage": 3, "antivenom": 4, "medicinal_herbs": 5,
                  "holy_water": 6, "skeleton_key": 7, "laudanum": 8, "firewood": 9}
        heir = {"bust": 0, "portrait": 1, "deed": 2, "crest": 3}
        gem_f = self.game / "inventory/base.gem.inventory.items.darkest"
        self.gems = [(str(f["id"]), int(f.get("sell_gold_value") or 0))
                     for k, f in parse_darkest(gem_f) if k == "inventory_item"]
        gem_ix = {g[0]: i for i, g in enumerate(self.gems)}
        self.loot_tables, self.loot_entries = [], []
        for (tid, diff, dun), t in sorted(tables.items(), key=lambda kv: str(kv[0])):
            first = len(self.loot_entries)
            for e in t["entries"]:
                d, ty = e.get("data", {}), e["type"]
                kind, ref, amt = 0, -1, int(d.get("amount", 0) or 0)
                if ty == "table":
                    kind, ref = 1, self.loot_id(d["table"])
                elif ty == "item":
                    it = d.get("type")
                    if it == "gold":
                        kind = 2
                    elif it == "gem" and d.get("id") in gem_ix:
                        kind, ref = 3, gem_ix[d["id"]]
                    elif it == "heirloom" and d.get("id") in heir:
                        kind, ref = 4, heir[d["id"]]
                    elif it == "provision":
                        kind, ref = 5, 0
                    elif it == "supply" and d.get("id") in supply:
                        kind, ref = 5, supply[d["id"]]
                elif ty == "trinket":
                    r = d.get("rarity")
                    kind, ref = 6, TRINKET_RARITIES.index(r) if r in TRINKET_RARITIES else -1
                elif ty == "journal_page":  # ref..amt: page range (specific_page_index: both)
                    kind = 7
                    if "specific_page_index" in d:
                        ref = amt = int(d["specific_page_index"])
                    else:
                        ref, amt = int(d.get("min_page_index", 1)), int(d.get("max_page_index", 21))
                self.loot_entries.append((kind, int(e.get("chances", 0)), ref, amt))
            self.loot_tables.append((self.loot_id(tid), diff, folders.index(dun) if dun in folders else -1,
                                     first, len(self.loot_entries) - first))
        dk = json.loads((self.game / "loot/darkness_overrides.loot.json").read_text())["darkness_bonuses"]
        self.darkness = {b["key"]: [(r["darkness"], r["chance"], [self.loot_id(c) for c in r["codes"]])
                                    for r in b["data"]] for b in dk}

    # ------------------------------------------------------------ quirks
    # Quirk library: positives, negatives, diseases and their buffs.
    def quirks(self):
        """shared/quirk/quirk_library.json: buffs, positive/disease, incompatibilities, roll weight."""
        q = json.loads((self.game / "shared/quirk/quirk_library.json").read_text())["quirks"]
        ix = {x["id"]: i for i, x in enumerate(q)}
        self.quirk_rows = []
        for x in q:
            bf, bn = self.buff_span(x.get("buffs", []))
            inc = [ix[i] for i in x.get("incompatible_quirks", []) if i in ix][:2] + [-1, -1]
            self.quirk_rows.append((x["id"], self.str.get(f"str_quirk_name_{x['id']}", x["id"].replace("_", " ").title()),
                                    int(bool(x.get("is_positive"))), int(bool(x.get("is_disease"))),
                                    float(x.get("random_chance", 0) or 0), bf, bn, inc[0], inc[1],
                                    self.str.get(f"str_quirk_description_{x['id']}", "")))

    # ------------------------------------------------------------ trinkets
    # Trinket list with rarity, class restriction, price and buffs.
    def trinkets(self):
        """trinkets/base.entries.trinkets.json (kickstarter backer trinkets are never awarded: skipped)."""
        e = json.loads((self.game / "trinkets/base.entries.trinkets.json").read_text())["entries"]
        folders = [d[1] for d in DUNGEONS]
        self.trinket_rows = []
        for x in e:
            if x["rarity"] not in TRINKET_RARITIES:
                continue
            bf, bn = self.buff_span(x.get("buffs", []))
            req = x.get("hero_class_requirements") or []
            cls = HEROES.index(req[0]) if req and req[0] in HEROES else -1
            dun = x.get("origin_dungeon", "")
            self.trinket_rows.append((x["id"], self.str.get(f"str_inventory_title_trinket{x['id']}", x["id"]),
                                      TRINKET_RARITIES.index(x["rarity"]), cls, int(x.get("limit", 0) or 0),
                                      folders.index(dun) if dun in folders else -1, int(x.get("price", 0)), bf, bn))
        self.manifest["trinkets"] = [r[0] for r in self.trinket_rows]

    # ------------------------------------------------------------ building upgrades
    # Estate upgrade trees (stage coach, tavern, blacksmith...) and their value effects.
    def building_upgrades(self):
        """upgrades/building/*.upgrades.json trees (heirloom + gold cost per level) and the values they
        unlock in campaign/town/buildings/*/*.building.json (key per tree, base row = level 0)."""
        cur = ["bust", "portrait", "deed", "crest", "gold"]
        keep = ("blacksmith", "guild", "tavern", "abbey", "stage_coach", "sanitarium", "nomad_wagon")
        self.trees, tix = [], {}
        for f in sorted((self.game / "upgrades/building").glob("*.upgrades.json")):
            for t in json.loads(f.read_text())["trees"]:
                if not t["id"].startswith(keep) or t["id"] == "stage_coach.upgraded_recruits":
                    continue
                costs = []
                for r in t["requirements"][:8]:
                    c = {x["type"]: x["amount"] for x in r["currency_cost"]}
                    costs.append([int(c.get(k, 0)) for k in cur])
                tix[t["id"]] = len(self.trees)
                self.trees.append((t["id"], costs))
        keys = {"discount_percent": 0, "amount": 1, "cost_currency": 2, "number_of_slots": 3, "heal_low": 4, "chance": 7}
        self.tree_values = []

        # arrays that share a tree and field get their own key (dd_types.h TV_*)
        own = {"negative_quirk_cost_upgrades": 5, "permanent_negative_quirk_cost_upgrades": 6,
               "disease_quirk_cure_all_chance_upgrades": 7}

        mode = 0  # GM_* the rows below belong to (each mode has its own copy of the building files)

        def rows(arr, tree, name="", activity=""):
            if tree not in tix:
                return
            for e in arr:
                code = e.get("upgrade_requirement_code")
                lvl = ord(code) - ord("a") + 1 if code else 0
                for k, kid in keys.items():
                    if k not in e:
                        continue
                    if name in own:
                        kid = own[name]
                    elif name == "slot_upgrades" and activity == "disease_treatment":
                        kid = 8
                    v = e[k]["amount"] if k == "cost_currency" else e[k]
                    self.tree_values.append((tix[tree], lvl, kid, float(v), mode))

        for mode, mdir in enumerate(("", "radiant", "new_game_plus")):
          for f in sorted((self.game / "campaign/town/buildings").glob("*/*.building.json")):
            b = f.parent.name
            over = self.game / "modes" / mdir / "campaign/town/buildings" / b / f.name
            if mdir and over.exists():
                f = over
            data = json.loads(f.read_text()).get("data", {})
            for k, v in data.items():
                if k.endswith("_upgrades") and isinstance(v, list) and v:
                    rows(v, next((e["upgrade_tree_id"] for e in v if "upgrade_tree_id" in e), ""))
            for group in ("activities", "stores"):
                for a in data.get(group, []):
                    for k, v in a.get("data", {}).items():
                        if not (k.endswith("_upgrades") and isinstance(v, list) and v):
                            continue
                        tree = next((e["upgrade_tree_id"] for e in v if "upgrade_tree_id" in e), f"{b}.{a['id']}")
                        if k in ("number_of_recruits_upgrades", "roster_size_upgrades", "cost_upgrades", "slot_upgrades",
                                 "stress_upgrades", "positive_quirk_cost_upgrades", "negative_quirk_cost_upgrades",
                                 "permanent_negative_quirk_cost_upgrades", "disease_quirk_cost_upgrades",
                                 "disease_quirk_cure_all_chance_upgrades", "number_of_trinkets_upgrades",
                                 "trinket_cost_discount_upgrades"):
                            rows(v, tree, k, a["id"])

    # ------------------------------------------------------------ write C
    # Emit everything as C source. The ORDER of fields here must match dd_types.h.
    def write(self, out):
        L = ['/* Generated by tools/export_game_data.py from the local game copy. Do not share. */',
             '#include <stddef.h>', '#include "dd_types.h"', '']
        L.append("const DDBuff dd_buffs[] = {")
        L += [f"  {{{c_str(b[0])}, {b[1]}, {b[2]}, {b[3]}, {b[4]}, {b[5]}, {c_float(b[6])}, {b[7]}, {c_float(b[8])}, {b[9]}, {b[10]}, {c_str(b[11])}}},"
              for b in self.buffs]
        L += ["};", f"const int dd_buff_count = {len(self.buffs)};", ""]
        L.append("const int16_t dd_buff_list[] = {" + ", ".join(map(str, self.buff_list or [0])) + "};")
        L.append("const DDEffOp dd_eff_ops[] = {")
        L += [f"  {{{op}, {arg}, {c_float(v)}}}," for op, arg, v in self.eff_ops] or ["  {0}"]
        L += ["};", "const DDEffect dd_effects[] = {"]
        L += [f"  {{{c_str(e[0])}, {e[1]}, {e[2]}, {e[3]}, {e[4]}, {e[5]}, {e[6]}, {c_float(e[7])}, {e[8]}, {e[9]}, {e[10]}}},"
              for e in self.effects]
        L += ["};", f"const int dd_effect_count = {len(self.effects)};", ""]
        L.append("const uint16_t dd_skill_effects[] = {" + ", ".join(map(str, self.skill_effects or [0])) + "};")
        L.append("const DDSkill dd_skills[] = {")
        for s in self.skills:
            L.append(f"  {{{c_str(s['id'])}, {c_str(s['name'])}, {c_str(s['anim'])}, {s['type']}, "
                     f"{s['level']}, {s['flags']}, {s['limit']}, {c_float(s['atk'])}, "
                     f"{c_float(s['dmg_mod'])}, {c_float(s['crit'])}, {s['dlo']}, {s['dhi']}, "
                     f"{s['hlo']}, {s['hhi']}, {s['mb']}, {s['mf']}, {s['launch']}, {s['target']}, "
                     f"{s['xt']}, {c_float(s['xtc'])}, {s['eff_first']}, {s['eff_count']}}},")
        L += ["};", f"const int dd_skill_count = {len(self.skills)};", ""]
        L.append("const int8_t dd_hero_guaranteed[] = {" + ", ".join(str(h.get("guaranteed", -1)) for h in self.heroes) + "};")
        L.append("const DDHeroClass dd_heroes[] = {")
        for h in self.heroes:
            res = ", ".join(c_float(r) for r in h["res"])
            wp = ", ".join(f"{{{c_float(a)}, {c_float(c)}, {lo}, {hi}, {sp}}}" for a, c, lo, hi, sp in h["weapons"])
            ar = ", ".join(f"{{{c_float(d)}, {c_float(p)}, {hp}, {sp}}}" for d, p, hp, sp in h["armours"])
            L.append(f"  {{{c_str(h['id'])}, {c_str(h['name'])}, {{{res}}}, {{{wp}}}, {{{ar}}}, "
                     f"{h['skill_first']}, {h['skill_count']}, {h['move']}, {h['riposte']}, "
                     f"{h['crit_eff'][0]}, {h['crit_eff'][1]}, {h['dd'][0]}, {h['dd'][1]}, "
                     f"{h['dd_rec'][0]}, {h['dd_rec'][1]}, {h['tags']}, {c_str(h['id'])}, {h['ha_rec'][0]}, {h['ha_rec'][1]}}},")
        L += ["};", f"const int dd_hero_count = {len(self.heroes)};", ""]
        L.append("const DDActOut dd_actouts[] = {")
        L += [f"  {{{a}, {c}, {e}, {c_float(w)}, {c_float(v)}}}," for a, c, e, w, v in self.actouts] or ["  {0}"]
        L += ["};", "const DDTrait dd_traits[] = {"]
        for tid, name, desc, kind, bf, af, an, bh, bm, bb in self.trait_rows:
            L.append(f"  {{{c_str(tid)}, {c_str(name)}, {c_str(desc)}, {kind}, {bf[0]}, {bf[1]}, {af}, {an}, "
                     f"{c_float(bh)}, {c_float(bm)}, {c_float(bb)}}},")
        L += ["};", f"const int dd_trait_count = {len(self.trait_rows)};", ""]
        L.append("const DDCurioResult dd_curio_results[] = {")
        L += [f"  {{{t}, {it}, {c_float(w)}, {e}, {d}}}," for t, it, w, e, d in self.curio_results] or ["  {0}"]
        L += ["};", "const DDLootTable dd_loot_tables[] = {"]
        L += [f"  {{{i}, {df}, {dn}, {f}, {n}}}," for i, df, dn, f, n in self.loot_tables]
        L += ["};", f"const int dd_loot_table_count = {len(self.loot_tables)};", "const DDLootEntry dd_loot_entries[] = {"]
        L += [f"  {{{k}, {c}, {r}, {a}}}," for k, c, r, a in self.loot_entries]
        L += ["};", "const DDGem dd_gems[] = {"]
        L += [f"  {{{c_str(g)}, {c_str(self.str.get('str_inventory_title_gem' + g, g.replace('_', ' ').title()))}, {v}}},"
              for g, v in self.gems]
        L += ["};", f"const int dd_gem_count = {len(self.gems)};"]
        for key in ("battle", "curio"):
            rows = self.darkness.get(key, [])
            L.append(f"const DDDarknessLoot dd_darkness_{key}[] = {{")
            L += [f"  {{{dk}, {c_float(ch)}, {len(cs)}, {cs[0] if cs else -1}}}," for dk, ch, cs in rows] or ["  {0}"]
            L += ["};", f"const int dd_darkness_{key}_count = {len(rows)};"]
        L.append("const DDQuirk dd_quirks[] = {")
        L += [f"  {{{c_str(a)}, {c_str(n)}, {p}, {d}, {c_float(w)}, {bf}, {bn}, {{{i1}, {i2}}}, {c_str(ds)}}},"
              for a, n, p, d, w, bf, bn, i1, i2, ds in self.quirk_rows]
        L += ["};", f"const int dd_quirk_count = {len(self.quirk_rows)};"]
        L.append("const DDTrinket dd_trinkets[] = {")
        L += [f"    {{{c_str(i)}, {c_str(n)}, {r}, {c}, {lim}, {d}, {pr}, {bf}, {bn}}},"
              for i, n, r, c, lim, d, pr, bf, bn in self.trinket_rows]
        L += ["};", f"const int dd_trinket_count = {len(self.trinket_rows)};"]
        L.append("const DDTownEvent dd_town_events[] = {")
        L += [f"  {{{c_str(i)}, {c_str(t)}, {c_str(d)}, {c_float(c)}, {c_float(m)}, {cd}, {w}, {dh}, {f}, {n}, {hl}, {hc}, {ts}}},"
              for i, t, d, c, m, cd, w, dh, f, n, hl, hc, ts in self.te_rows]
        L += ["};", f"const int dd_town_event_count = {len(self.te_rows)};", "const DDTownEventOp dd_town_event_ops[] = {"]
        L += [f"  {{{t}, {a}, {c_float(n)}}}," for t, a, n in self.te_ops]
        L += ["};", "const DDTownEventGuarantee dd_town_event_guarantees[] = {"]
        L += [f"  {{{d}, {q}, {e}}}," for d, q, e in self.te_guar]
        L += ["};", f"const int dd_town_event_guarantee_count = {len(self.te_guar)};",
              "const float dd_town_event_chance[4] = {%s};" % ", ".join(c_float(x) for x in (self.te_chance + [1.0] * 4)[:4])]
        jt = [self.str.t.get(f"journal_page_title_{i}", "") for i in range(JOURNAL_PAGES)]
        jx = [self.str.t.get(f"journal_page_text_{i}", "") for i in range(JOURNAL_PAGES)]
        L.append("const char *const dd_journal_title[JOURNAL_PAGES] = {" + ", ".join(c_str(x) for x in jt) + "};")
        L.append("const char *const dd_journal_text[JOURNAL_PAGES] = {" + ", ".join(c_str(x) for x in jx) + "};")
        fa = lambda xs: "{" + ", ".join(c_float(x) for x in xs) + "}"
        L.append("const DDRules dd_rules[GM_COUNT] = {")
        for r in self.rules:
            L.append(f"  {{{fa(r['dark_lower'])}, {{{', '.join(fa(x) for x in r['dark'])}}}, "
                     f"{c_float(r['crit_comp_chance'])}, {c_float(r['dd_comp_chance'])}, {c_float(r['dd_comp_chance_rep'])}, "
                     f"{c_float(r['pass_stress'])}, {c_float(r['dd_self'])}, {c_float(r['dd_self_rep'])}, "
                     f"{c_float(r['dd_comp'])}, {c_float(r['dd_comp_rep'])}, {fa(r['hall'])}, "
                     f"{int(r['light_new'])}, {int(r['light_old'])}, {{{', '.join(map(str, r['level_xp']))}}}, "
                     f"{fa(r['te'])}, {int(r['week_limit'])}, {int(r['death_limit'])}, {int(r['idle_heal'])}, "
                     f"{fa(r['act_mult'])}, {{{', '.join(str(min(int(x), 99)) for x in r['restrict'])}}}}},")
        L.append("};")
        L.append("const char *const dd_ui_str[] = {" + ", ".join(
            c_str(re.sub(r"\{colour_start\|[^}]*\}|\{colour_end\}", "", self.str.t.get(k, ""))) for k in UI_STRINGS) + "};")
        L.append("const char *const dd_game_over_reason[2] = {%s, %s};" % (
            c_str(self.str.t.get("game_over_reason_weeks", "")), c_str(self.str.t.get("game_over_reason_dead_heroes", ""))))
        L.append("const DDHeirExchange dd_heir_exchange[] = {" + ", ".join("{%d, %d, %d, %d}" % x for x in self.heir_ex) + "};")
        L.append(f"const int dd_heir_exchange_count = {len(self.heir_ex)};")
        L.append("const DDTrap dd_traps[DG_COUNT] = {" + ", ".join(
            "{NULL}" if t is None else "{%s, {%s}, {%s}, %d}" % (
                c_str(t[0]), ", ".join("%rf" % -h for h, _ in t[1]), ", ".join("{%d, %d}" % tuple(i) for _, i in t[1]), t[2])
            for t in self.traps) + "};")
        L.append("const int16_t dd_item_effect[10] = {" + ", ".join(str(-1 if i is None else i) for i in self.item_eff) + "};")
        L.append("const DDObstacle dd_obstacles[DG_COUNT] = {" + ", ".join(
            "{NULL}" if o is None else "{%s, %rf, %d, %d}" % (c_str(o[0]), o[1], int(o[2]), o[3]) for o in self.obstacles) + "};")
        L.append("const float dd_trap_base[7] = {" + ", ".join("%rf" % float(x) for x in (self.trap_base + [0] * 7)[:7]) + "};")
        L.append(f"const float dd_trap_scout_bonus = {self.trap_bonus!r}f;")
        L.append("const float dd_corridor_return[3][5] = {" + ", ".join(
            "{" + ", ".join("%rf" % v for v in row) + "}" for row in self.ret) + "};")
        L.append("const DDActSide dd_act_sides[] = {" + ", ".join(
            "{%d, %rf, %d, %d, %s, %s}" % (t, float(w), a1, a2, c_str(s), c_str(d)) for t, w, a1, a2, s, d in self.act_sides) + "};")
        L.append("const DDActivity dd_activities[6] = {" + ", ".join(
            "{%rf, %d, %d, {%s}, %d, %s, %s, %s, %s, %s}" % (float(p), f, n, ", ".join(map(str, req)) or "0", len(req),
                                                           c_str(r), c_str(c), c_str(m), c_str(k), c_str(nm))
            for p, f, n, req, r, c, m, k, nm in self.acts) + "};")
        L.append("const DDTree dd_trees[] = {")
        for tid, costs in self.trees:
            cs = ", ".join("{" + ", ".join(map(str, c)) + "}" for c in costs)
            L.append(f"  {{{c_str(tid)}, {len(costs)}, {{{cs}}}}},")
        L += ["};", f"const int dd_tree_count = {len(self.trees)};", "const DDTreeValue dd_tree_values[] = {"]
        L += [f"  {{{t}, {lv}, {k}, {c_float(v)}, {m}}}," for t, lv, k, v, m in self.tree_values]
        L += ["};", f"const int dd_tree_value_count = {len(self.tree_values)};"]
        L.append("const char *const dd_loot_ids[] = {" + ", ".join(c_str(k) for k in self.loot_ids) + "};")
        L.append(f"const int dd_loot_id_count = {len(self.loot_ids)};")
        L += ["const DDCurio dd_curios[] = {"]
        L += [f"  {{{c_str(a)}, {c_str(b)}, {c_str(sp)}, {rg}, {gd}, {rf}, {rn}, {itf}, {itn}}},"
              for a, b, sp, rg, gd, rf, rn, itf, itn in self.curio_rows]
        L += ["};", f"const int dd_curio_count = {len(self.curio_rows)};", ""]
        L.append("const DDCampEffect dd_camp_effects[] = {")
        L += [f"  {{{t}, {sl}, {bi}, {c_float(a)}, {c_float(ch)}}}," for t, sl, bi, a, ch in self.camp_effects] or ["  {0}"]
        L += ["};", "const DDCampSkill dd_camp_skills[] = {"]
        L += [f"  {{{c_str(i)}, {c_str(n)}, {c}, {u}, {cl}, {f}, {k}, {t}}}," for i, n, c, u, cl, f, k, t in self.camp_skills]
        L += ["};", f"const int dd_camp_skill_count = {len(self.camp_skills)};", ""]
        L.append("const DDMapParams dd_map_params[] = {")
        for m in self.map_params:
            pr = lambda v: "{" + f"{v[0]}, {v[1]}" + "}"
            L.append(f"  {{{m['length']}, {m['quest']}, {m['dungeon']}, {m['rooms']}, {m['corridors']}, {m['gw']}, {m['gh']}, "
                     f"{m['spacing']}, {m['goal']}, {m['mfd']}, {c_float(m['conn'])}, {pr(m['hb'])}, {pr(m['ht'])}, "
                     f"{pr(m['ho'])}, {pr(m['hc'])}, {pr(m['hh'])}, {pr(m['rb'])}, {pr(m['gc'])}, {pr(m['gt'])}, {pr(m['sr'])}}},")
        L += ["};", f"const int dd_map_param_count = {len(self.map_params)};", ""]
        L.append("const DDQuestOption dd_quest_options[] = {")
        L += [f"  {{{d}, {r}, {q}, {l}, {c_float(c)}}}," for d, r, q, l, c in self.quest_options]
        L += ["};", f"const int dd_quest_option_count = {len(self.quest_options)};"]
        L.append("const uint8_t dd_quests_per_visit[8] = {" + ", ".join(map(str, self.quests_per_visit)) + "};")
        L.append("const uint8_t dd_dungeon_unlock[DG_COUNT] = {" + ", ".join(map(str, self.dungeon_unlock)) + "};")
        L.append("const DDUpgrades dd_upgrades[] = {  /* [mode * hero count + class] */")
        arr = lambda xs: "{" + ", ".join(map(str, xs)) + "}"
        for m in range(3):
            for h in self.heroes:
                wc, wl, ac, al, sk = h["upgrades"][m]
                L.append(f"  {{{arr(wc)}, {arr(wl)}, {arr(ac)}, {arr(al)}, "
                         f"{{{', '.join(arr(c) for c, _ in sk)}}}, {{{', '.join(arr(l) for _, l in sk)}}}}},")
        L += ["};"]
        L.append("const DDMonsterClass dd_monsters[] = {")
        for m in self.monsters:
            res = ", ".join(c_float(r) for r in m.get("res", [0] * 8))
            code_c = self.loot_id(m["loot"][0])
            L.append(f"  {{{c_str(m['id'])}, {c_str(m['name'])}, {m['size']}, {m['types']}, "
                     f"{m['flags']}, {m['tpr']}, {m.get('hp', 1)}, {c_float(m.get('def'))}, "
                     f"{c_float(m.get('prot'))}, {m.get('spd', 0)}, {{{res}}}, "
                     f"{m.get('skill_first', 0)}, {m.get('skill_count', 0)}, {m['riposte']}, "
                     f"{m['brain']}, {m['corpse']}, {code_c}, {m['loot'][1]}, {c_str(m['sprite'])}, "
                     f"{c_str(m['life_link'])}, {m['captor_full']}, {m['captor_empty']}, {c_str(m['captor_for'])}, "
                     f"{c_float(m['captor_damage'])}, {m['captor_dd']}, {m['shared']}, {len(m['shift'])}, {m['shift_every']}, "
                     f"{{{', '.join(str(x[0]) for x in (m['shift'] + [(-1, 0, 0)] * 3)[:3])}}}, "
                     f"{{{', '.join(c_float(x[1]) for x in (m['shift'] + [(-1, 0, 0)] * 3)[:3])}}}, "
                     f"{{{', '.join(str(x[2]) for x in (m['shift'] + [(-1, 0, 0)] * 3)[:3])}}}, "
                     f"{c_str(m['companion'])}, {m['comp_buffs'][0]}, {m['comp_buffs'][1]}, {c_float(m['comp_heal'])}, "
                     f"{m['control_stress']}, {m['spawn'][0]}, {m['spawn'][1]}, {m['boss']}, "
                     f"{m['flags2']}, {m['death_effs'][0]}, {m['death_effs'][1]}, {c_float(m['carry_hp'])}, "
                     f"{c_str(m['death_dmg_base'])}, {m['death_dmg']}, {m['react'][0]}, {m['react'][1]}, {m.get('prefskill', -1)}}},")
        L += ["};", f"const int dd_monster_count = {len(self.monsters)};", ""]
        L.append("const DDSkillDesire dd_skill_desires[] = {")
        L += [f"  {{{c_str(s) if s else 'NULL'}, {c_float(c)}, {ty}, {tn}, {fo}, {ks}, {c_str(al) if al else 'NULL'}, {c_float(hp)}, "
              f"{{{', '.join(map(str, lo))}}}, {{{', '.join(map(str, hi))}}}}},"
              for s, c, ty, tn, fo, ks, al, hp, lo, hi in self.skill_desires] or ["  {0}"]
        L += ["};", "const DDTargetDesire dd_target_desires[] = {"]
        L += [f"  {{{t}, {p}, {c_str(s) if s else 'NULL'}, {c_float(c)}}}," for t, p, s, c in self.target_desires] or ["  {0}"]
        L += ["};", "const DDBonusDesire dd_bonus_desires[] = {"]
        L += [f"  {{{t}, {w}, {c_str(sk) if sk else 'NULL'}, {c_str(tr)}, {c_str(al)}, {a0}, {a1}, {m0}, {m1}, {sz}, {ig}}},"
              for t, w, sk, tr, al, a0, a1, m0, m1, sz, ig in self.bonus_desires] or ["  {0}"]
        L += ["};", "const DDBrain dd_brains[] = {"]
        L += [f"  {{{c_str(b['id'])}, {b.get('skill_first', 0)}, {b.get('skill_count', 0)}, "
              f"{b.get('target_first', 0)}, {b.get('target_count', 0)}, "
              f"{b.get('bonus_first', 0)}, {b.get('bonus_count', 0)}}}," for b in self.brains]
        L += ["};", f"const int dd_brain_count = {len(self.brains)};", ""]
        L.append("const DDEncounter dd_encounters[] = {")
        for di, lvl, kind, n, ch, ids, cond in self.encounters:
            ids = (ids + [-1] * 4)[:4]
            L.append(f"  {{{di}, {lvl}, {kind}, {n}, {c_float(ch)}, {{{', '.join(map(str, ids))}}}, {c_float(cond)}}},")
        L += ["};", f"const int dd_encounter_count = {len(self.encounters)};",
              "const int16_t dd_enc_tutorial[2] = {%s};" % ", ".join(str(i) for i in (self.tutorial_enc + [-1, -1])[:2]), ""]
        L.append("const DDPlotRoom dd_plot_rooms[] = {")
        L += [f"  {{{x}, {y}, {sp}, {e}, {c}}}," for x, y, sp, e, c in self.plot_rooms]
        L += ["};", "const DDPlotCorr dd_plot_corrs[] = {"]
        for a, b, segs in self.plot_corrs:
            sg = [t for t, _ in segs] + [0] * (10 - len(segs))
            rf = [r for _, r in segs] + [-1] * (10 - len(segs))
            L.append(f"  {{{a}, {b}, {len(segs)}, {{{', '.join(map(str, sg))}}}, {{{', '.join(map(str, rf))}}}}},")
        L += ["};", "const DDPlotQuest dd_plot_quests[DD_PLOT_ALL] = {"]
        tix = {r[0]: i for i, r in enumerate(self.trinket_rows)}
        qix = {x["id"]: i for i, x in enumerate(json.loads((self.game / "shared/quirk/quirk_library.json").read_text())["quirks"])}

        def ql(lst):
            lst = [(qix[a], w) for a, w in lst if a in qix]
            return (f"{len(lst)}, {{{', '.join(str(a) for a, _ in lst) or '0'}}}, "
                    f"{{{', '.join(str(int(w)) for _, w in lst) or '0'}}}")
        for q in self.plot_quests:
            L.append(f"  {{{q['quest']}, {q['length']}, {q['retreat']}, {q['goals']}, {q['boss']}, "
                     f"{q['rooms'][0]}, {q['rooms'][1]}, {q['corrs'][0]}, {q['corrs'][1]}, {q['gold']}, {q['crests']}, {q['xp']}, "
                     f"{c_str(q['name'])}, {c_str(q['desc'])}, {c_str(q['tip'])}, {q['dungeon']}, {q['level']}, "
                     f"{tix.get(q['trinket'], -1)}, {TRINKET_RARITIES.index(q['rarity']) if q['rarity'] in TRINKET_RARITIES else -1}, "
                     f"{q['ignore_upgrades']}, {ql(q['qwin'])}, {ql(q['qlose'])}}},")
        L += ["};", "const char *const dd_epilog[] = {" + ", ".join(c_str(x) for x in self.epilog) + "};",
              f"const int dd_epilog_count = {len(self.epilog)};", ""]
        coach = [" ".join(x.split()) for x in self.str.all.get("str_stagecoach_idle", []) if x]
        L += ["const char *const dd_coach_idle[] = {" + ", ".join(c_str(x) for x in coach or [""]) + "};",
              f"const int dd_coach_idle_count = {len(coach)};"]
        L.append("const char *const dd_dungeon_names[DG_COUNT] = {" +
                 ", ".join(c_str(n) for _, _, n in DUNGEONS) + ", " + c_str(self.str.get("town_name_town", "The Hamlet")) + "};")
        L.append("const char *const dd_dungeon_dirs[DG_COUNT] = {" +
                 ", ".join(c_str(f) for _, f, _ in DUNGEONS) + ", \"town\"};  /* DG_TOWN: the brigand incursion */")
        out.mkdir(parents=True, exist_ok=True)
        (out / "dd_data.c").write_text("\n".join(L) + "\n")
        (out / "manifest.json").write_text(json.dumps(self.manifest, indent=1))


ACTIVITIES = ["bar", "gambling", "brothel", "meditation", "prayer", "flagellation", "treatment", "disease_treatment"]
TE_OPS = {"free_activity": 0, "activity_cost_change": 1, "activity_lock": 2, "provision_item_type_cost_change": 3,
          "bonus_recruit": 4, "idle_resolve_level": 5, "dead_recruit": 6, "upgrade_tag_free": 7,
          "upgrade_tag_discount": 8, "embark_party_buff": 9, "idle_buff": 10, "in_activity_buff": 11,
          "remove_quest_hero_level_restriction": 12, "plot_quest": 13, "trinket_retention_add_from_storage": 14}
PLOT_EVENT_QUESTS = {"plot_town_invasion_0": 4, "plot_crow_trinket": 5}  # PQ_INVASION, PQ_CROW


JOURNAL_PAGES = 22  # journal.string_table.xml journal_page_title_0..21


MODES = ["", "radiant", "new_game_plus"]  # GM_DARKEST (base), GM_RADIANT, GM_STYGIAN
DARK_KEYS = ["stress_chance_increase", "stress_damage_increase", "monster_attack_increase", "monster_damage_increase",
             "monster_crit_increase", "player_crit_increase", "player_def_increase", "player_scouting_increase",
             "monsters_surprised_increase", "heroes_surprised_increase"]


# Game-mode rule overrides (Radiant / Darkest / Stygian): darkness table, XP thresholds, limits.
def mode_rules(ex):
    """Per game mode: rules.json, progression and town event settings (modes/<m>/ override the base files)."""
    def load(mode, rel):
        f = ex.game / "modes" / mode / rel if mode else None
        return json.loads((f if f and f.exists() else ex.game / rel).read_text())
    ex.rules = []
    for m in MODES:
        r = load(m, "shared/rules.json")
        dark = sorted(r["darkness"]["range_table"], key=lambda b: -b["range"]["lower"])[:5]
        hs = r["hallway_stress"]
        ll = {x["key"]: x["data"] for x in r["tile_light_loss"]}
        roster = load(m, "campaign/roster/roster.variables.json")
        thr = (roster["resolve_level_thresholds"] + [255] * 8)[:8]  # hero XP per resolve level
        te = next(s["event_chance_per_town_visits"] for s in
                  load(m, "campaign/town_events/town_events.settings.json")["settings"] if s["id"] == "normal")
        ex.rules.append(dict(
            dark_lower=[max(-1000.0, float(b["range"]["lower"])) for b in dark],
            dark=[[float(b["value"].get(k, 0)) for k in DARK_KEYS] for b in dark],
            crit_comp_chance=r["monster_crit"]["companion_stress_chance"],
            dd_comp_chance=r["deaths_door_companion_stress_chance"],
            dd_comp_chance_rep=r["deaths_door_companion_stress_chance_repeat"],
            pass_stress=r["passed_turn_stress_dmg"], dd_self=r["deaths_door_self_stress_dmg"],
            dd_self_rep=r["deaths_door_self_stress_dmg_repeat"], dd_comp=r["deaths_door_companion_stress_dmg"],
            dd_comp_rep=r["deaths_door_companion_stress_dmg_repeat"],
            hall=[hs["hallway_per_tile_stress_damage_fwd"], hs["hallway_per_tile_stress_damage_chance_fwd"],
                  hs["hallway_per_tile_stress_damage_backing_up"], hs["hallway_per_tile_stress_damage_chance_backing_up"]],
            light_new=ll.get("dim", 6), light_old=ll.get("clear", 1), level_xp=thr, te=(te + [1.0] * 4)[:4],
            idle_heal=roster["town_visit_town_progression"]["idle_hero_stress_heal"],
            act_mult=(load(m, "campaign/estate/estate.json")["hero_activity_cost_multiplier_table"] + [2.0] * 7)[:7],
            restrict=(load(m, "campaign/quest/quest.restriction.json")["restriction"]["difficulty"]
                      ["resolve_level_threshold_table"] + [99] * 7)[:7],
            week_limit=r.get("new_game_plus_week_limit", 0), death_limit=r.get("new_game_plus_hero_death_limit", 0)))


# game text the menus need (dd_ui_str[], order = UiStr in dd_types.h)
UI_STRINGS = ["str_select_campaign", "fe_flow_mode_radiant_confirm", "fe_flow_mode_base_confirm",
              "fe_flow_mode_new_game_plus_confirm", "str_game_mode_select_radiant_tooltip",
              "str_game_mode_select_base_tooltip", "str_game_mode_select_new_game_plus_tooltip",
              "dungeon_name_old_road", "str_old_road_tip", "town_quest_goal_start_plural_tutorial_room",
              "str_crypts_tip", "str_weald_tip", "str_warrens_tip", "str_cove_tip", "str_darkestdungeon_tip",
              "str_quest_complete_banner", "raid_results_quest_inventory_title", "raid_results_party_gold_inventory_title",
              "raid_results_party_heirloom_inventory_title", "raid_results_progression_return_to_town",
              "raid_results_progression_heroes", "raid_results_hero_resolve_from_quest", "raid_results_new_quirks_title",
              "raid_results_quest_result_was_completed", "raid_results_quest_result_was_not_completed_defeat",
              "raid_results_quest_result_was_not_completed_escape", "town_name_activity_log", "str_caretaker_goals_heading",
              "str_caretaker_goals_quest_goals_heading", "str_caretaker_goal_plot_tutorial_crypts",
              "str_caretaker_goal_plot_town_invasion_0"] + \
             [f"str_caretaker_goal_plot_darkest_dungeon_{n}" for n in range(1, 5)] + \
             [f"str_caretaker_goal_plot_kill_{b}_{lv}" for b in
              ("necromancer", "prophet", "hag", "brigand_cannon", "swine_prince", "formless_flesh", "siren", "drowned_crew")
              for lv in (1, 2, 3)] + [f"str_resolve_{n}" for n in range(7)] + ["str_stagecoach_roster_full_rejection", "camping_skill_requirement_has_quirk",
                                                                  "str_its_a_trap", "resistance_trap_disarm_format"]
BOSS_KEYS = ["necromancer", "prophet", "hag", "cannon", "swine_prince", "formless", "siren", "drowned"]  # goal order


# Random town events (campaign/town_events) with chances, cooldowns and operations.
def town_events(ex):
    """campaign/town_events: base events (plot quests, trinket retention and stock-size events are
    left out), their ops and the quest-type guarantees."""
    root = ex.game / "campaign" / "town_events"
    evs = json.loads((root / "base.town_events.events.json").read_text())["events"]
    dg = {"crypts": 0, "weald": 1, "warrens": 2, "cove": 3}
    tags = {"armour": 0, "weapon": 1, "building": 2, "trinket": 3}
    buffs = {b["id"]: b for b in json.loads((ex.game / "shared/buffs/base.buffs.json").read_text())["buffs"]}
    ex.te_rows, ex.te_ops, idx = [], [], {}
    for e in evs:
        if e["id"] == "provision_reduced_amounts" or any(x["type"] not in TE_OPS for x in e["data"]):
            continue
        first = len(ex.te_ops)
        for x in e["data"]:
            t, s, n = TE_OPS[x["type"]], x["string_data"], float(x["number_data"])
            arg = 0
            if t in (0, 1, 2):
                arg = ACTIVITIES.index(s)
            elif t == 3:
                arg = 1 if s == "supply" else 0
            elif t in (4, 5):
                if s not in HEROES:
                    continue  # musketeer: DLC
                arg = HEROES.index(s)
            elif t in (7, 8):
                arg = tags[s]
            elif t == 13:
                arg = PLOT_EVENT_QUESTS[s]
            elif t in (9, 10, 11):  # buff: stat in arg (0 dmg, 1 resolve xp, 2 resolve check, 3 stress heal)
                b = buffs[s]
                arg = {"combat_stat_multiply": 0, "resolve_xp_bonus_percent": 1, "resolve_check_percent": 2,
                       "stress_heal_received_percent": 3}[b["stat_type"]]
                if arg == 0 and b.get("stat_sub_type") != "damage_low":
                    continue  # damage_low + damage_high: one op
                n = float(b["amount"])
                d = next((v for k, v in dg.items() if f"_{k}_" in s), -1)
                if t == 11:
                    d = next(i for i, a in enumerate(ACTIVITIES) if f"_{a}_" in s)
                arg |= (d + 1) << 4  # high nibble: dungeon + 1 (embark) / activity + 1 (in activity)
            ex.te_ops.append((t, arg, n))
        r = e["requirements"]
        idx[e["id"]] = len(ex.te_rows)
        ex.te_rows.append((e["id"], ex.str.t.get("town_event_title_" + e["id"], e["id"]),
                           ex.str.t.get("town_event_description_" + e["id"], ""), float(e["base_chance"]),
                           float(e["per_not_rolled_additional_chance"]),
                           255 if e.get("is_unique") else int(e["cooldown"]), int(r["minimum_week"]),
                           int(r["dead_heroes"]), first, len(ex.te_ops) - first,
                           max([int(h["level"]) for h in r["hero_level_counts"]] or [0]),
                           max([int(h["count"]) for h in r["hero_level_counts"]] or [0]),
                           int(r.get("trinket_storage_count", 0))))
    g = json.loads((root / "town_events.quest_type_event_guarantees.json").read_text())["quest_type_event_guarantees"]
    qt = {"explore": 0, "cleanse": 1, "kill_boss": 2, "gather": 3, "activate": 4, "inventory_activate": 5}
    ex.te_guar = [(dg[x["dungeon_type"]], qt[x["quest_type"]], idx[x["event_id"]]) for x in g if x["event_id"] in idx]
    heir = {"bust": 0, "portrait": 1, "deed": 2, "crest": 3}  # HEIR_* order
    ex.heir_ex = [(heir[x["exchange_from_type"]], int(x["exchange_from_amount"]), heir[x["exchange_to_type"]],
                   int(x["exchange_to_amount"])) for x in json.loads((ex.game / "campaign/heirloom_exchange/heirloom_exchange.json")
                                                                     .read_text())["exchange_rates"] if x["exchange_from_type"] in heir and x["exchange_to_type"] in heir]
    ex.te_chance = next(s["event_chance_per_town_visits"] for s in
                        json.loads((root / "town_events.settings.json").read_text())["settings"] if s["id"] == "normal")


TOWN_ACTS = [("tavern", "bar"), ("tavern", "gambling"), ("tavern", "brothel"),
             ("abbey", "meditation"), ("abbey", "prayer"), ("abbey", "flagellation")]  # Hero.busy 1..6
SIDE_TYPES = ["activity_lock", "go_missing", "add_quirk", "apply_buff", "add_currency", "remove_currency",
              "add_trinket", "remove_trinket"]  # AS_*


STORY_KEYS = {"building_name": "B", "hero_name": "H", "amount": "N", "stress_amount": "N", "quirk_name": "Q",
              "disease_name": "Q", "trinket_name": "T", "description": "D", "affliction": "A"}


# Convert activity-log story text placeholders into our own format.
def log_story(s):
    """Activity log text: colour markup dropped, {?key}%s placeholders -> '$' + STORY_KEYS letter."""
    s = re.sub(r"\{colour_start\|[^}]*\}|\{colour_end\}", "", " ".join(s.split()))
    return re.sub(r"\{\?([a-z_]+)\}%[a-z]", lambda m: "$" + STORY_KEYS.get(m.group(1), "?"), s)


# Tavern/abbey activities and their side-effect tables.
def town_activities(ex):
    """buildings/<b>/<b>.building.json activities: side effects (one roll per week, then a weighted
    result; a result's data options are flattened into rows weighted result * option share),
    not_have_quirks requirements and the activity log stories (miscellaneous.string_table)."""
    qix = {x["id"]: i for i, x in enumerate(json.loads((ex.game / "shared/quirk/quirk_library.json").read_text())["quirks"])}
    ex.acts, ex.act_sides = [], []
    for ai, (b, a) in enumerate(TOWN_ACTS):
        acts = json.loads((ex.game / f"campaign/town/buildings/{b}/{b}.building.json").read_text())["data"]["activities"]
        d = next(x["data"] for x in acts if x["id"] == a)
        req = [qix[q] for r in d.get("requirements", []) if r["type"] == "not_have_quirks"
               for q in r["data"]["quirk_library_names"] if q in qix][:8]
        st = lambda k: log_story(ex.str.t.get(f"str_{a}_{k}", ""))
        first = len(ex.act_sides)
        for r in d["side_effects"]["results"]:
            if r["type"] not in SIDE_TYPES or float(r["chance"]) <= 0:
                continue
            t, w, opts = SIDE_TYPES.index(r["type"]), float(r["chance"]), r["data"] or [{"chance": 1.0}]
            tot = sum(float(o.get("chance", 1)) for o in opts) or 1
            for o in opts:
                ow = w * float(o.get("chance", 1)) / tot
                a1 = a2 = -1
                story, desc = "", ""
                if t == 0: story = st("activity_lock_story")
                elif t == 1: a1, story = int(o["duration"]), st("go_missing_story")
                elif t == 2:
                    if o["quirk_library_name"] not in qix: continue
                    a1, story = qix[o["quirk_library_name"]], st(f"add_quirk_{o['quirk_library_name']}_story")
                elif t == 3:
                    ids = [ex.buff_index[i] for i in o["buff_library_ids"] if i in ex.buff_index]
                    if not ids: continue
                    a1, a2 = ids[0], ids[1] if len(ids) > 1 else -1
                    story = st(f"add_buff_{o['buff_library_ids'][0]}_story")
                    desc = st(f"add_buff_{o['buff_library_ids'][0]}_story_desc")
                elif t in (4, 5): a1, story = int(o["amount"]), st("currency_gained_story" if t == 4 else "currency_lost_story")
                else:
                    if o["rarity"] not in TRINKET_RARITIES: continue
                    a1, story = TRINKET_RARITIES.index(o["rarity"]), st("add_trinket_story" if t == 6 else "remove_trinket_story")
                ex.act_sides.append((t, ow, a1, a2, story, desc))
        ex.acts.append((float(d["side_effects"]["chance"]), first, len(ex.act_sides) - first, req,
                        st("stress_relief_story"), st("stress_relief_affliction_cured_story"),
                        st("go_missing_found_story"), st("committed"), ex.str.get(f"town_activity_name_{a}", a)))


# Trap and obstacle definitions per dungeon.
def traps(ex):
    """props/trap_definitions.json + dungeons/<d>/<d>.props.darkest traps: one trap type per dungeon,
    with health (fraction of max HP) and fail effects per level (1/3/5, 6 uses 5); rules.json
    difficulty_trap_base (by dungeon level) and trap_scout_disarm_bonus."""
    defs = {t["name"]: t for t in json.loads((ex.game / "props/trap_definitions.json").read_text())["props"]}
    rules = json.loads((ex.game / "shared/rules.json").read_text())
    ex.trap_base = rules["difficulty_trap_base"]
    # corridor_return_content: base_chance + base_dark_mod_table (lowest_excluded) per torch band
    ex.ret = []
    for key in ("ac_battle", "ac_hunger", "ac_trap"):
        e = next(x["data"] for x in rules["corridor_return_content"] if x["key"] == key)
        def mod(torch, tab=e["base_dark_mod_table"]):
            for rr in tab["range_table"]:
                lo, hi = rr["range"]["lower"], rr["range"]["upper"]
                if (lo < torch <= hi) if tab.get("lowest_excluded") else (lo <= torch < hi):
                    return float(rr["value"])
            return 0.0
        ex.ret.append([float(e["base_chance"]) + mod(t) for t in (0, 25, 50, 75, 100)])
    ex.trap_bonus = float(rules["trap_scout_disarm_bonus"])
    ex.traps = []
    for _, folder, _ in DUNGEONS + [("town", "town", "")]:
        f = ex.game / "dungeons" / folder / f"{folder}.props.darkest"
        m = re.search(r"^traps:.*\.types\s+(\S+)", f.read_text(), re.M) if f.exists() else None
        t = defs.get(m.group(1)) if m else None
        if not t:
            ex.traps.append(None)
            continue
        base = t["default_data"]
        rows = []
        for lv in (1, 3, 5, 5):
            v = next((x for x in t.get("difficulty_variations", []) if x["level"] == lv), {})
            fail = v.get("fail_effects", base.get("fail_effects", []))
            hp = v.get("health", base.get("health", 0.0))
            idx = [ex.effect(n) for n in fail][:2]
            idx = [i if i is not None else -1 for i in idx] + [-1] * (2 - len(idx))
            rows.append((float(hp), idx))
        succ = base.get("success_effects", [])
        s = ex.effect(succ[0]) if succ else -1
        ex.traps.append((t["name"], rows, s if s is not None else -1))
    # obstacles: props/prop_definitions.json "obstacle" defaults (no shovel: health, torchlight,
    # fail_effects on each hero) + obstacle_definitions.json graphics per dungeon
    pdef = next(x["default_data"] for x in json.loads((ex.game / "props/prop_definitions.json").read_text())["props"]
                if x["name"] == "obstacle")
    odefs = {t["name"]: t["default_data"] for t in json.loads((ex.game / "props/obstacle_definitions.json").read_text())["props"]}
    ex.obstacles = []
    for _, folder, _ in DUNGEONS + [("town", "town", "")]:
        f = ex.game / "dungeons" / folder / f"{folder}.props.darkest"
        m = re.search(r"^obstacles:.*\.types\s+(\S+)", f.read_text(), re.M) if f.exists() else None
        name = m.group(1) if m else None
        o = dict(pdef, **odefs.get(name, {})) if name else None
        if not o:
            ex.obstacles.append(None)
            continue
        fe = [ex.effect(n) for n in o.get("fail_effects", [])]
        fe = [i for i in fe if i is not None][:1] or [-1]
        ex.obstacles.append((name, -float(o.get("health", 0)), -float(o.get("torchlight", 0)), fe[0]))


# Entry point: run every exporter step in dependency order, then write the files and print a
# short summary (plus warnings about effects or fields that were not understood).
def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    game, out = Path(sys.argv[1]).expanduser(), Path(sys.argv[2])
    ex = Exporter(game)
    for h in HEROES:
        ex.hero(h)
    for di, (_, folder, _) in enumerate(DUNGEONS):
        ex.encounters_for(di, folder)
    ex.traits()
    ex.curios()
    ex.camping()
    ex.maps_and_quests()
    ex.plot_maps()
    ex.loot()
    ex.building_upgrades()
    ex.quirks()
    ex.trinkets()
    town_events(ex)
    town_activities(ex)
    traps(ex)
    # supply effects (effects/base.effects.darkest "bandage" ...), ItemId order
    ex.item_eff = [ex.effect(n) if n else None for n in
                   (None, None, None, "bandage", "antivenom", "medicinal_herbs", "holy_water", None, "laudanum", None)]
    mode_rules(ex)
    ex.write(out)
    print(f"curios {len(ex.curio_rows)} ({len(ex.curio_results)} results)")
    print(f"heroes {len(ex.heroes)}, monsters {len(ex.monsters)}, skills {len(ex.skills)}, "
          f"effects {len(ex.effects)} ({len(ex.eff_ops)} ops), buffs {len(ex.buffs)}, "
          f"brains {len(ex.brains)}, encounters {len(ex.encounters)}")
    if ex.missing_effects:
        print(f"missing effects ({len(ex.missing_effects)}): {sorted(ex.missing_effects)[:10]}")
    if ex.unsupported_fields:
        print("unsupported effect fields:", dict(sorted(ex.unsupported_fields.items(), key=lambda x: -x[1])))


if __name__ == "__main__":
    main()
