#!/usr/bin/env python3
"""Export the hamlet and title-screen Spine sprites (buildings, ground, logo) for the PSP.

Usage: export_town.py <game_dir> <out_dir>
Writes <out_dir>/sprites/town_<building>/<anim>.dda at hamlet scale (1920 px wide town -> 480)
and <out_dir>/sprites/titles/<anim>.dda for the animated logo.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from export_art import export_anim  # noqa: E402

TOWN_SCALE = 0.25  # the hamlet is laid out for 1920x1080
BUILDINGS = ["stage_coach", "guild", "blacksmith", "tavern", "abbey", "sanitarium", "camping_trainer",
             "graveyard", "nomad_wagon", "statue"]


# Convert every hamlet building sprite and the animated title logo using export_art.export_anim.
def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    game, out = Path(sys.argv[1]).expanduser(), Path(sys.argv[2])
    scratch = out / ".scratch.json"
    jobs = [("town_ground", game / "fx/town_ground", TOWN_SCALE)]
    for b in BUILDINGS:
        lv = game / f"fx/town_{b}_level01"
        jobs.append((f"town_{b}", lv if lv.exists() else game / f"fx/town_{b}", TOWN_SCALE))
    jobs.append(("campfire", game / "fx/campfire", 0.3))
    # curio props (all dungeons): drawn in rooms and corridors at the actors' world scale
    for skel in sorted((game / "props").glob("*/curios/*/*.skel")):
        jobs.append((f"curio_{skel.parent.name}", skel.parent, 0.3))
    # trap props (props/shared/traps/<t>): "idle" armed, "sprung" set off
    for t in sorted((game / "props/shared/traps").iterdir()):
        for anim in ("idle", "sprung"):
            skel = t / f"{t.name}.skel"
            if skel.exists():
                dst = out / "sprites" / f"trap_{t.name}"
                dst.mkdir(parents=True, exist_ok=True)
                export_anim(skel, skel.with_suffix(".atlas"), t, dst / f"{anim}.dda", scratch, None, world_scale=0.3, anim=anim)
    # title logo: "show" (letters and torch appear) then "torch_loop" (the flame, repeated)
    t = game / "fx/titles/titles.sprite.skel"
    for anim in ("show", "torch_loop"):
        dst = out / "sprites" / "titles"
        dst.mkdir(parents=True, exist_ok=True)
        export_anim(t, t.with_suffix(".atlas"), t.parent, dst / f"{anim}.dda", scratch, None, world_scale=0.3, anim=anim)
    # hall obstacles: "idle" blocking, "clear" being cleared
    for o in sorted((game / "props/shared/obstacles").iterdir()):
        skel = o / f"{o.name}.skel"
        if not skel.exists():
            continue
        for anim in ("idle", "clear"):
            dst = out / "sprites" / f"obstacle_{o.name}"
            dst.mkdir(parents=True, exist_ok=True)
            export_anim(skel, skel.with_suffix(".atlas"), o, dst / f"{anim}.dda", scratch, None, world_scale=0.3, anim=anim)
    for name, folder, scale in jobs:
        skels = sorted(folder.glob("*.skel"))
        if not skels:
            print(f"missing {folder}")
            continue
        dst = out / "sprites" / name
        dst.mkdir(parents=True, exist_ok=True)
        for skel in skels[:1]:
            anim = "idle"
            ts, pw, ph, feats = export_anim(skel, skel.with_suffix(".atlas"), folder, dst / f"{anim}.dda",
                                            scratch, None, world_scale=scale)
            print(f"{name}: {pw}x{ph} tex {ts:.2f} {sorted(feats)}")
    scratch.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
