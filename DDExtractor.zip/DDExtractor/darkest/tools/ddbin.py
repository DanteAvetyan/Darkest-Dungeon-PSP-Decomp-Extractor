#!/usr/bin/env python3
"""Game data tables <-> binary blob, so the EBOOT carries no data from the game.

The exporter (export_game_data.py) writes C text (dd_data.c).  This tool turns that text into
`gen/dd_data.bin` (loaded at run time by src/core/dd_load_gen.c) using a schema read from dd_types.h.

  ddbin.py spec  dd_types.h dd_data.c  spec.json        schema + table list (developer step)
  ddbin.py gen   spec.json  loader.c  tables.h          generate the C loader and the extern block
  ddbin.py bin   spec.json  dd_data.c out.bin           the blob (the extractor runs this)

Blob: "DDDT" | schema hash u32 | table count u32 | pool size u32 | string pool | tables...
Each table: array tables start with the element count (u32); all fields follow in declaration
order, little endian; strings are u32 offsets into the pool (0xFFFFFFFF = NULL).
"""
import json
import re
import struct
import sys
import zlib

SCALARS = {
    'int8_t': ('b', 1), 'uint8_t': ('B', 1), 'int16_t': ('h', 2), 'uint16_t': ('H', 2),
    'int32_t': ('i', 4), 'uint32_t': ('I', 4), 'int': ('i', 4), 'unsigned': ('I', 4),
    'float': ('f', 4), 'char': ('b', 1),
}
NULL_STR = 0xFFFFFFFF


# ---------------------------------------------------------------- header -> schema
def strip_comments(s):
    s = re.sub(r'/\*.*?\*/', ' ', s, flags=re.S)
    return re.sub(r'//[^\n]*', ' ', s)


def eval_expr(expr, names):
    e = re.sub(r'\b0[xX][0-9a-fA-F]+[uUlL]*', lambda m: str(int(m.group(0).rstrip('uUlL'), 16)), expr)
    e = re.sub(r'\b(\d+)[uUlL]+\b', r'\1', e)
    e = re.sub(r"'(.)'", lambda m: str(ord(m.group(1))), e)
    e = re.sub(r'\([A-Za-z_]\w*\)\s*(?=[\w(])', '', e)   # casts such as (int)

    def sub(m):
        if m.group(0) not in names:
            raise KeyError(m.group(0))
        return str(names[m.group(0)])
    e = re.sub(r'\b[A-Za-z_]\w*\b', sub, e)
    if not re.fullmatch(r'[\d\s+\-*/%()<>|&^~.]*', e):
        raise ValueError(expr)
    return int(eval(e, {'__builtins__': {}}, {}))   # noqa: S307 - sanitized above


def parse_header(text):
    text = strip_comments(text)
    names = {}
    events = []
    for m in re.finditer(r'^[ \t]*#[ \t]*define[ \t]+(\w+)(?!\()[ \t]+([^\n]+)', text, flags=re.M):
        events.append((m.start(), 'define', m.group(1), m.group(2)))
    enum_types = set()
    for m in re.finditer(r'typedef\s+enum\s*\w*\s*\{([^}]*)\}\s*(\w+)\s*;', text):
        enum_types.add(m.group(2))
    for m in re.finditer(r'enum\s*\w*\s*\{([^}]*)\}', text):
        events.append((m.start(), 'enum', m.group(1), None))
    events.sort(key=lambda e: e[0])
    for _, kind, a, b in events:
        if kind == 'define':
            try:
                names[a] = eval_expr(b, names)
            except (KeyError, ValueError, SyntaxError):
                pass
        else:
            nxt = 0
            for item in a.split(','):
                item = item.strip()
                if not item:
                    continue
                if '=' in item:
                    n, v = [x.strip() for x in item.split('=', 1)]
                    nxt = eval_expr(v, names)
                else:
                    n = item
                names[n] = nxt
                nxt += 1
    structs = {}
    for m in re.finditer(r'typedef\s+struct\s*\w*\s*\{(.*?)\}\s*(\w+)\s*;', text, flags=re.S):
        fields = []
        for stmt in m.group(1).split(';'):
            stmt = ' '.join(stmt.split())
            if not stmt:
                continue
            parts = stmt.split(',')
            first = re.match(r'^(?P<type>[\w\s]+?)\s*(?P<ptr>\*?)\s*(?P<name>\w+)(?P<dims>(\[[^\]]+\])*)$', parts[0].strip())
            if not first:
                raise ValueError('cannot parse field: ' + stmt)
            base = ' '.join(w for w in first.group('type').split() if w not in ('const', 'struct'))
            decls = [(first.group('ptr'), first.group('name'), first.group('dims'))]
            for p in parts[1:]:
                d = re.match(r'^\s*(\*?)\s*(\w+)((\[[^\]]+\])*)\s*$', p)
                if not d:
                    raise ValueError('cannot parse declarator: ' + p)
                decls.append((d.group(1), d.group(2), d.group(3)))
            for ptr, name, dims in decls:
                dl = [eval_expr(x, names) for x in re.findall(r'\[([^\]]+)\]', dims)]
                fields.append({'name': name, 'type': 'enum' if base in enum_types else base, 'ptr': bool(ptr), 'dims': dl})
        structs[m.group(2)] = fields
    return names, structs


# ---------------------------------------------------------------- C initializer parser
TOKEN = re.compile(r'\s*(?:(?P<str>"(?:\\.|[^"\\])*")|(?P<num>-?(?:0[xX][0-9a-fA-F]+|\d+\.?\d*(?:[eE][-+]?\d+)?)[fFuUlL]*)|(?P<id>[A-Za-z_]\w*)|(?P<p>[{},;=\[\]*]))')


def tokenize(text):
    pos = 0
    n = len(text)
    while pos < n:
        m = TOKEN.match(text, pos)
        if not m:
            if text[pos:].strip() == '':
                return
            raise ValueError('bad token near: ' + text[pos:pos + 40])
        pos = m.end()
        if m.group('str') is not None:
            yield ('str', m.group('str'))
        elif m.group('num') is not None:
            yield ('num', m.group('num'))
        elif m.group('id') is not None:
            yield ('id', m.group('id'))
        else:
            yield ('p', m.group('p'))


ESC = {'n': '\n', 't': '\t', 'r': '\r', '\\': '\\', '"': '"', "'": "'", '0': '\0', 'a': '\a', 'b': '\b', 'f': '\f', 'v': '\v'}


def unescape(lit):
    s = lit[1:-1]
    out = bytearray()
    i = 0
    while i < len(s):
        c = s[i]
        if c != '\\':
            out += c.encode('utf-8')
            i += 1
            continue
        i += 1
        c = s[i]
        if c == 'x':
            j = i + 1
            while j < len(s) and s[j] in '0123456789abcdefABCDEF':
                j += 1
            out.append(int(s[i + 1:j], 16) & 255)
            i = j
        elif c in '01234567':
            j = i
            while j < len(s) and j < i + 3 and s[j] in '01234567':
                j += 1
            out.append(int(s[i:j], 8) & 255)
            i = j
        else:
            out += ESC.get(c, c).encode('utf-8')
            i += 1
    return bytes(out)


def parse_init(toks, pos, names):
    """Returns (value, next_pos).  Values: list for {..}, bytes for strings, int/float, None for NULL."""
    t = toks[pos]
    if t == ('p', '{'):
        items = []
        pos += 1
        while toks[pos] != ('p', '}'):
            v, pos = parse_init(toks, pos, names)
            items.append(v)
            if toks[pos] == ('p', ','):
                pos += 1
        return items, pos + 1
    if t[0] == 'str':
        s = unescape(t[1])
        pos += 1
        while toks[pos][0] == 'str':   # adjacent literals concatenate
            s += unescape(toks[pos][1])
            pos += 1
        return s, pos
    if t[0] == 'num':
        txt = t[1]
        body = txt.rstrip('fFuUlL') if not txt.lower().startswith(('0x', '-0x')) else txt.rstrip('uUlL')
        if re.fullmatch(r'-?0[xX][0-9a-fA-F]+', body):
            return int(body, 16), pos + 1
        if re.fullmatch(r'-?\d+', body) and not txt.endswith(('f', 'F')):
            return int(body), pos + 1
        return float(body), pos + 1
    if t[0] == 'id':
        if t[1] == 'NULL':
            return None, pos + 1
        return names[t[1]], pos + 1
    raise ValueError('unexpected token %r' % (t,))


def parse_data_c(text, names):
    """name -> (type, ptr, dims(list of int|None as written), value)"""
    text = strip_comments(text)
    text = re.sub(r'^[ \t]*#[^\n]*', '', text, flags=re.M)
    out = {}
    pos = 0
    toks = list(tokenize(text))
    # split into top-level statements ending with ';'
    stmts, cur, depth = [], [], 0
    for t in toks:
        if t == ('p', '{'):
            depth += 1
        elif t == ('p', '}'):
            depth -= 1
        if t == ('p', ';') and depth == 0:
            stmts.append(cur)
            cur = []
        else:
            cur.append(t)
    for st in stmts:
        if not st:
            continue
        eq = st.index(('p', '='))
        decl, init = st[:eq], st[eq + 1:]
        fb = next((k for k, t in enumerate(decl) if t == ('p', '[')), len(decl))
        words = [t[1] for t in decl[:fb] if t[0] == 'id']
        ptr = ('p', '*') in decl
        name = None
        dims = []
        i = 0
        while i < len(decl):
            if decl[i] == ('p', '['):
                j = i + 1
                dims.append(None if decl[j] == ('p', ']') else decl[j][1])
                i = j
            i += 1
        # name = last id before the first '['
        first_br = next((k for k, t in enumerate(decl) if t == ('p', '[')), len(decl))
        name = [t[1] for t in decl[:first_br] if t[0] == 'id'][-1]
        type_words = [w for w in words if w not in ('const', name)]
        base = ' '.join(type_words)
        val, _ = parse_init(init + [('p', ';')], 0, names)
        out[name] = (base, ptr, dims, val)
    return out


# ---------------------------------------------------------------- schema / spec
def schema_hash(structs, tables):
    return zlib.crc32(json.dumps([structs, tables], sort_keys=True).encode()) & 0xFFFFFFFF


def make_spec(header_path, data_path):
    names, structs = parse_header(open(header_path, encoding='utf-8').read())
    defs = parse_data_c(open(data_path, encoding='utf-8').read(), names)
    tables = []
    for name, (base, ptr, dims, _val) in defs.items():
        dl = []
        for d in dims:
            dl.append(None if d is None else (int(d) if re.fullmatch(r'\d+', d) else eval_expr(d, names)))
        if base == 'char' and not ptr:
            raise ValueError('unexpected char table ' + name)
        tables.append({'name': name, 'type': base, 'ptr': ptr, 'dims': dl})
    spec = {'enums': {k: v for k, v in names.items() if isinstance(v, int)}, 'structs': structs, 'tables': tables}
    spec['hash'] = schema_hash(structs, tables)
    return spec


# ---------------------------------------------------------------- blob writer
class Writer:
    def __init__(self, spec):
        self.spec = spec
        self.structs = spec['structs']
        self.pool = bytearray()
        self.pool_idx = {}
        self.out = bytearray()

    def string(self, s):
        if s is None:
            return NULL_STR
        if s not in self.pool_idx:
            self.pool_idx[s] = len(self.pool)
            self.pool += s + b'\0'
        return self.pool_idx[s]

    def scalar(self, ftype, v):
        fmt, _ = SCALARS.get(ftype, ('i', 4))
        if ftype == 'float':
            v = float(v)
        else:
            if isinstance(v, float):
                v = int(v)
            if v is None:
                v = 0
            lim = {'b': (-128, 127), 'B': (0, 255), 'h': (-32768, 32767), 'H': (0, 65535), 'i': (-2**31, 2**31 - 1), 'I': (0, 2**32 - 1)}[fmt]
            if not lim[0] <= v <= lim[1]:
                if fmt in 'BHI' and -lim[1] <= v < 0:
                    v &= (1 << (8 * SCALARS.get(ftype, ('i', 4))[1])) - 1   # C wraps negatives to unsigned
                elif fmt in 'bhi' and v <= lim[1] * 2 + 1 and v > lim[1]:
                    v -= (lim[1] + 1) * 2
                else:
                    raise ValueError('value %r does not fit %s' % (v, ftype))
        self.out += struct.pack('<' + fmt, v)

    # -- C aggregate initialisation with brace elision ---------------------------------------
    def put(self, ftype, ptr, dims, items):
        """items: iterator-with-peek over initializers of the enclosing list"""
        if dims:
            n = dims[0]
            first = items.peek()
            if isinstance(first, list):    # braced array
                sub = Peek(items.next())
                for _ in range(n):
                    self.put(ftype, ptr, dims[1:], sub)
            elif isinstance(first, bytes) and ftype == 'char' and not ptr and len(dims) == 1:
                raise ValueError('char arrays unsupported')
            else:                           # elided braces: consume from the same list
                for _ in range(n):
                    self.put(ftype, ptr, dims[1:], items)
            return
        if ptr:
            v = items.next() if items.has() else None
            self.out += struct.pack('<I', self.string(v))
            return
        if ftype in self.structs:
            first = items.peek()
            if isinstance(first, list):
                sub = Peek(items.next())
            else:
                sub = items
            for f in self.structs[ftype]:
                self.put(f['type'], f['ptr'], f['dims'], sub)
            return
        v = items.next() if items.has() else 0
        if isinstance(v, list):
            v = v[0] if v else 0
        self.scalar(ftype, v)

    def table(self, t, value):
        ftype, ptr, dims = t['type'], t['ptr'], t['dims']
        if not dims:
            self.put(ftype, ptr, [], Peek([value]))
            return
        items = value if isinstance(value, list) else [value]
        count = len(items) if dims[0] is None else dims[0]
        self.out += struct.pack('<I', count)
        it = Peek(items)
        for _ in range(count):
            self.put(ftype, ptr, dims[1:], it)


class Peek:
    def __init__(self, seq):
        self.seq = list(seq)
        self.i = 0

    def has(self):
        return self.i < len(self.seq)

    def peek(self):
        return self.seq[self.i] if self.has() else 0

    def next(self):
        v = self.seq[self.i] if self.has() else 0
        self.i += 1
        return v


def make_bin(spec, data_c_text):
    names = dict(spec['enums'])
    defs = parse_data_c(data_c_text, names)
    w = Writer(spec)
    for t in spec['tables']:
        if t['name'] not in defs:
            raise ValueError('missing table ' + t['name'])
        w.table(t, defs[t['name']][3])
    pool = bytes(w.pool)
    pool += b'\0' * (-len(pool) % 4)
    head = b'DDDT' + struct.pack('<IIII', 1, spec['hash'], len(spec['tables']), len(pool))
    return head + pool + bytes(w.out)


# ---------------------------------------------------------------- C code generation
RD = {'b': 'rd_i8', 'B': 'rd_u8', 'h': 'rd_i16', 'H': 'rd_u16', 'i': 'rd_i32', 'I': 'rd_u32', 'f': 'rd_f32'}


def c_read_field(spec, lv, ftype, ptr, dims, ind, depth=0):
    """C lines reading one (possibly array / struct) value into lvalue lv."""
    pad = '    ' * ind
    if dims:
        v = 'i%d' % depth
        body = c_read_field(spec, '%s[%s]' % (lv, v), ftype, ptr, dims[1:], ind + 1, depth + 1)
        return '%sfor (int %s = 0; %s < %d; %s++) {\n%s%s}\n' % (pad, v, v, dims[0], v, body, pad)
    if ptr:
        return '%s%s = rd_str(r);\n' % (pad, lv)
    if ftype in spec['structs']:
        return '%sld_%s(r, &%s);\n' % (pad, ftype, lv)
    fmt = SCALARS.get(ftype, ('i', 4))[0]
    return '%s%s = %s(r);\n' % (pad, lv, RD[fmt])


def table_decl(t):
    """(declaration without 'extern', pointer variable text)"""
    base = 'char' if t['ptr'] else t['type']
    dims = t['dims']
    if not dims:
        return '%s %s' % (base, t['name'])
    if t['ptr']:
        return 'const char *const %s*%s' % ('(' if len(dims) > 1 else '', t['name']) if False else \
            ('const char *const *%s' % t['name'] if len(dims) == 1 else
             'const char *const (*%s)%s' % (t['name'], ''.join('[%d]' % d for d in dims[1:])))
    if len(dims) == 1:
        return 'const %s *%s' % (base, t['name'])
    return 'const %s (*%s)%s' % (base, t['name'], ''.join('[%d]' % d for d in dims[1:]))


def gen_header(spec):
    """Extern block that replaces the array/const declarations in dd_types.h."""
    lines = ['/* generated by tools/ddbin.py: game data tables, loaded from assets/gen/dd_data.bin by dd_data_load() */',
             '#ifdef DD_LOADER', '#define DD_C', '#else', '#define DD_C const', '#endif']
    for t in spec['tables']:
        if not t['dims']:
            base = t['type']
            lines.append('extern DD_C %s %s;' % (base, t['name']))
        else:
            lines.append('extern %s;' % table_decl(t))
    return '\n'.join(lines) + '\n'


def gen_loader(spec):
    s = spec
    o = ['/* generated by tools/ddbin.py - do not edit.  Reads gen/dd_data.bin (made by the extractor from the',
         ' * user\'s own game copy) into the dd_* tables.  Contains no game data. */',
         '#define DD_LOADER', '#include "dd_types.h"', '#include "dd_load.h"', '#include <stdlib.h>', '#include <string.h>', '',
         '#define DD_SCHEMA_HASH 0x%08XU' % s['hash'], '',
         'typedef struct { const uint8_t *p, *end; const char *pool; int err; } Rd;',
         'static uint32_t rd_u32(Rd *r) { if (r->end - r->p < 4) { r->err = 1; return 0; } uint32_t v = (uint32_t)r->p[0] | (uint32_t)r->p[1] << 8 | (uint32_t)r->p[2] << 16 | (uint32_t)r->p[3] << 24; r->p += 4; return v; }',
         'static int32_t rd_i32(Rd *r) { return (int32_t)rd_u32(r); }',
         'static uint16_t rd_u16(Rd *r) { if (r->end - r->p < 2) { r->err = 1; return 0; } uint16_t v = (uint16_t)(r->p[0] | r->p[1] << 8); r->p += 2; return v; }',
         'static int16_t rd_i16(Rd *r) { return (int16_t)rd_u16(r); }',
         'static uint8_t rd_u8(Rd *r) { if (r->end - r->p < 1) { r->err = 1; return 0; } return *r->p++; }',
         'static int8_t rd_i8(Rd *r) { return (int8_t)rd_u8(r); }',
         'static float rd_f32(Rd *r) { union { uint32_t u; float f; } c; c.u = rd_u32(r); return c.f; }',
         'static const char *rd_str(Rd *r) { uint32_t o = rd_u32(r); return o == 0xFFFFFFFFU ? NULL : r->pool + o; }', '']
    for name, fields in s['structs'].items():
        o.append('static void ld_%s(Rd *r, %s *o) {' % (name, name))
        for f in fields:
            o.append(c_read_field(s, 'o->' + f['name'], f['type'], f['ptr'], f['dims'], 1).rstrip('\n'))
        o.append('}')
        o.append('')
    # variables
    for t in s['tables']:
        if not t['dims']:
            o.append('%s %s;' % (t['type'], t['name']))
        else:
            o.append('%s;' % table_decl(t))
    o += ['', 'int dd_data_load(const void *blob, int size) {',
          '    const uint8_t *b = blob;',
          '    if (size < 20 || memcmp(b, "DDDT", 4)) return -1;',
          '    Rd rr, *r = &rr;',
          '    rr.p = b + 4; rr.end = b + size; rr.err = 0;',
          '    if (rd_u32(r) != 1) return -2;',
          '    if (rd_u32(r) != DD_SCHEMA_HASH) return -3;   /* pak made for a different build */',
          '    if (rd_u32(r) != %d) return -4;' % len(s['tables']),
          '    uint32_t pool = rd_u32(r);',
          '    if ((uint32_t)(rr.end - rr.p) < pool) return -5;',
          '    char *pc = malloc(pool ? pool : 1);',
          '    if (!pc) return -6;',
          '    memcpy(pc, rr.p, pool);',
          '    rr.pool = pc; rr.p += pool;']
    for t in s['tables']:
        n, dims = t['name'], t['dims']
        if not dims:
            o.append('    %s' % c_read_field(s, n, t['type'], t['ptr'], [], 0).strip())
            continue
        base = 'const char *' if t['ptr'] else t['type']
        rest = ''.join('[%d]' % d for d in dims[1:])
        decl = ('%s (*a)%s' % (base, rest)) if rest else ('%s *a' % base)
        o.append('    {')
        o.append('        uint32_t n = rd_u32(r);')
        o.append('        if (n > 1000000) return -7;')
        o.append('        %s = calloc(n ? n : 1, sizeof *a);' % decl)
        o.append('        if (!a) return -6;')
        o.append('        for (uint32_t i = 0; i < n; i++) {')
        o.append(c_read_field(s, 'a[i]', t['type'], t['ptr'], dims[1:], 3).rstrip('\n'))
        o.append('        }')
        o.append('        %s = a;' % n)
        o.append('    }')
    o += ['    return rr.err ? -8 : 0;', '}', '']
    return '\n'.join(o)


def main():
    cmd = sys.argv[1]
    if cmd == 'spec':
        spec = make_spec(sys.argv[2], sys.argv[3])
        json.dump(spec, open(sys.argv[4], 'w'), indent=1)
        print('spec: %d structs, %d tables, hash %08X' % (len(spec['structs']), len(spec['tables']), spec['hash']))
    elif cmd == 'gen':
        spec = json.load(open(sys.argv[2]))
        open(sys.argv[3], 'w').write(gen_loader(spec))
        open(sys.argv[4], 'w').write(gen_header(spec))
    elif cmd == 'bin':
        spec = json.load(open(sys.argv[2]))
        data = make_bin(spec, open(sys.argv[3], encoding='utf-8').read())
        open(sys.argv[4], 'wb').write(data)
        print('wrote %s (%d bytes)' % (sys.argv[4], len(data)))
    else:
        sys.exit(__doc__)


if __name__ == '__main__':
    main()
