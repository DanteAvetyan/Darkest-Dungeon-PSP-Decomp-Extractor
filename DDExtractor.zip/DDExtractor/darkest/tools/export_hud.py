"""Export the raid HUD art (bottom panels, torch meter, brackets, map icons, equipment icons)
at PSP scale into extracted/assets/hud/. Usage: export_hud.py <game dir> <assets dir>"""
import sys
from pathlib import Path

from PIL import Image, ImageOps

sys.path.insert(0, str(Path(__file__).parent))
from export_ui import write_ddi, export_font, HEROES  # noqa: E402

S = 0.25  # 1920x1080 UI -> 480x270


# Smallest power of two >= n (min 8, max 256): tile size for a HUD image.
def pow2(n):
    p = 8
    while p < n:
        p *= 2
    return min(p, 256)


# Save as a single-tile-size .ddi.
def save(img, path):
    write_ddi(img, path, tile=pow2(max(img.size)))


# Load a 1080p UI image, optionally crop (to its visible pixels or a box), scale by s.
def scaled(path, s=S, crop=None, alpha_crop=False):
    im = Image.open(path).convert("RGBA")
    if alpha_crop:
        im = im.crop(im.split()[3].getbbox())
    if crop:
        im = im.crop(crop)
    w, h = max(1, round(im.width * s)), max(1, round(im.height * s))
    return im.resize((w, h), Image.LANCZOS)


# Driver: converts every HUD, estate, store, quest-map and character-sheet piece.
def main():
    game, out = Path(sys.argv[1]), Path(sys.argv[2])
    hud = out / "hud"
    p, o = game / "panels", game / "overlays"
    save(scaled(p / "panel_banner.png", crop=(40, 0, 754, 136)), hud / "banner.ddi")
    save(scaled(p / "panel_hero.png"), hud / "hero.ddi")
    save(scaled(p / "panel_map.png"), hud / "map.ddi")
    save(scaled(p / "panel_inventory.png"), hud / "inventory.ddi")
    save(scaled(p / "party_order_button.png", 0.4), hud / "party_order.ddi")
    # battle status tray (overlays/tray_*.png, 24 px) at 10 px under each actor
    for t in o.glob("tray_*.png"):
        im = Image.open(t).convert("RGBA").resize((10, 10), Image.LANCZOS)
        save(im, hud / "tray" / (t.stem[5:] + ".ddi"))
    side = scaled(p / "side_decor.png")
    save(side, hud / "side_l.ddi")
    save(ImageOps.mirror(side), hud / "side_r.ddi")
    save(scaled(o / "torch.png", 0.24, alpha_crop=True), hud / "torch.ddi")
    save(scaled(o / "torch_flame.png", 0.75), hud / "flame.ddi")
    for k in ("selected", "target", "target_h"):
        save(scaled(o / f"{k}_1.png", 0.30, alpha_crop=True), hud / f"{k}.ddi")
    ab = p / "icons_ability"
    save(scaled(ab / "ability_move.png"), hud / "move.ddi")
    save(scaled(ab / "ability_pass.png"), hud / "pass.ddi")
    save(scaled(ab / "selected_ability.png"), hud / "skill_sel.ddi")
    for f in (p / "icons_map").glob("*.png"):
        n = f.stem.lower()
        if n.startswith(("room_", "hall_", "marker_")) or n == "indicator":
            save(scaled(f, 0.25 if n.startswith("room_") else 0.34), hud / "map" / f"{n}.ddi")
    for h in HEROES:
        for kind in ("weapon", "armour"):
            for lv in range(5):
                f = game / "heroes" / h / "icons_equip" / f"eqp_{kind}_{lv}.png"
                if f.exists():
                    save(scaled(f, 0.25), hud / "equip" / f"{h}_{kind}_{lv}.ddi")
    t, est = game / "campaign" / "town", game / "shared" / "estate"
    save(scaled(t / "estate_title" / "estate_nameplate.png", 0.2, alpha_crop=True), hud / "town" / "nameplate.ddi")
    save(scaled(t / "roster" / "roster_bggrad.png"), hud / "town" / "roster_bg.ddi")
    save(scaled(t / "roster" / "rosterelement.background.png"), hud / "town" / "roster_el.ddi")
    save(scaled(t / "roster" / "roster_topframe.png"), hud / "town" / "roster_top.ddi")
    pv = t / "provision"
    write_ddi(scaled(pv / "provision.background.png"), hud / "town" / "store_bg.ddi")
    save(scaled(pv / "provision.character.png"), hud / "town" / "store_char.ddi")
    save(scaled(pv / "inventory_grid_background_store.png", 0.33), hud / "town" / "store_grid.ddi")
    save(scaled(pv / "inventory_grid_background_party.png", 0.33), hud / "town" / "party_grid.ddi")
    qs = t / "quest_select"
    write_ddi(scaled(qs / "quest_select.background.png"), hud / "quest" / "map.ddi")
    save(scaled(qs / "quest_select.questverbose_bg.png"), hud / "quest" / "verbose.ddi")
    save(scaled(qs / "quest_select_selected.png", 0.17), hud / "quest" / "selected.ddi")
    save(scaled(qs / "locked_dungeon.png", 0.33), hud / "quest" / "locked.ddi")
    for kind in ("explore", "cleanse", "kill_boss"):
        for lv in (1, 3, 5):
            save(scaled(qs / f"quest_select_{kind}_{lv}.png", 0.5), hud / "quest" / f"{kind}_{lv}.ddi")
    ch = game / "shared" / "character"
    sheet = Image.open(ch / "characterpanel_bg.png").convert("RGBA")
    sheet.alpha_composite(Image.open(ch / "characterpanel_frames.png").convert("RGBA"))
    k = 480 / sheet.width
    write_ddi(sheet.resize((480, round(sheet.height * k)), Image.LANCZOS), hud / "sheet" / "panel.ddi")
    for f in (game / "shared" / "resistance").glob("resistance_icon_*.png"):
        save(scaled(f, 0.5), hud / "sheet" / f"{f.stem.replace('resistance_icon_', 'res_')}.ddi")
    for c in ("gold", "bust", "portrait", "deed", "crest"):
        save(scaled(est / f"currency.{c}.icon.png", 0.4), hud / "town" / f"cur_{c}.ddi")
    # inventory icons (loot window, provision store): gold_0, gem_jade, heirloom_bust, supply_torch...
    for kind in ("gold", "gem", "heirloom", "supply", "provision"):
        for f in sorted((p / "icons_equip" / kind).glob("*.png")):
            name = f.stem.split("+", 1)[1].lstrip("_")
            save(scaled(f, 0.3), hud / "items" / f"{kind}_{name}.ddi")
    # trinket icons (kickstarter backer trinkets are never awarded: skipped)
    import json
    entries = json.loads((game / "trinkets/base.entries.trinkets.json").read_text())["entries"]
    for e in entries:
        f = p / "icons_equip" / "trinket" / f"inv_trinket+{e['id']}.png"
        if e["rarity"] != "kickstarter" and f.exists():
            save(scaled(f, 0.3), hud / "items" / f"trinket_{e['id']}.ddi")
    print("small font:", export_font(game / "fonts/ubuntu.fnt", out / "fonts/small.ddf", 9, tight=0.86))


if __name__ == "__main__":
    main()
