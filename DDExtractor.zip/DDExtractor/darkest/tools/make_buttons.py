#!/usr/bin/env python3
"""Draw our own PSP button glyphs (not game art) into assets/ui/buttons.ddi: 14 icons, 16x16 each,
in text.c order: cross, circle, square, triangle, L, R, START, SELECT, d-pad, d-pad left/right,
d-pad up/down, right, up, down.

Usage: make_buttons.py <assets_dir>"""
import sys
from pathlib import Path

from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).resolve().parent))
from export_ui import write_ddi  # noqa: E402

S = 64  # drawn large, then scaled to 16


# Draw the shared round button face.
def face(draw, col):
    draw.ellipse((2, 2, S - 3, S - 3), fill=(28, 26, 24, 255), outline=(150, 140, 120, 255), width=3)


# Draw glyph number i (order = BG_* order in text.h) onto a 16x16 transparent canvas.
def icon(i):
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    if i < 4:
        face(d, None)
        if i == 0:  # cross, blue
            d.line((18, 18, 46, 46), fill=(110, 160, 255, 255), width=7)
            d.line((46, 18, 18, 46), fill=(110, 160, 255, 255), width=7)
        elif i == 1:  # circle, red
            d.ellipse((17, 17, 47, 47), outline=(255, 90, 90, 255), width=6)
        elif i == 2:  # square, pink
            d.rectangle((19, 19, 45, 45), outline=(250, 130, 210, 255), width=6)
        else:  # triangle, green
            d.polygon([(32, 14), (50, 46), (14, 46)], outline=(90, 230, 150, 255), width=6)
    elif i < 8:  # shoulder / pill buttons
        d.rounded_rectangle((2, 14, S - 3, S - 15), radius=14, fill=(28, 26, 24, 255), outline=(150, 140, 120, 255), width=3)
        if i == 4 or i == 5:
            x = 24 if i == 4 else 22
            if i == 4:
                d.line((x, 22, x, 42), fill=(235, 225, 205, 255), width=6)
                d.line((x, 42, x + 18, 42), fill=(235, 225, 205, 255), width=6)
            else:
                d.line((x, 22, x, 42), fill=(235, 225, 205, 255), width=6)
                d.arc((x - 6, 22, x + 16, 34), -90, 90, fill=(235, 225, 205, 255), width=6)
                d.line((x + 2, 33, x + 18, 42), fill=(235, 225, 205, 255), width=6)
        elif i == 6:  # START: play triangle
            d.polygon([(24, 22), (44, 32), (24, 42)], fill=(235, 225, 205, 255))
        else:  # SELECT: two bars
            d.rectangle((18, 25, 46, 29), fill=(235, 225, 205, 255))
            d.rectangle((18, 35, 46, 39), fill=(235, 225, 205, 255))
    else:  # d-pad variants: cross shape, highlighted arms
        base, hi = (110, 100, 90, 255), (240, 225, 190, 255)
        arms = {"u": (24, 4, 40, 26), "d": (24, 38, 40, 60), "l": (4, 24, 26, 40), "r": (38, 24, 60, 40)}
        lit = {8: "udlr", 9: "lr", 10: "ud", 11: "r", 12: "u", 13: "d"}[i]
        d.rectangle((24, 24, 40, 40), fill=base)
        for k, box in arms.items():
            d.rectangle(box, fill=hi if k in lit else base)
    return im.resize((16, 16), Image.Resampling.LANCZOS)


# Render all glyphs side by side into one strip image and save it as buttons.ddi.
def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    out = Path(sys.argv[1])
    atlas = Image.new("RGBA", (256, 16), (0, 0, 0, 0))
    for i in range(14):
        atlas.paste(icon(i), (i * 16, 0))
    write_ddi(atlas, out / "ui/buttons.ddi")
    print("buttons: 14 icons")


if __name__ == "__main__":
    main()
