#!/usr/bin/env python3
"""Scale Spine sprites for the PSP screen, reduce to 256 colours, pack into one 512x512 atlas.

Usage: pack_psp_atlas.py <scale> <out_dir> <spine_dir>/<name> [<spine_dir>/<name> ...]
Example:
  pack_psp_atlas.py 0.3 extracted/psp \
      extracted/spine/crusader/crusader.sprite.combat \
      extracted/spine/brigand_cutthroat/brigand_cutthroat.sprite.combat

Inputs are the outputs of convert_spine.py (<name>.json, <name>.atlas.json, page png).
Writes to <out_dir>:
  atlas.png            512x512 palettized PNG (256 colours incl. alpha)
  atlas.t8 / atlas.clut  raw PSP data: 8-bit indices + 256 x RGBA8888 palette (GU_PSM_T8 / GU_PSM_8888)
  atlas.json           region rects per skeleton in the new atlas
  <name>.atlas         libGDX/Spine atlas text for the new page (for Spine viewers)
  <name>.json          skeleton with every length (bones, attachments, translate keys) scaled
  preview.png          setup pose: original vs PSP version, plus both on a 480x272 frame
"""
import copy
import json
import math
import sys
from pathlib import Path

from PIL import Image, ImageDraw

ATLAS_SIZE = 512
PAD = 2  # transparent gap between regions; 1px of it is filled by edge extrusion
SCREEN = (480, 272)


# ---------------------------------------------------------------- loading / cropping

def load_sprite(base):
    base = Path(base)
    skel = json.loads(Path(f"{base}.json").read_text())
    pages = json.loads(Path(f"{base}.atlas.json").read_text())
    return skel, pages


def crop_regions(pages, page_dir):
    """Return {region_name: RGBA image in unrotated orientation}."""
    out = {}
    for page in pages:
        img = Image.open(page_dir / page["file"]).convert("RGBA")
        for name, r in page["regions"].items():
            x, y = r["xy"]
            w, h = r["size"]
            if r["rotate"] == "true":
                # Stored rotated 90deg CCW with a swapped footprint; rotate back clockwise.
                out[name] = img.crop((x, y, x + h, y + w)).transpose(Image.Transpose.ROTATE_270)
            else:
                out[name] = img.crop((x, y, x + w, y + h))
    return out


def resize_rgba(img, size):
    # Premultiply so transparent pixels don't bleed dark fringes into edges.
    return img.convert("RGBa").resize(size, Image.Resampling.LANCZOS).convert("RGBA")


# ---------------------------------------------------------------- skeleton scaling

def scale_skeleton(skel, s):
    """Uniformly scale every length in a Spine 2.1 skeleton. Angles and scale keys are unchanged."""
    skel = copy.deepcopy(skel)
    for k in ("width", "height"):
        if k in skel.get("skeleton", {}):
            skel["skeleton"][k] *= s
    for b in skel["bones"]:
        for k in ("x", "y", "length"):
            if k in b:
                b[k] *= s
    for skin in skel["skins"].values():
        for slot in skin.values():
            for att in slot.values():
                t = att.get("type", "region")
                for k in ("x", "y", "width", "height"):
                    if k in att:
                        att[k] *= s
                if t == "mesh":
                    att["vertices"] = [v * s for v in att["vertices"]]
                elif t == "skinnedmesh":
                    att["vertices"] = scale_weighted_vertices(att["vertices"], s)
    for anim in skel.get("animations", {}).values():
        for tracks in anim.get("bones", {}).values():
            for key in tracks.get("translate", []):
                key["x"] = key.get("x", 0) * s
                key["y"] = key.get("y", 0) * s
        for skin in anim.get("ffd", {}).values():
            for slot in skin.values():
                for keys in slot.values():
                    for key in keys:
                        if "vertices" in key:
                            key["vertices"] = [v * s for v in key["vertices"]]
    return skel


def scale_weighted_vertices(v, s):
    """skinnedmesh vertices: per vertex [n, (bone, x, y, weight) * n]."""
    out, i = [], 0
    while i < len(v):
        n = int(v[i])
        out.append(n)
        i += 1
        for _ in range(n):
            out += [v[i], v[i + 1] * s, v[i + 2] * s, v[i + 3]]
            i += 4
    return out


# ---------------------------------------------------------------- packing

def shelf_pack(sizes):
    """Simple shelf packer. sizes: {key: (w, h)} -> {key: (x, y)}; raises if it doesn't fit."""
    order = sorted(sizes, key=lambda k: (-sizes[k][1], -sizes[k][0]))
    pos, x, y, shelf_h = {}, PAD, PAD, 0
    for k in order:
        w, h = sizes[k]
        if x + w + PAD > ATLAS_SIZE:
            x, y, shelf_h = PAD, y + shelf_h + PAD, 0
        if y + h + PAD > ATLAS_SIZE:
            raise SystemExit(f"atlas overflow at {k}; lower the scale")
        pos[k] = (x, y)
        x += w + PAD
        shelf_h = max(shelf_h, h)
    return pos, y + shelf_h + PAD


def extrude(atlas, x, y, w, h):
    """Copy the outermost pixel row/column outward by 1px so bilinear filtering stays clean."""
    atlas.paste(atlas.crop((x, y, x + w, y + 1)), (x, y - 1))
    atlas.paste(atlas.crop((x, y + h - 1, x + w, y + h)), (x, y + h))
    atlas.paste(atlas.crop((x, y - 1, x + 1, y + h + 1)), (x - 1, y - 1))
    atlas.paste(atlas.crop((x + w - 1, y - 1, x + w, y + h + 1)), (x + w, y - 1))


def quantize_rgba(img):
    """256 colours including alpha. Fully transparent pixels are zeroed first so they share one entry."""
    px = img.load()
    for yy in range(img.height):
        for xx in range(img.width):
            if px[xx, yy][3] == 0:
                px[xx, yy] = (0, 0, 0, 0)
    q = img.quantize(colors=256, method=Image.Quantize.LIBIMAGEQUANT, dither=Image.Dither.NONE)
    pal = q.getpalette("RGBA")[: 256 * 4]
    pal += [0] * (256 * 4 - len(pal))
    return q, pal


# ---------------------------------------------------------------- setup-pose renderer (preview only)

def world_bones(skel):
    """Spine 2.1 setup-pose world transforms: name -> (wx, wy, m00, m01, m10, m11)."""
    out = {}
    for b in skel["bones"]:
        x, y = b.get("x", 0), b.get("y", 0)
        rot, sx, sy = b.get("rotation", 0), b.get("scaleX", 1), b.get("scaleY", 1)
        p = out.get(b.get("parent"))
        if p:
            wx = p["x"] + x * p["m"][0] + y * p["m"][1]
            wy = p["y"] + x * p["m"][2] + y * p["m"][3]
            if b.get("inheritScale", True):
                sx, sy = sx * p["sx"], sy * p["sy"]
            if b.get("inheritRotation", True):
                rot += p["rot"]
        else:
            wx, wy = x, y
        c, s = math.cos(math.radians(rot)), math.sin(math.radians(rot))
        out[b["name"]] = {"x": wx, "y": wy, "rot": rot, "sx": sx, "sy": sy,
                          "m": (c * sx, -s * sy, s * sx, c * sy)}
    return out


def bone_xform(b, lx, ly):
    m = b["m"]
    return b["x"] + lx * m[0] + ly * m[1], b["y"] + lx * m[2] + ly * m[3]


def attachment_geometry(att, bone, bones_by_index):
    """-> (world_vertices[(x, y)], uvs[(u, v)] region-relative, triangles[(i, j, k)])."""
    t = att.get("type", "region")
    if t == "region":
        w, h = att["width"], att["height"]
        sx, sy = att.get("scaleX", 1), att.get("scaleY", 1)
        r = math.radians(att.get("rotation", 0))
        c, s = math.cos(r), math.sin(r)
        corners = [(-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, h / 2), (-w / 2, h / 2)]
        verts = []
        for cx, cy in corners:
            cx, cy = cx * sx, cy * sy
            lx = att.get("x", 0) + cx * c - cy * s
            ly = att.get("y", 0) + cx * s + cy * c
            verts.append(bone_xform(bone, lx, ly))
        return verts, [(0, 1), (1, 1), (1, 0), (0, 0)], [(0, 1, 2), (0, 2, 3)]
    uv = att["uvs"]
    uvs = list(zip(uv[0::2], uv[1::2]))
    tris = list(zip(*[iter(att["triangles"])] * 3))
    v = att["vertices"]
    if t == "mesh":
        verts = [bone_xform(bone, v[i], v[i + 1]) for i in range(0, len(v), 2)]
    else:
        verts, i = [], 0
        while i < len(v):
            n, i, wx, wy = int(v[i]), i + 1, 0.0, 0.0
            for _ in range(n):
                px, py = bone_xform(bones_by_index[int(v[i])], v[i + 1], v[i + 2])
                wx, wy, i = wx + px * v[i + 3], wy + py * v[i + 3], i + 4
            verts.append((wx, wy))
    return verts, uvs, tris


def draw_triangle(canvas, tex, dst, src):
    """Affine-map a texture triangle onto the canvas (dst/src: three (x, y) points in pixels)."""
    xs, ys = [p[0] for p in dst], [p[1] for p in dst]
    x0, y0 = math.floor(min(xs)), math.floor(min(ys))
    x1, y1 = math.ceil(max(xs)), math.ceil(max(ys))
    if x1 <= x0 or y1 <= y0:
        return
    (ax, ay), (bx, by), (cx, cy) = [(x - x0, y - y0) for x, y in dst]
    det = (bx - ax) * (cy - ay) - (cx - ax) * (by - ay)
    if abs(det) < 1e-9:
        return
    (su, sv), (tu, tv), (ru, rv) = src
    # Solve dst->src affine: src = A * dst + t
    ia, ib = (cy - ay) / det, -(cx - ax) / det
    ic, id_ = -(by - ay) / det, (bx - ax) / det
    a = (tu - su) * ia + (ru - su) * ic
    b = (tu - su) * ib + (ru - su) * id_
    d = (tv - sv) * ia + (rv - sv) * ic
    e = (tv - sv) * ib + (rv - sv) * id_
    c, f = su - a * ax - b * ay, sv - d * ax - e * ay
    size = (x1 - x0, y1 - y0)
    patch = tex.transform(size, Image.Transform.AFFINE, (a, b, c, d, e, f), Image.Resampling.BILINEAR)
    mask = Image.new("L", size, 0)
    ImageDraw.Draw(mask).polygon([(ax, ay), (bx, by), (cx, cy)], fill=255)
    patch.putalpha(Image.composite(patch.getchannel("A"), mask, mask))
    canvas.alpha_composite(patch, (x0, y0))


def render_setup_pose(skel, regions, canvas, origin):
    """Draw the setup pose; regions maps attachment path -> RGBA image. origin = canvas pos of skeleton (0,0)."""
    bones = world_bones(skel)
    by_index = [bones[b["name"]] for b in skel["bones"]]
    skin = skel["skins"]["default"]
    ox, oy = origin
    for slot in skel["slots"]:
        name = slot.get("attachment")
        att = skin.get(slot["name"], {}).get(name) if name else None
        if att is None:
            continue
        tex = regions[att.get("path", name)]
        verts, uvs, tris = attachment_geometry(att, bones[slot["bone"]], by_index)
        pts = [(ox + x, oy - y) for x, y in verts]  # Spine is y-up
        tw, th = tex.size
        for i, j, k in tris:
            draw_triangle(canvas, tex, [pts[i], pts[j], pts[k]],
                          [(uvs[n][0] * tw, uvs[n][1] * th) for n in (i, j, k)])


# ---------------------------------------------------------------- main

def main():
    if len(sys.argv) < 4:
        sys.exit(__doc__)
    scale, out_dir = float(sys.argv[1]), Path(sys.argv[2])
    out_dir.mkdir(parents=True, exist_ok=True)

    sprites = []  # (short_name, file_stem, original skel, scaled skel, original regions)
    sizes, scaled_imgs = {}, {}
    for base in map(Path, sys.argv[3:]):
        skel, pages = load_sprite(base)
        regions = crop_regions(pages, base.parent)
        short = base.name.split(".")[0]
        sprites.append((short, base.name, skel, scale_skeleton(skel, scale), regions))
        for rname, img in regions.items():
            size = (max(1, round(img.width * scale)), max(1, round(img.height * scale)))
            scaled_imgs[(short, rname)] = resize_rgba(img, size)
            sizes[(short, rname)] = size

    pos, used_h = shelf_pack(sizes)
    atlas = Image.new("RGBA", (ATLAS_SIZE, ATLAS_SIZE), (0, 0, 0, 0))
    for key, (x, y) in pos.items():
        atlas.paste(scaled_imgs[key], (x, y))
        extrude(atlas, x, y, *sizes[key])

    q, pal = quantize_rgba(atlas)
    q.save(out_dir / "atlas.png", transparency=bytes(pal[3::4]))
    (out_dir / "atlas.t8").write_bytes(q.tobytes())
    (out_dir / "atlas.clut").write_bytes(bytes(pal))  # R,G,B,A per entry = GU_PSM_8888 in memory

    # Atlas description + per-skeleton libGDX atlas + scaled skeleton JSON
    desc = {"page": "atlas.png", "size": [ATLAS_SIZE, ATLAS_SIZE], "scale": scale, "skeletons": {}}
    for short, stem, _, scaled, regions in sprites:
        rects = {}
        lines = ["", "atlas.png", f"size: {ATLAS_SIZE},{ATLAS_SIZE}", "format: RGBA8888",
                 "filter: Linear,Linear", "repeat: none"]
        for rname in regions:
            (x, y), (w, h) = pos[(short, rname)], sizes[(short, rname)]
            rects[rname] = {"x": x, "y": y, "w": w, "h": h}
            lines += [rname, "  rotate: false", f"  xy: {x}, {y}", f"  size: {w}, {h}",
                      f"  orig: {w}, {h}", "  offset: 0, 0", "  index: -1"]
        desc["skeletons"][short] = rects
        (out_dir / f"{stem}.atlas").write_text("\n".join(lines) + "\n")
        (out_dir / f"{stem}.json").write_text(json.dumps(scaled))
    (out_dir / "atlas.json").write_text(json.dumps(desc, indent=1))

    # Preview: originals (drawn at the target scale for comparison) / PSP atlas render / 480x272 frame
    final = q.convert("RGBA")
    psp_regions = {s: {r: final.crop((p[0], p[1], p[0] + sizes[(s, r)][0], p[1] + sizes[(s, r)][1]))
                       for (ss, r), p in pos.items() if ss == s} for s, *_ in sprites}
    cell_w, cell_h = 160, 160
    sheet = Image.new("RGBA", (cell_w * 2 * len(sprites), cell_h + SCREEN[1] + 20), (40, 40, 48, 255))
    for i, (short, _, orig, scaled, regions) in enumerate(sprites):
        a = Image.new("RGBA", (cell_w * 4, cell_h * 4), (0, 0, 0, 0))
        render_setup_pose(orig, regions, a, (cell_w * 2, cell_h * 4 - 40))
        sheet.alpha_composite(a.resize((cell_w, cell_h), Image.Resampling.LANCZOS), (cell_w * 2 * i, 0))
        b = Image.new("RGBA", (cell_w, cell_h), (0, 0, 0, 0))
        render_setup_pose(scaled, psp_regions[short], b, (cell_w // 2, cell_h - 10))
        sheet.alpha_composite(b, (cell_w * (2 * i + 1), 0))
    frame = Image.new("RGBA", SCREEN, (20, 18, 24, 255))
    ImageDraw.Draw(frame).line([(0, 230), (480, 230)], fill=(70, 60, 50, 255))
    # First sprite fills ranks 4..1 on the left, second sprite ranks 1..4 on the right.
    for (short, _, _, scaled, _), xs in zip(sprites, ([45, 105, 165, 225], [270, 330, 390, 450])):
        for x in xs:
            render_setup_pose(scaled, psp_regions[short], frame, (x, 240))
    sheet.alpha_composite(frame, (0, cell_h + 20))
    sheet.save(out_dir / "preview.png")

    print(f"scale {scale}: {len(pos)} regions packed, {used_h}/{ATLAS_SIZE} px of atlas height used")
    for short, _, _, scaled, _ in sprites:
        w, h = scaled["skeleton"]["width"], scaled["skeleton"]["height"]
        print(f"  {short}: skeleton bounds {w:.0f}x{h:.0f} px on PSP screen")
    print(f"wrote {sorted(p.name for p in out_dir.iterdir())}")


if __name__ == "__main__":
    main()
