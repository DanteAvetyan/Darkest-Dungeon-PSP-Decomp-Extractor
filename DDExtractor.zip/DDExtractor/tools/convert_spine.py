#!/usr/bin/env python3
"""Convert one Darkest Dungeon Spine animation (.skel + .atlas + .png) to JSON.

Usage: convert_spine.py <anim_dir> <png_dir> <name> <out_dir>
Example:
  convert_spine.py ~/psp/DarkestDungeonCopy/heroes/crusader/anim \
                   ~/psp/DarkestDungeonCopy/heroes/crusader/crusader_A/anim \
                   crusader.sprite.combat extracted/spine/crusader

Writes <name>.json (skeleton), <name>.atlas.json (regions), copies <name>.png,
and prints a summary. Uses tools/third_party/SpineConverter2.1.27.
"""
import json
import shutil
import sys
from pathlib import Path

import os
CONVERTER = Path(os.environ.get("DD_SPINE_CONVERTER") or Path(__file__).resolve().parent / "third_party" / "SpineConverter2.1.27")
sys.path.insert(0, str(CONVERTER))

from spBinaryReader import spBinaryReader  # noqa: E402
from spJsonWriter import spJsonWriter  # noqa: E402


def parse_atlas(path):
    """Parse a libGDX/Spine 2.x .atlas into {page: {...}, regions: {name: {...}}}."""
    lines = [l.rstrip("\n") for l in Path(path).read_text().splitlines()]
    pages, cur_page, cur_region = [], None, None
    for line in lines:
        if not line.strip():
            cur_page = None
            continue
        if cur_page is None:
            cur_page = {"file": line.strip(), "regions": {}}
            pages.append(cur_page)
            cur_region = None
            continue
        if ":" in line and (line.startswith(" ") or cur_region is None and not line.startswith(" ")):
            key, val = (s.strip() for s in line.split(":", 1))
            nums = [v.strip() for v in val.split(",")]
            parsed = [int(n) if n.lstrip("-").isdigit() else n for n in nums]
            parsed = parsed[0] if len(parsed) == 1 else parsed
            (cur_region if line.startswith(" ") else cur_page)[key] = parsed
        else:
            cur_region = {}
            cur_page["regions"][line.strip()] = cur_region
    return pages


def main():
    if len(sys.argv) != 5:
        sys.exit(__doc__)
    anim_dir = Path(sys.argv[1]).expanduser()
    png_dir = Path(sys.argv[2]).expanduser()
    name = sys.argv[3]
    out_dir = Path(sys.argv[4]).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)

    skel = spBinaryReader().readSkeletonDataFile(str(anim_dir / f"{name}.skel"))
    spJsonWriter().writeSkeletonDataFile(skel, str(out_dir / f"{name}.json"))

    pages = parse_atlas(anim_dir / f"{name}.atlas")
    (out_dir / f"{name}.atlas.json").write_text(json.dumps(pages, indent=1))
    for p in pages:
        shutil.copy2(png_dir / p["file"], out_dir / p["file"])

    j = json.loads((out_dir / f"{name}.json").read_text())
    print(f"skeleton: {j.get('skeleton')}")
    print(f"bones {len(j.get('bones', []))}, slots {len(j.get('slots', []))}, "
          f"skins {list(j.get('skins', {}))}, events {list(j.get('events', {}))}")
    for anim, a in j.get("animations", {}).items():
        print(f"  anim '{anim}': bone tracks {len(a.get('bones', {}))}, "
              f"slot tracks {len(a.get('slots', {}))}, ffd {bool(a.get('ffd'))}, "
              f"drawOrder {bool(a.get('drawOrder'))}, events {len(a.get('events', []))}")
    for p in pages:
        print(f"atlas page {p['file']} size {p.get('size')} regions {len(p['regions'])}")


if __name__ == "__main__":
    main()
