#!/usr/bin/env python3
"""Extract one hero and one monster from Darkest Dungeon .darkest data files into JSON.

Usage: extract_units.py <game_dir> <hero_class> <monster_class> <monster_tier> <out.json>
Example: extract_units.py ~/psp/DarkestDungeonCopy crusader brigand_cutthroat A extracted/units.json

Output is for personal use only; keep it under the gitignored extracted/ folder.
"""
import json
import re
import shlex
import sys
from pathlib import Path


def parse_value(tok):
    """Turn one .darkest token into a Python value."""
    low = tok.lower()
    if low == "true":
        return True
    if low == "false":
        return False
    if tok.endswith("%"):
        try:
            return float(tok[:-1]) / 100.0
        except ValueError:
            return tok
    try:
        return int(tok)
    except ValueError:
        pass
    try:
        return float(tok)
    except ValueError:
        return tok


def parse_darkest(path):
    """Parse a .darkest file into a list of (record_type, {field: value}).

    Each line looks like:  key: .field v1 v2 .field2 v3 ...
    Fields with one value become scalars, more become lists, none become None.
    """
    records = []
    for raw in Path(path).read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("//") or ":" not in line:
            continue
        key, rest = line.split(":", 1)
        rest = re.sub(r'"\.(?=[A-Za-z_])', '" .', rest)  # some lines lack a space after a quoted value
        rest = re.sub(r'(?<=[%0-9])\.(?=[A-Za-z_])', ' .', rest)  # ...or after a number like 33%.on_hit
        try:
            tokens = shlex.split(rest, posix=True)
        except ValueError:
            tokens = rest.split()
        fields, cur = {}, None
        for tok in tokens:
            if tok.startswith(".") and len(tok) > 1 and not tok[1].isdigit():
                cur = tok[1:]
                fields[cur] = []
            elif cur is not None:
                fields[cur].append(parse_value(tok))
        fields = {k: (None if not v else v[0] if len(v) == 1 else v) for k, v in fields.items()}
        records.append((key.strip(), fields))
    return records


def ranks(value):
    """Rank strings like '21', '~12', '@1234' -> {ranks:[1,2], all:bool, friendly:bool}."""
    if value is None:
        return {"ranks": [], "all": False, "friendly": False}
    s = str(value)
    return {
        "ranks": sorted(int(c) for c in s if c.isdigit()),
        "all": "~" in s,       # hits every listed rank at once
        "friendly": "@" in s,  # targets own party
    }


def as_list(v):
    return [] if v is None else v if isinstance(v, list) else [v]


def extract_hero(game, cls):
    recs = parse_darkest(game / "heroes" / cls / f"{cls}.info.darkest")
    hero = {"id": cls, "resistances": {}, "weapons": [], "armours": [], "skills": {}, "tags": []}
    for key, f in recs:
        if key == "resistances":
            hero["resistances"] = f
        elif key == "weapon":
            hero["weapons"].append({"name": f["name"], "atk": f.get("atk"), "dmg": f.get("dmg"),
                                    "crit": f.get("crit"), "spd": f.get("spd")})
        elif key == "armour":
            hero["armours"].append({"name": f["name"], "def": f.get("def"), "prot": f.get("prot"),
                                    "hp": f.get("hp"), "spd": f.get("spd")})
        elif key in ("combat_skill", "combat_move_skill"):
            sk = hero["skills"].setdefault(f["id"], {"type": f.get("type"), "levels": []})
            sk["levels"].append({
                "level": f.get("level"),
                "atk": f.get("atk"), "dmg_mod": f.get("dmg"), "crit": f.get("crit"),
                "heal": f.get("heal"), "move": f.get("move"),
                "launch": ranks(f.get("launch")), "target": ranks(f.get("target")),
                "per_battle_limit": f.get("per_battle_limit"),
                "effects": as_list(f.get("effect")),
            })
        elif key == "tag":
            hero["tags"].append(f["id"])
    return hero


def extract_monster(game, cls, tier):
    variant = f"{cls}_{tier}"
    recs = parse_darkest(game / "monsters" / cls / variant / f"{variant}.info.darkest")
    mon = {"id": variant, "skills": []}
    for key, f in recs:
        if key == "enemy_type":
            mon["enemy_type"] = f.get("id")
        elif key == "display":
            mon["size"] = f.get("size")
        elif key == "stats":
            mon["stats"] = f
        elif key == "skill":
            mon["skills"].append({
                "id": f["id"], "type": f.get("type"),
                "atk": f.get("atk"), "dmg": f.get("dmg"), "crit": f.get("crit"),
                "move": f.get("move"),
                "launch": ranks(f.get("launch")), "target": ranks(f.get("target")),
                "effects": as_list(f.get("effect")),
            })
        elif key == "monster_brain":
            mon["brain"] = f.get("id")
        elif key == "initiative":
            mon["turns_per_round"] = f.get("number_of_turns_per_round")
    return mon


def extract_effects(game, names):
    """Pull just the effect definitions referenced by the extracted skills."""
    out = {}
    for key, f in parse_darkest(game / "effects" / "base.effects.darkest"):
        name = f.get("name")
        if key == "effect" and isinstance(name, str) and name in names:
            out[f["name"]] = {k: v for k, v in f.items() if k != "name"}
    return out


def main():
    if len(sys.argv) != 6:
        sys.exit(__doc__)
    game = Path(sys.argv[1]).expanduser()
    hero = extract_hero(game, sys.argv[2])
    mon = extract_monster(game, sys.argv[3], sys.argv[4])

    wanted = {e for s in hero["skills"].values() for lv in s["levels"] for e in lv["effects"]}
    wanted |= {e for s in mon["skills"] for e in s["effects"]}
    data = {"hero": hero, "monster": mon, "effects": extract_effects(game, wanted)}
    missing = sorted(wanted - data["effects"].keys())
    if missing:
        data["effects_not_found"] = missing

    out = Path(sys.argv[5])
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(data, indent=1))
    print(f"wrote {out} ({out.stat().st_size} bytes): "
          f"{len(hero['skills'])} hero skills, {len(mon['skills'])} monster skills, "
          f"{len(data['effects'])} effects, {len(missing)} missing")


if __name__ == "__main__":
    main()
