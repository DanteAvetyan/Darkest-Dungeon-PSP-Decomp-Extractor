#!/bin/sh
cd "$(dirname "$0")" && exec python3 darkest/extractor/extractor.py "$@"
