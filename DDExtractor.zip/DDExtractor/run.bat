@echo off
cd /d "%~dp0"
python darkest\extractor\extractor.py %*
